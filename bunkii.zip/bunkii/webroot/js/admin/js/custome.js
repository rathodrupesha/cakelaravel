/** Form validation **/
$(function() {
    $('#login').validate();
    $('#user').validate();
    $('#role').validate();
    $('#change-password').validate({ 
    		rules: {
                new_password: {
                    required: true,
                    minlength: 5
                },
                con_password: {
                    required: true,
                    minlength: 5,
                    equalTo: "#new_password"
                },
            }
        });
});

