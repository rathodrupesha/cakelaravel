<?php
namespace App\View\Helper;

use Cake\View\Helper;

class DatatableHelper extends Helper
{
    //public $helpers = ['Html'];

    public function createTable($thArray,$tableId,$extra = array())
    {
        $table = '';
        $table .= '<table id="'.$tableId.'" class="table table-responsive table-striped tableAjax" width="100%">';
        $table .= '<thead>';
        $table .= '<tr>';
        foreach ($thArray as $key => $thVal)
        {
        	$table .= '<th>'.$thVal.'</th>';	
        }
        $table .= '</tr>';
        $table .= '</thead>';
        $table .= '</table>';
        return $table;
    }
    
}