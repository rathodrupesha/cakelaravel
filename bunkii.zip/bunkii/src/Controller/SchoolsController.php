<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Validation\Validation;
use Cake\Event\Event;
use Cake\Datasource\ConnectionManager;
use App\View\Helper\DatatableHelper;
/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 */
class SchoolsController extends AppController
{
    public function beforeFilter(Event $event) {
        $this->Auth->allow(['login','add','uploadImage','activeAccount','forgotpassword']);
        parent::beforeFilter($event);
        $this->viewBuilder()->layout('default'); // Admin panel layout
    }
    /**
     * Index method
       //
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $tableTh = array("Id","School Name","Email","Web Address","Image","Status","Action");
        $request = $this->request->data;
        //echo "<pre>"; print_r($request); exit();
        $deletei = ' class="btn btn-danger"><i class="fa fa-trash"></i>';
        $editi = ' class="btn btn-info"><i class="fa fa-edit"></i>';
        $viewi = ' class="btn btn-success"><i class="fa fa-eye"></i>';

        $deleteLink = "<a href='+BASE_URL+'schools/delete/'+id+' $deletei</a>";
        $EditLink = "<a href='+BASE_URL+'schools/edit/'+id+' $editi</a>";
        $ViewLink = "<a href='+BASE_URL+'schools/view/'+id+' $viewi</a>";
        $URL = "BASE_URL+'schools'";
        $status = "full.status =='1'?'Active':'Inactive'";
        $imglink="<img src=\"'+API_IMAGE_URL+'school/'+full.school_image+'\" width=\"100\" height=\"80\">";
    
        $scriptStr = "'columns':[{ 'data':'id' },{ 'data': 'name'},{ 'data': 'email' },{ 'data': 'web_address' },{ 'data': 'school_image','render':function (id, type, full, meta){ return '$imglink' } },{ 'data': 'id','render':function (id, type, full, meta){ return $status } },{ 'data': 'id','sortable':false,'render':function (id, type, full, meta){ return '$ViewLink $EditLink $deleteLink' } },],'processing': true,'serverSide': true,'ajax': {url: $URL,type: 'POST'}";
 
        if (!empty($request))
        {
            $modelName = $this->modelClass;
            $parameter['fields'] = array('Schools.id','Schools.name','Schools.email','Schools.web_address','Schools.school_image','Schools.status');
            $parameter['conditions'] = array('Schools.isDeleted' => 0);
            $parameter['join'] = array();
           // echo "<pre>"; print_r($parameter); exit();
            // $parameter['fields'] = array('Collages.id','Collages.title','Collages.collages_image');
            // $parameter['conditions'] = array();
            // $parameter['join'] = array('Users');
            $result = $this->ApiHttpRequest->createAjaxTable($modelName,$request,$parameter);
           //echo "<pre>"; print_r($result); exit();
            echo json_encode($result);exit;
        }
        $this->set(compact('tableTh','scriptStr'));
    }
    
    public function view($id = null)
    {

        $params = array(            
            'conditions' => ['Schools.id'=>$id],
            'contain' => [],                      
            'fields' => array(),
            'select' => array(),
            'get' => 'all',
            'order' => array(),
            'page' => 1, 
            'limit' => 1
        );
        $school = $this->ApiHttpRequest->sendRequest($params);
        $schools = $school->Schools[0];
        $this->set('schools', $schools);
        $this->set('_serialize', ['schools']);
    }

    /**
     * Add method

     * URL : 192.168.0.133/bankii/api_bankii/users/add.json
     * Request = {"role_id":2,"name":"jenis","email":"jenishfdcf@gmail.com","school_name":"vidhya vihar sankul","school_email":"developer.laravel@gmail.com","password":"123456","profile_image":"abcd.png","register_type":"1"}
     * Responce = { "user": { "email": "user1@gmail.com", "firstname": "user1", "lastname": "user1", "api_plain_key": "e9b70cfb3e3b433cefc45bbd656d27e27a12c3cb", "api_key": "$2y$10$w20tmh1ObiqtSF3tdFk73uk\/gsjjoQ52LEaZFCtoh928UqDhC\/60W", "role_id": 4, "unique_code": "0317", "created_by": 1, "modified_by": 1, "created": "2017-03-21T06:12:36", "modified": "2017-03-21T06:12:36", "id": 5, "status": 1, "message": "The user has been saved." } }
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        if ($this->request->is('post'))
        {  
            $request = $this->request->data;
          

            $school = $this->ApiHttpRequest->sendRequest($request);
            //echo "<pre>"; print_r($user); exit();
            if($school->code == 200)
            { 
                $this->Flash->success(__($school->message));
                $this->redirect(BASE_URL.'schools');
            }
            else if($school->code == 100)
            { 
                $this->Flash->success(__($school->message));
            }
            else if($school->code == 400)
            { 
                $this->Flash->error(__($school->message));
                $this->redirect(BASE_URL.'schools/add');
            }
            else
            {  
                $this->Flash->success(__($school->message));
            }
        }
       
        $this->set(compact('user'));
        $this->set('_serialize', ['user']);
    }

    /**
     * Edit method
     * URL : 192.168.0.133/bankii/api_bunkii/users/edit.json
     * Request = {"id":14,"name":"jenis","school_name":"rachna","password":"123456","profile_image":"abcd.png"}
     * Responce = { "code": 200, "url": "Users\/edit.json", "message": "The user has been edit.", "Users": { "id": 14, "role_id": 2, "name": "jenis", "email": "erertertret@gmail.com", "school_name": "rachna", "school_email": "rrrrrr@gmail.com", "api_plain_key": "ceea6e6baf5f553e529b0893467147f419f047af", "api_key": "$2y$10$56pBAR5oSGMlG9H9iPZzz.9exRVP\/M6QDNdrAQH.3RVLd3a.0cowu", "profile_image": "abcd.png", "verification_code": "0512", "register_type": 1, "status": 0, "isDeleted": 0, "created": "2017-09-22T10:44:22", "modified": "2017-09-22T11:18:46" } }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        if ($this->request->is(['post']))
        {  
            $request = $this->request->data;
           
            if(!isset($request['status'])){ $request['status']=0;  }

            $school = $this->ApiHttpRequest->sendRequest($request);
            // echo "<pre>"; print_r($school->code); exit();
            $schools = $school->Schools;
            //echo "<pre>"; print_r($schools); exit();
            if($school->code == 200)
            {
                $this->Flash->success(__($school->message));
                $this->redirect(BASE_URL.'schools');
            }
            else
            {
                $this->Flash->success(__($school->message));
            }       
        }
        else
        {
            $params = array(            
                'conditions' => ['Schools.id'=>$id],
                'contain' => [],                      
                'fields' => array(),
                'select' => array(),
                'get' => 'all',
                'order' => array(),
                'page' => 1, 
                'limit' => 1
            );
            $school = $this->ApiHttpRequest->sendRequest($params,'editIndex');
            if($school->code == 200)
            { 
                $schools = $school->Schools[0];                
            }
            else
            {
                $this->Flash->success(__($school->message));
                $this->redirect(BASE_URL.'schools');
            }
        }
        $this->set(compact('schools'));
        $this->set('_serialize', ['schools']);
    }

    /**
     * Delete method
     * URL : 192.168.0.133/bankii/api_bunkii/users/delete.json
     * Request = {"id":"14"}
     * Responce = { "code": 200, "url": "Users\/delete.json", "message": "The user has been deleted.", "Users": { "id": 14, "role_id": 2, "name": "reterert", "email": "erertertret@gmail.com", "school_name": "vidhya vihar sankul", "school_email": "rrrrrr@gmail.com", "api_plain_key": "ceea6e6baf5f553e529b0893467147f419f047af", "api_key": "$2y$10$56pBAR5oSGMlG9H9iPZzz.9exRVP\/M6QDNdrAQH.3RVLd3a.0cowu", "profile_image": "abcd.png", "verification_code": "0512", "register_type": 1, "status": 0, "isDeleted": 1, "created": "2017-09-22T10:44:22", "modified": "2017-09-22T11:09:11" } }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $params = array('id' => $id);
        $schools = $this->ApiHttpRequest->sendRequest($params);
        if ($schools->code == 200)
        {
            $this->Flash->success(__($schools->message));
        }
        else
        {
            $this->Flash->success(__($schools->message));
        }
        $this->redirect(BASE_URL.'schools');
    }

    /**
     * Active account method
     * URL : 
     * Request = {"ActivationCode":"####"}
     * Responce = 
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function activeAccount()
    {
        $ActivationCode = $this->request->params['pass'][0];
        $params = array('ActivationCode' => $ActivationCode);
        $user = $this->ApiHttpRequest->sendRequest($params,'activeAccount');
        if ($user->code == 200)
        {
            $this->Flash->success(__($user->message));
        }
        else
        {
            $this->Flash->success(__($user->message));
        }
        $this->viewBuilder()->layout('login_layout');
        $this->render('activeaccount');
    }

    /**
     * remove profile image
     * URL : 
     * Request = {"id":"####","imagename":"####"}
     * Responce = 
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function removeImage()
    {
        $request = $this->request->data;
        $params = array('id' => $request['id'],'imagename' => $request['imagename']);
        $school = $this->ApiHttpRequest->sendRequest($params,'removeImage');

        if($school->code == 200)
        {
            echo 1;exit;
        }
        else
        {
            echo 0;exit;
        }
    }
    
    /**
     * Create image url from view and edit files
     * URL : 
     * Request = 
     * Responce = 
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function makeimgurl()
    {
        $ImageName = $this->request->params['pass'][0];
        $Image = $this->ApiHttpRequest->getImageContent($ImageName,'collages');
        echo $Image;exit;
    }

    /*
    * Forgot password for admin
    URL:192.168.0.133/bankii/api_bunkii/users/forgotpassword.json
    Request = role_id , email
    */
    public function forgotpassword()
    {
        if ($this->request->is(['post']))
        {  
            $request = $this->request->data;
            $request['role_id'] = 1;
            $user = $this->ApiHttpRequest->sendRequest($request);
            $users = $user->Users;
            if($user->code == 200)
            {
                $this->Flash->success(__($user->message));
                $this->redirect(BASE_URL);
            }
            else
            {
                $this->Flash->success(__($user->message));
                $this->redirect(BASE_URL);
            }  
        }
    }

    /* Change Password for admin */
    /**
     * Delete method
     * URL : 192.168.0.133/bankii/api_bunkii/users/changePassword.json
     *  Request = {"id":"14","cur_password" : "123456","new_password":"abc"}
     * Responce = { "code": 200, "url": "Users\/delete.json", "message": "The user has been deleted.", "Users": { "id": 14, "role_id": 2, "name": "reterert", "email": "erertertret@gmail.com", "school_name": "vidhya vihar sankul", "school_email": "rrrrrr@gmail.com", "api_plain_key": "ceea6e6baf5f553e529b0893467147f419f047af", "api_key": "$2y$10$56pBAR5oSGMlG9H9iPZzz.9exRVP\/M6QDNdrAQH.3RVLd3a.0cowu", "profile_image": "abcd.png", "verification_code": "0512", "register_type": 1, "status": 0, "isDeleted": 1, "created": "2017-09-22T10:44:22", "modified": "2017-09-22T11:09:11" } }
     */
    public function changePassword($id = null)
    {
        if ($this->request->is(['post']))
        {  
            $request = $this->request->data;
            $user = $this->ApiHttpRequest->sendRequest($request);
            $users = $user->Users;
            if($user->code == 200)
            {
                $this->Flash->success(__($user->message));
                $this->redirect(BASE_URL.'users');
            }
            else
            {
                $this->Flash->success(__($user->message));
                $this->redirect(BASE_URL.'users/change-password/'.$request['id']);
            }  
        }
        else
        {
            $params = array(            
                'conditions' => ['Users.id'=>$id],
                'contain' => array(),
                'fields' => array(),
                'select' => array(),
                'get' => 'all',
                'order' => array(),
                'page' => 1, 
                'limit' => 1
            );
            $user = $this->ApiHttpRequest->sendRequest($params,'editIndex');
            if($user->code == 200)
            { 
                $users = $user->Users[0];                
            }
            else
            {
                $this->Flash->success(__($user->message));
                $this->redirect(BASE_URL.'users');
            }
        }
        $this->set(compact('users'));
        $this->set('_serialize', ['users']);
    }

    public function uploadcsv()
    {

      if ($this->request->is('post'))
        {  
            $request = $this->request->data;
           // echo "<pre>"; print_r($request["school_image_file"]["tmp_name"]); exit();
            $file =$request["school_image_file"]["tmp_name"];
            $handle = fopen($file, "r");
            $c =0;
            $flag = true;
            while(($filesop = fgetcsv($handle, 1000, ",")) !== false)
            {
              if($flag) { $flag = false; continue; }
              $name = $filesop[0];
              $address = $filesop[1];
              $email = $filesop[2];
              $web_address = $filesop[3];
              $school_image = $filesop[4];
           
              $params=array('name' =>$name,'address' =>$address,'email' =>$email,'web_address' =>$web_address,'school_image' =>$school_image);
            
              $school = $this->ApiHttpRequest->sendRequest($params);
          
              $c = $c + 1;
            }

           if($school->code == 200)
            { 
                $this->Flash->success(__("CSV file uploaded succesfully"));
                $this->redirect(BASE_URL.'schools');
            }
        }

    }

    public function uploadexcel()
    {
       
       if ($this->request->is('post'))
        {
           $request = $this->request->data;  
           
            $file=API_BASE_UPLOAD_PATH."school/".$request["school_xlsx_file"]; 
           
            $school = $this->PhpExcel->loadWorksheet($file);
            echo "<pre>"; print_r($school); exit();
        }
    }

}
