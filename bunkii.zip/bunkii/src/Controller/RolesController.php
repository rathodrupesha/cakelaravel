<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Validation\Validation;
use Cake\Event\Event;
use Cake\Datasource\ConnectionManager;
use App\View\Helper\DatatableHelper;


/**
 * Roles Controller
 *
 * @property \App\Model\Table\RolesTable $Roles
 */
class RolesController extends AppController
{

    public function beforeFilter(Event $event)
    {
        $this->Auth->allow(['']);
        parent::beforeFilter($event);
        $this->viewBuilder()->layout('default'); // Test Admin panel look
    }

    /**
     * Index method
     URL:http://localhost/api_cakedemo/users/changePassword.json
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
         $tableTh = array("ID","Role Name","Action");
        $request = $this->request->data;

        $deletei = ' class="btn btn-danger"><i class="fa fa-trash"></i>';
        $editi = ' class="btn btn-info"><i class="fa fa-edit"></i>';
        $viewi = ' class="btn btn-success"><i class="fa fa-eye"></i>';

        $deleteLink = "<a href='+BASE_URL+'roles/delete/'+id+' $deletei</a>";
        $EditLink = "<a href='+BASE_URL+'roles/edit/'+id+' $editi</a>";
        $ViewLink = "<a href='+BASE_URL+'roles/view/'+id+' $viewi</a>";

        $URL = "BASE_URL+'roles'";

        $scriptStr = "'columns':[{ 'data': 'id' },{ 'data': 'name' },{ 'data': 'id','sortable':false,'render':function (id, type, full, meta){ return '$ViewLink  $EditLink $deleteLink' } },],'processing': true,'serverSide': true,'ajax': {url: $URL,type: 'POST'}";

        if (!empty($request))
        {
            $modelName = $this->modelClass;
            $parameter['fields'] = array('id','name');
            $parameter['conditions'] = array('Roles.isDeleted' => 0);
            $parameter['join'] = array();
            $result = $this->ApiHttpRequest->createAjaxTable($modelName,$request,$parameter);
            echo json_encode($result);exit;
        }
        $this->set(compact('tableTh','scriptStr'));

    }

    /**
     * View method
     *
     * @param string|null $id Role id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $params = array(            
            'conditions' => ['Roles.id'=>$id],
            'contain' => array(),
            'fields' => array(),
            'select' => array(),
            'get' => 'all',
            'order' => array(),
            'page' => 1, 
            'limit' => 1
        );
        $role = $this->ApiHttpRequest->sendRequest($params);
        $role = $role->Roles[0];
        $this->set('role', $role);
        $this->set('_serialize', ['role']);
    }

    /**
     * Add method
     * URL : http://localhost/Proximity-Attendance-app/roles/add.json
     * Request = {"name":"user1@gmail.com"}
     * Responce = { "code": 200, "url": "Roles\/add.json", "message": "The role name has been saved.", "Roles": { "name": "test", "created": "2017-03-24T12:03:33", "modified": "2017-03-24T12:03:33", "id": 8 } }
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        if ($this->request->is('post'))
        {  
            $request = $this->request->data;
            $role = $this->ApiHttpRequest->sendRequest($request);
            if($role->code == 200)
            {
                $this->Flash->success(__($role->message));
                $this->redirect(BASE_URL.'roles');
            }
            else if($role->code == 100)
            {
                $this->Flash->success(__($role->message));
            }
            else
            {
                 $this->Flash->success(__($role->message));
            }
        }
        $this->set(compact('role'));
        $this->set('_serialize', ['role']);
    }

    /**
     * Edit method
     * URL : http://localhost/Proximity-Attendance-app/roles/edit.json
     * Request = {"name":"test1","id":"8"}
     * Responce = { "code": 200, "url": "Roles\/edit.json", "message": "The role name has been edit.", "Roles": { "id": 8, "name": "test1", "status": 1, "isDeleted": 0, "created": "2017-03-24T12:03:33", "modified": "2017-03-24T12:05:12" } }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        if ($this->request->is(['post']))
        {  
            $request = $this->request->data;
            $role = $this->ApiHttpRequest->sendRequest($request);
            $roles = $role->Roles;
            if($role->code == 200)
            {
                $this->Flash->success(__($role->message));
                $this->redirect(BASE_URL.'roles');
            }
            elseif($role->code == 100)
            {
                $this->Flash->success(__($role->message));
                $this->redirect(BASE_URL.'roles');
            }
            else
            {
                $this->Flash->success(__($role->message));
            }       
        }
        else
        {
            $params = array(            
                'conditions' => ['Roles.id'=>$id],
                'contain' => array(),
                'fields' => array(),
                'select' => array(),
                'get' => 'all',
                'order' => array(),
                'page' => 1, 
                'limit' => 1
            );
            $role = $this->ApiHttpRequest->sendRequest($params,'editIndex');
            if($role->code == 200)
            { 
                $roles = $role->Roles[0];                
            }
            else
            {
                $this->Flash->success(__($role->message));
                $this->redirect(BASE_URL.'roles');
            }
        }
        $this->set(compact('roles'));
        $this->set('_serialize', ['roles']);
    }

    /**
     * Delete method
     * URL : http://localhost/Proximity-Attendance-app/roles/delete.json
     * Request = {"id":"5"}
     * Responce = { "code": 200, "url": "Roles\/delete.json", "message": "The role name has been deleted.", "Roles": { "id": 8, "name": "test1", "status": 1, "isDeleted": 1, "created": "2017-03-24T12:03:33", "modified": "2017-03-24T12:06:15" } }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $params = array('id' => $id);
        $role = $this->ApiHttpRequest->sendRequest($params);
        if ($role->code == 200)
        {
            $this->Flash->success(__($role->message));
        }
        else
        {
            $this->Flash->success(__($role->message));
        }
        $this->redirect(BASE_URL.'roles');
    }
}
