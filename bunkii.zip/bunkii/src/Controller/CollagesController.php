<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Validation\Validation;
use Cake\Event\Event;
use Cake\Datasource\ConnectionManager;
use App\View\Helper\DatatableHelper;
/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 */
class CollagesController extends AppController
{

    public function beforeFilter(Event $event) {
        $this->Auth->allow(['login','add','uploadImage','activeAccount','forgotpassword']);
        parent::beforeFilter($event);
        $this->viewBuilder()->layout('default'); // Admin panel layout
    }

    /**
     * Index method
       //
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
         
        $tableTh = array("Id","User Name","Title","Action");
        $request = $this->request->data;
        //echo "<pre>"; print_r($request); exit();
        $deletei = ' class="btn btn-danger"><i class="fa fa-trash"></i>';
        $editi = ' class="btn btn-info"><i class="fa fa-edit"></i>';
        $viewi = ' class="btn btn-success"><i class="fa fa-eye"></i>';

        $deleteLink = "<a href='+BASE_URL+'collages/delete/'+id+' $deletei</a>";
        $EditLink = "<a href='+BASE_URL+'collages/edit/'+id+' $editi</a>";
        $ViewLink = "<a href='+BASE_URL+'collages/view/'+id+' $viewi</a>";
        $URL = "BASE_URL+'collages'";
        
      
    
        $scriptStr = "'columns':[{ 'data': 'id' },{ 'data': 'user.name'},{ 'data': 'title' },{ 'data': 'id','sortable':false,'render':function (id, type, full, meta){ return '$ViewLink  $deleteLink' } },],'processing': true,'serverSide': true,'ajax': {url: $URL,type: 'POST'}";
 
        if (!empty($request))
        {
            $modelName = $this->modelClass;
            $parameter['fields'] = array('Collages.id','Users.name','Collages.title','Collages.collages_image');
            $parameter['conditions'] = array('Collages.isDeleted' => 0);
            $parameter['join'] = array('Users');

            // $parameter['fields'] = array('Collages.id','Collages.title','Collages.collages_image');
            // $parameter['conditions'] = array();
            // $parameter['join'] = array('Users');
            
            $result = $this->ApiHttpRequest->createAjaxTable($modelName,$request,$parameter);
            //echo "<pre>"; print_r($result); exit();
            echo json_encode($result);exit;
        }
        $this->set(compact('tableTh','scriptStr'));
    }
    


 

    
    public function view($id = null)
    {
        $params = array(            
            'conditions' => ['Collages.id'=>$id],
            'contain' => ['Users'],                      
            'fields' => array(),
            'select' => array(),
            'get' => 'all',
            'order' => array(),
            'page' => 1, 
            'limit' => 1
        );
        $collage = $this->ApiHttpRequest->sendRequest($params);
        $collages = $collage->Collages[0];
        $this->set('collages', $collages);
        $this->set('_serialize', ['collages']);
    }

    /**
     * Add method

     * URL : 192.168.0.133/bankii/api_bankii/users/add.json
     * Request = {"role_id":2,"name":"jenis","email":"jenishfdcf@gmail.com","school_name":"vidhya vihar sankul","school_email":"developer.laravel@gmail.com","password":"123456","profile_image":"abcd.png","register_type":"1"}
     * Responce = { "user": { "email": "user1@gmail.com", "firstname": "user1", "lastname": "user1", "api_plain_key": "e9b70cfb3e3b433cefc45bbd656d27e27a12c3cb", "api_key": "$2y$10$w20tmh1ObiqtSF3tdFk73uk\/gsjjoQ52LEaZFCtoh928UqDhC\/60W", "role_id": 4, "unique_code": "0317", "created_by": 1, "modified_by": 1, "created": "2017-03-21T06:12:36", "modified": "2017-03-21T06:12:36", "id": 5, "status": 1, "message": "The user has been saved." } }
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        if ($this->request->is('post'))
        {  
            $request = $this->request->data;
            $user = $this->ApiHttpRequest->sendRequest($request);
            //echo "<pre>"; print_r($user); exit();
            if($user->code == 200)
            { 
                $this->Flash->success(__($user->message));
                $this->redirect(BASE_URL.'users');
            }
            else if($user->code == 100)
            { 
                $this->Flash->success(__($user->message));
            }
            else
            {  
                $this->Flash->success(__($user->message));
            }
        }
        $roles = $this->ApiHttpRequest->sendRequest(array(),'getRoles');
        $roles = $roles->Users;
        $this->set(compact('user', 'roles'));
        $this->set('_serialize', ['user']);
    }

    /**
     * Edit method
     * URL : 192.168.0.133/bankii/api_bunkii/users/edit.json
     * Request = {"id":14,"name":"jenis","school_name":"rachna","password":"123456","profile_image":"abcd.png"}
     * Responce = { "code": 200, "url": "Users\/edit.json", "message": "The user has been edit.", "Users": { "id": 14, "role_id": 2, "name": "jenis", "email": "erertertret@gmail.com", "school_name": "rachna", "school_email": "rrrrrr@gmail.com", "api_plain_key": "ceea6e6baf5f553e529b0893467147f419f047af", "api_key": "$2y$10$56pBAR5oSGMlG9H9iPZzz.9exRVP\/M6QDNdrAQH.3RVLd3a.0cowu", "profile_image": "abcd.png", "verification_code": "0512", "register_type": 1, "status": 0, "isDeleted": 0, "created": "2017-09-22T10:44:22", "modified": "2017-09-22T11:18:46" } }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        if ($this->request->is(['post']))
        {  
            $request = $this->request->data;
            $user = $this->ApiHttpRequest->sendRequest($request);

            $users = $user->Users;
            if($user->code == 200)
            {
                $this->Flash->success(__($user->message));
                $this->redirect(BASE_URL.'users');
            }
            else
            {
                $this->Flash->success(__($user->message));
            }       
        }
        else
        {
            $params = array(            
                'conditions' => ['Users.id'=>$id],
                'contain' => ['Roles'],                      
                'fields' => array(),
                'select' => array(),
                'get' => 'all',
                'order' => array(),
                'page' => 1, 
                'limit' => 1
            );
            $user = $this->ApiHttpRequest->sendRequest($params,'editIndex');
            if($user->code == 200)
            { 
                $users = $user->Users[0];                
            }
            else
            {
                $this->Flash->success(__($user->message));
                $this->redirect(BASE_URL.'users');
            }
        }
        $roles = $this->ApiHttpRequest->sendRequest(array(),'getRoles');
        $roles = $roles->Users;
        $this->set(compact('users', 'roles'));
        $this->set('_serialize', ['users']);
    }

    /**
     * Delete method
     * URL : 192.168.0.133/bankii/api_bunkii/users/delete.json
     * Request = {"id":"14"}
     * Responce = { "code": 200, "url": "Users\/delete.json", "message": "The user has been deleted.", "Users": { "id": 14, "role_id": 2, "name": "reterert", "email": "erertertret@gmail.com", "school_name": "vidhya vihar sankul", "school_email": "rrrrrr@gmail.com", "api_plain_key": "ceea6e6baf5f553e529b0893467147f419f047af", "api_key": "$2y$10$56pBAR5oSGMlG9H9iPZzz.9exRVP\/M6QDNdrAQH.3RVLd3a.0cowu", "profile_image": "abcd.png", "verification_code": "0512", "register_type": 1, "status": 0, "isDeleted": 1, "created": "2017-09-22T10:44:22", "modified": "2017-09-22T11:09:11" } }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $params = array('id' => $id);
        $collages = $this->ApiHttpRequest->sendRequest($params);
        if ($collages->code == 200)
        {
            $this->Flash->success(__($collages->message));
        }
        else
        {
            $this->Flash->success(__($collages->message));
        }
        $this->redirect(BASE_URL.'collages');
    }

    /**
     * Active account method
     * URL : 
     * Request = {"ActivationCode":"####"}
     * Responce = 
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function activeAccount()
    {
        $ActivationCode = $this->request->params['pass'][0];
        $params = array('ActivationCode' => $ActivationCode);
        $user = $this->ApiHttpRequest->sendRequest($params,'activeAccount');
        if ($user->code == 200)
        {
            $this->Flash->success(__($user->message));
        }
        else
        {
            $this->Flash->success(__($user->message));
        }
        $this->viewBuilder()->layout('login_layout');
        $this->render('activeaccount');
    }

    /**
     * remove profile image
     * URL : 
     * Request = {"id":"####","imagename":"####"}
     * Responce = 
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function removeImage()
    {
        $request = $this->request->data;
        $params = array('id' => $request['id'],'imagename' => $request['imagename']);
        $user = $this->ApiHttpRequest->sendRequest($params,'removeImage');
        if($user->code == 200)
        {
            echo 1;exit;
        }
        else
        {
            echo 0;exit;
        }
    }
    
    /**
     * Create image url from view and edit files
     * URL : 
     * Request = 
     * Responce = 
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function makeimgurl()
    {
        $ImageName = $this->request->params['pass'][0];
        $Image = $this->ApiHttpRequest->getImageContent($ImageName,'collages');
        echo $Image;exit;
    }

    /*
    * Forgot password for admin
    URL:192.168.0.133/bankii/api_bunkii/users/forgotpassword.json
    Request = role_id , email
    */
    public function forgotpassword()
    {
        if ($this->request->is(['post']))
        {  
            $request = $this->request->data;
            $request['role_id'] = 1;
            $user = $this->ApiHttpRequest->sendRequest($request);
            $users = $user->Users;
            if($user->code == 200)
            {
                $this->Flash->success(__($user->message));
                $this->redirect(BASE_URL);
            }
            else
            {
                $this->Flash->success(__($user->message));
                $this->redirect(BASE_URL);
            }  
        }
    }

    /* Change Password for admin */
    /**
     * Delete method
     * URL : 192.168.0.133/bankii/api_bunkii/users/changePassword.json
     *  Request = {"id":"14","cur_password" : "123456","new_password":"abc"}
     * Responce = { "code": 200, "url": "Users\/delete.json", "message": "The user has been deleted.", "Users": { "id": 14, "role_id": 2, "name": "reterert", "email": "erertertret@gmail.com", "school_name": "vidhya vihar sankul", "school_email": "rrrrrr@gmail.com", "api_plain_key": "ceea6e6baf5f553e529b0893467147f419f047af", "api_key": "$2y$10$56pBAR5oSGMlG9H9iPZzz.9exRVP\/M6QDNdrAQH.3RVLd3a.0cowu", "profile_image": "abcd.png", "verification_code": "0512", "register_type": 1, "status": 0, "isDeleted": 1, "created": "2017-09-22T10:44:22", "modified": "2017-09-22T11:09:11" } }
     */
    public function changePassword($id = null)
    {
        if ($this->request->is(['post']))
        {  
            $request = $this->request->data;
            $user = $this->ApiHttpRequest->sendRequest($request);
            $users = $user->Users;
            if($user->code == 200)
            {
                $this->Flash->success(__($user->message));
                $this->redirect(BASE_URL.'users');
            }
            else
            {
                $this->Flash->success(__($user->message));
                $this->redirect(BASE_URL.'users/change-password/'.$request['id']);
            }  
        }
        else
        {
            $params = array(            
                'conditions' => ['Users.id'=>$id],
                'contain' => array(),
                'fields' => array(),
                'select' => array(),
                'get' => 'all',
                'order' => array(),
                'page' => 1, 
                'limit' => 1
            );
            $user = $this->ApiHttpRequest->sendRequest($params,'editIndex');
            if($user->code == 200)
            { 
                $users = $user->Users[0];                
            }
            else
            {
                $this->Flash->success(__($user->message));
                $this->redirect(BASE_URL.'users');
            }
        }
        $this->set(compact('users'));
        $this->set('_serialize', ['users']);
    }
}
