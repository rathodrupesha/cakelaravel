<?php

namespace App\Controller\Component;

use Cake\Controller\Component;
use Cake\Network\Http\Client;
use Cake\Core\Configure;
use Cake\Event\Event;

class ApiHttpRequestComponent extends Component {

    public $apiServerUrl;
    public $controllerName;
    public $actionName;
    public $apiActionUrl;
    public $requestData;
    public $components = array('RequestHandler', 'Auth');

    public function initialize(array $config)
    {
        //$this->Auth->allow(['sendRequest']);
        //$this->loadComponent(['RequestHandler','Auth']);
    }

    public function beforeFilter(Event $event)
    {
        // getting site_url, controller name & method
        $this->apiServerUrl = Configure::read("API_SITE_URL");
        $this->controllerName = $this->request->params['controller'];
        $this->actionName = $this->request->params['action'];
    }

    public function sendRequest($params = array(), $actionName = null)
    {
        // Which url to be called
        $api_map = Configure::read('map');
        $username = $password = "";
        if (!empty($this->Auth->user())) {
            $username = $this->Auth->user('email');
            $password = $this->Auth->user('api_plain_key');
        }
        // Overwrite actionName if given in argument(second)
		if($actionName) $this->actionName = $actionName;
        // creating request url
        $control_action = $api_map[$this->controllerName . '/' . $this->actionName];
        $this->apiActionUrl = $control_action . '.json';
        // pr($this->apiActionUrl); exit();
        // created httpClient object with configuration
        $httpClient = new Client([
            'host' => $this->apiServerUrl
            , 'scheme' => 'http'
            , 'auth' => ['type' => 'basic', 'username' => $username, 'password' => $password]
                ]
        );
        
        $requestData = $params;
        // echo "fd";pr($requestData); exit();
        $response = $httpClient->post($this->apiActionUrl, $requestData);
         //print_r($response->body); exit;
        return json_decode($response->body);        
    }

    public function getImageContent($ImageName,$folderName)
    {
        $ext = pathinfo($ImageName, PATHINFO_EXTENSION);
        $ImgPath = API_BASE_UPLOAD_PATH.$folderName.'/'.$ImageName;
        if($ext == 'jpg' || $ext == 'jpeg' || $ext == 'gif' || $ext == 'png'){
            $Image = file_get_contents($ImgPath);
            header("Content-type: image/".$ext);
        }else{
            $Image = file_get_contents($ImgPath);
            header("Content-type: image/jpeg");
        }
        return $Image;
    }

    public function createAjaxTable($modelName,$request,$parameter)
    {

        $draw = $request['draw'];
        $orderByColumnIndex  = $request['order'][0]['column'];
        $orderBy = $request['columns'][$orderByColumnIndex]['data'];
        $orderType = $request['order'][0]['dir']; 
        $start  = $request["start"];
        $length = $request['length'];

        $params = array(     
                'contain' => $parameter['join'],         
                'conditions' => [$parameter['conditions']],
                'fields' => ['total_count' => "count(".$modelName.".id)"],
                'get' => 'all',
            );

        
        $resCount = $this->sendRequest($params);
        //echo "<pre>"; print_r($resCount); exit();
        $recordsTotal = $resCount->{$modelName}[0]->total_count;
        
        if(!empty($request['search']['value']))
        {
            $search = $request['search']['value'];
            
            for($i = 0; $i < count($parameter['fields']); $i++)
            {
               $OR[$parameter['fields'][$i]." LIKE"] = "%".$search."%";
            }
            
            $params = array(      
                'conditions' => [$parameter['conditions'],"OR" => $OR],
                'contain' => $parameter['join'],    
                'fields' => ['total_count' => "count(".$modelName.".id)"],
                'get' => 'all',
            );

            $resSearchCou = $this->sendRequest($params);
            $recordsFiltered = $resSearchCou->{$modelName}[0]->total_count;
            
            $params= array(  
                    'conditions' => [$parameter['conditions'],"OR" => $OR],
                    'contain' => $parameter['join'],          
                    'order' => array($modelName.".".$orderBy => $orderType),
                    'limit' => $length,
                    'offset' => $start,
                    'get' => 'all'
                );
            $resSearch = $this->sendRequest($params);
            $data = $resSearch->{$modelName};
        }
        else
        {
            $params = array(            
                'conditions' => $parameter['conditions'],
                'contain' => $parameter['join'],                      
                'order' => array($modelName.".".$orderBy => $orderType),
                'limit' => $length,
                'offset' => $start,
                'get' => 'all'
            );
            
            $resultNormal = $this->sendRequest($params);
            $data = $resultNormal->{$modelName};
            $recordsFiltered = $recordsTotal;
        }

        $response = array(
            "draw" => intval($draw),
            "recordsTotal" => $recordsTotal,
            "recordsFiltered" => $recordsFiltered,
            "data" => $data
        );
        return $response;
    }

}
