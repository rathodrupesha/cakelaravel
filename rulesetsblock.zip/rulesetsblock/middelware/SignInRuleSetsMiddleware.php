<?php

namespace App\Http\Middleware;

use Closure;
use App\Models\RuleSets;
use App\Models\RuleFilters;
use App\Models\User;
use App\Models\UserBlockHistory;

use App\Http\Helpers\CommonTrait;
use App\Http\Helpers\ResponseTrait;

class SignInRuleSetsMiddleware
{
    use CommonTrait;
    use ResponseTrait;
    public function handleVerbDescription($paramName, $paramValue, $value1)
    {
        switch ($value1['verb_description']) {
            case 'CONTAINS':
                return $this->isContains($paramName, $paramValue, $value1);
            case 'DOES_NOT_CONTAIN':
                return $this->isDoesNotContain($paramName, $paramValue, $value1);
            case 'GREATER_THAN':
                return $this->isGreaterThan($paramName, $paramValue, $value1);
            case 'LESS_THAN':
                return $this->isLessThan($paramName, $paramValue, $value1);
            default:
                return false;
        }
    }

    /**
      * Check existence of specified input in $value.
      *
      * @param $value
      * @return bool
      */
    public function isContains($paramName, $paramValue, $value1)
    {
        // Test if string contains the word
        if (strpos($paramValue, $value1['specified_input']) !== false) {
            return 'pass'; //word found
        } else {
            return 'not_pass'; //word not found
        }
    }

    /**
     * Check absence of specified input in $value.
     *
     * @param $value
     * @return bool
     */
    public function isDoesNotContain($paramName, $paramValue, $value1)
    {
        // Test if string contains the word
        if (strpos($paramValue, $value1['specified_input']) !== false) {
            return 'not_pass'; //word found  opposit
        } else {
            return 'pass'; //word not found
        }
    }

    /**
     * Compare specified input with $value.
     *
     * @param $value
     * @return bool
     */
    public function isGreaterThan($paramName, $paramValue, $value1)
    {
        if ($value1['specified_input'] > $paramValue) {
            return 'pass';
        } else {
            return 'not_pass';
        }
    }

    /**
     * Compare specified input with $value.
     *
     * @param $value
     * @return bool
     */
    public function isLessThan($paramName, $paramValue, $value1)
    {
        if ($value1['specified_input'] < $paramValue) {
            return 'pass';
        } else {
            return 'not_pass';
        }
    }


    /**
     * Action handler.
     *
     * @param $userId
     * @return bool
     */
    protected function handleAction($email, $value1): bool
    {
        switch ($value1['action']) {
            case 'BLOCK':
                $user = User::findByEmailOrUserName($email);

                if ($user) {
                    //Do inactive or block the user
                    $userData=User::updateByEmailOrUserName($email);

                    //keep history with reason
                    $reason=$value1['item_name'].' is '.$value1['verb_description'].' the value '.$value1['specified_input'];
                    $blockData=array('user_id'=>$user->id,'rule_sets_id'=>$value1['rule_sets_id'],'rule_filters_id'=>$value1['id'],'on_action'=>'sign_in','reason'=>$reason);
                    UserBlockHistory::createUserBlockHistory($blockData);
                }
                return true;
            case 'BANNED':
                $user = User::findByEmailOrUserName($email);

                if ($user) {
                    //Do inactive or block the user
                    $userData=User::updateByEmailOrUserName($email);

                    //keep history with reason
                    $reason=$value1['item_name'].' is '.$value1['verb_description'].' the value '.$value1['specified_input'];
                    $blockData=array('user_id'=>$user->id,'rule_sets_id'=>$value1['rule_sets_id'],'rule_filters_id'=>$value1['id'],'on_action'=>'sign_in','reason'=>$reason);
                    UserBlockHistory::createUserBlockHistory($blockData);
                }
                return true;
                return true;
            case 'NOTHING':
                return true;
            default:
                return false;
        }
    }

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $requestData=$request->all();
        $onActionArray=array(2,3);

        //First check for is rule set for signup
        $isApplicable=RuleSets::isApplicable($onActionArray);

        if ($isApplicable>0) {
            $idArray=array();
            $getIds=RuleSets::getIds($onActionArray);

            foreach ($getIds as $value) {
                array_push($idArray, $value['id']);
            }

            foreach ($requestData as $key=>$value) {
                $paramName=$key;
                $paramValue=$value;

                $AllParamsRules=RuleFilters::getAllFilterForParticualrParam($idArray, $paramName);

                if (!empty($AllParamsRules)) {

                    //if rules set for req param then here check for is it comply the rules
                    foreach ($AllParamsRules as $key1 => $value1) {
                        $result=$this->handleVerbDescription($paramName, $paramValue, $value1);

                        //Here pass means making condition true & if true then fire action
                        if ($result=='pass') {

                           //we have only 2 action BLOCK & NOTHING
                            //if signin then block means not to do signin & for signin do user inactive for block
                            if ($value1['action']=='BLOCK') {
                                $this->handleAction($requestData['email_username'], $value1);
                                return $this->error('RULE_BLOCK', 404);
                            //$this->handleAction($paramName, $paramValue, $value1);
                            } else {
                                //nothing to do & goes forwars for signin..
                            }
                        }
                    }
                }//not empty
                exit;
            }//req data for each
        }//isApplicable
        return $next($request);
    }
}
