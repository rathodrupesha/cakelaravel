<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRuleFiltersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('rule_filters', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('rule_sets_id')->unsigned();
            $table->string('item_name')->nullable();
            $table->string('verb_description')->nullable();
            $table->string('contains')->nullable();
            $table->string('specified_input')->nullable();
            $table->string('time_frame')->nullable();
            $table->string('action')->nullable();
            $table->string('notification')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('rule_filters');
    }
}
