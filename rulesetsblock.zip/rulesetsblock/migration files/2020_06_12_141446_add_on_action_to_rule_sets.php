<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddOnActionToRuleSets extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('rule_sets', function (Blueprint $table) {
            $table->integer('on_action')->default(0)->comment('0: nothing; 1: singup; 2:signin, 3:both');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('rule_sets', function (Blueprint $table) {
            $table->dropColumn('on_action');
        });
    }
}
