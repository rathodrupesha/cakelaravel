<?php

return [
    'IP_ADDRESS'        => new \BitcoinBabe\Repositories\Rules\Filters\IpAddress(),
    'IP_LOCATION'       => new \BitcoinBabe\Repositories\Rules\Filters\IpLocation(),
    'EMAIL'             => new \BitcoinBabe\Repositories\Rules\Filters\Email(),
    'PHONE_NUMBER'      => new \BitcoinBabe\Repositories\Rules\Filters\PhoneNumber(),
    'FIRST_NAME'        => new \BitcoinBabe\Repositories\Rules\Filters\FirstName(),
    'MIDDLE_NAME'       => new \BitcoinBabe\Repositories\Rules\Filters\MiddleName(),
    'LAST_NAME'         => new \BitcoinBabe\Repositories\Rules\Filters\LastName(),
    'DOB'               => new \BitcoinBabe\Repositories\Rules\Filters\Dob(),
    'AGE'               => new \BitcoinBabe\Repositories\Rules\Filters\Age(),
    'AMOUNT_FUNDED'     => new \BitcoinBabe\Repositories\Rules\Filters\AmountFunded(),
    'AMOUNT_BOUGHT'     => new \BitcoinBabe\Repositories\Rules\Filters\AmountBought(),
    'AMOUNT_SOLD'       => new \BitcoinBabe\Repositories\Rules\Filters\AmountSold(),
    'FLEXEPIN_FUNDED'   => new \BitcoinBabe\Repositories\Rules\Filters\FlexepinFunded(),
    'SECONDARY_EMAIL'   => new \BitcoinBabe\Repositories\Rules\Filters\SecondaryEmail(),
    'SECONDARY_NUMBER'  => new \BitcoinBabe\Repositories\Rules\Filters\SecondaryNumber(),
    'WALLET'            => new \BitcoinBabe\Repositories\Rules\Filters\Wallets(),
    'NAMEPLUSDOB'       => new \BitcoinBabe\Repositories\Rules\Filters\NameplusDOB(), 
    'BANKNUMBER'        => new \BitcoinBabe\Repositories\Rules\Filters\BankAccountNumber(),
    'PHYSICALADDRESS'   => new \BitcoinBabe\Repositories\Rules\Filters\Address(),
];