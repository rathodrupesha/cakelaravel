-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 15, 2020 at 07:35 PM
-- Server version: 5.7.29-0ubuntu0.16.04.1
-- PHP Version: 7.1.33-16+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `baselumen`
--

-- --------------------------------------------------------

--
-- Table structure for table `rule_sets`
--

CREATE TABLE `rule_sets` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filters` text COLLATE utf8_unicode_ci,
  `description` text COLLATE utf8_unicode_ci,
  `times_triggered` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) DEFAULT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '1',
  `triggered_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `on_action` int(11) NOT NULL DEFAULT '0' COMMENT '0: nothing; 1: singup; 2:signin, 3:both'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `rule_sets`
--

INSERT INTO `rule_sets` (`id`, `name`, `filters`, `description`, `times_triggered`, `priority`, `active`, `triggered_at`, `created_at`, `updated_at`, `on_action`) VALUES
(12, 'email validation', '[{\"item_name\":\"email\",\"verb_description\":\"CONTAINS\",\"specified_input\":\"rupesh@gmail.com\",\"time_frame\":\"any time\",\"action\":\"BANNED\",\"notification\":\"NOTIFY\"}]', 'ad', 0, 1, 1, NULL, '2020-06-12 12:10:33', '2020-06-12 12:10:33', 2),
(15, 'first name validation', '[{\"item_name\":\"first_name\",\"verb_description\":\"CONTAINS\",\"specified_input\":\"rupesh\",\"time_frame\":\"any time\",\"action\":\"BLOCK\",\"notification\":\"NOTIFY\"}]\n', 'fist name evalidation rule set', 0, 1, 0, NULL, '2020-06-15 09:34:23', '2020-06-15 09:34:23', 1),
(16, 'phone numr bevalidation', '[{\"item_name\":\"phone_number\",\"verb_description\":\"CONTAINS\",\"specified_input\":\"079\",\"time_frame\":\"any time\",\"action\":\"BLOCK\",\"notification\":\"NOTIFY\"}]\n                ', 'phone nubmer  evalidation rule set', 0, 1, 0, NULL, '2020-06-15 09:42:38', '2020-06-15 09:42:38', 1),
(17, 'Email bevalidation', '[{\"item_name\":\"email\",\"verb_description\":\"CONTAINS\",\"specified_input\":\"yopmail\",\"time_frame\":\"any time\",\"action\":\"BLOCK\",\"notification\":\"NOTIFY\"}]', 'Email  evalidation rule set', 0, 1, 1, NULL, '2020-06-15 09:44:32', '2020-06-15 09:44:32', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `rule_sets`
--
ALTER TABLE `rule_sets`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `rule_sets`
--
ALTER TABLE `rule_sets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
