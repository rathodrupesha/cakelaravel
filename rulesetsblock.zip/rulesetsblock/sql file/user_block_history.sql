-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 15, 2020 at 07:36 PM
-- Server version: 5.7.29-0ubuntu0.16.04.1
-- PHP Version: 7.1.33-16+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `baselumen`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_block_history`
--

CREATE TABLE `user_block_history` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `rule_sets_id` int(11) DEFAULT NULL,
  `rule_filters_id` int(11) DEFAULT NULL,
  `uuid` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on_action` varchar(191) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reason` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_block_history`
--

INSERT INTO `user_block_history` (`id`, `user_id`, `rule_sets_id`, `rule_filters_id`, `uuid`, `on_action`, `reason`, `created_at`, `updated_at`) VALUES
(1, 3, 17, 14, 'd093a57d-5e08-4ecc-9993-c2aa37aa46e1', 'sign_in', 'email_username is CONTAINS the value riya', '2020-06-15 12:21:36', '2020-06-15 12:21:36'),
(2, 3, 17, 14, '0ed2f04e-d2ef-4fdc-b397-588f4f57b89f', 'sign_in', 'email_username is CONTAINS the value riya', '2020-06-15 12:58:42', '2020-06-15 12:58:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user_block_history`
--
ALTER TABLE `user_block_history`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user_block_history`
--
ALTER TABLE `user_block_history`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
