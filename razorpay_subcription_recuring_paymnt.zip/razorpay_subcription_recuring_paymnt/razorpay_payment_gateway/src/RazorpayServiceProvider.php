<?php

namespace BVIPackage\RazorpayPaymentGateway;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Route;

class RazorpayServiceProvider extends ServiceProvider
{

    /**
     * This will be used to register configuration
     *
     * @var  string
     */
    protected $packageName = 'razorpay_payment_gateway';

    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function boot()
    {
        // Regiter migrations
        $this->loadMigrationsFrom(__DIR__ . '/database/migrations');

        // Publish your config
        $this->publishes(
            [__DIR__ . '/config/razorpayConfig.php' => config_path($this->packageName . '.php')],
            'config'
        );
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {

        // Merge config file
        if (file_exists(base_path() . '/config/razorpayConfig.php')) {
            $this->mergeConfigFrom(base_path() . '/config/razorpayConfig.php', $this->packageName);
        } else {
            $this->mergeConfigFrom(__DIR__ . '/config/razorpayConfig.php', $this->packageName);
        }

        // Load routes
        Route::group(['prefix' => 'api'], function ($router) {
            // By default, use the routes file provided in vendor
            $routeFilePathInUse = __DIR__ . '/routes/routes.php';

            // but if there's a file with the same name in routes/backpack, use that one
            $configPath = base_path() . '/config/razorpayConfig.php';
            $routePath = base_path() . '/routes/razorpayConfig.php';
            if (file_exists($configPath) && file_exists($routePath)) {
                $routeFilePathInUse = base_path() . '/routes/razorpayConfig.php';
            }

            require $routeFilePathInUse;
        });

        $this->app->make('BVIPackage\RazorpayPaymentGateway\RazorpayController');
    }
}
