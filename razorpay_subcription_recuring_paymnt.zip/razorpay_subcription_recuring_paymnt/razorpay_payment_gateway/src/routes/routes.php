<?php
/*
  |--------------------------------------------------------------------------
  | Application Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register routes for banner module
  |
 */
//http://localhost/lumen-lts_current/public/api/razorpay/list
$router->group(['prefix' => 'razorpay'], function ($router) {
    // Suggestion
    $router->post('webhook', ['as' => 'rpay.webhook', 'uses' => 'BVIPackage\RazorpayPaymentGateway\RazorpayController@webHookOfRazorpay']);
});
