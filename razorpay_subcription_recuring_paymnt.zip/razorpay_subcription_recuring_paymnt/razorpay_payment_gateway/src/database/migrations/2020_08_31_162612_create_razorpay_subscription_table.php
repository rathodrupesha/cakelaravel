<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRazorpaySubscriptionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('razorpay_subscription', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('user_id')->unsigned();
            $table->integer('subscription_plan_id')->unsigned();
            $table->string('plan_id');
            $table->string('subcription_id');
            $table->string('short_url');
            $table->string('charge_at');
            $table->string('start_at');
            $table->string('end_at');
            $table->string('total_count');
            $table->string('paid_count');
            $table->string('customer_notify');
            $table->string('subscription_created_at');
            $table->string('remaining_count');
            $table->timestamps();

            $table->foreign('subscription_plan_id')->references('id')
             ->on('subscription_plans')
             ->onDelete('cascade')
             ->onUpdate('cascade');

            $table->foreign('user_id')->references('id')
             ->on('users');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('razorpay_subscription');
    }
}
