<?php

namespace BVIPackage\RazorpayPaymentGateway;

class RazorpayPackage
{
    public function __construct()
    {
        //
    }
}
