<?php

namespace BVIPackage\RazorpayPaymentGateway;

use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Validator;
use Carbon\Carbon;
use App\Http\Helpers\CommonTrait;
use DB;
use Razorpay\Api\Api;
use App\Models\SubscriptionHistory;
use App\Models\Transaction;
use App\Models\RazorpaySubscription;

/**
 * Razorpay Module Controller
 * @author Brainvire Inc.
 * @link https://www.brainvire.com/
 */
class RazorpayController extends Controller
{
    use CommonTrait;

    /**
    * api
    * $api
    */
    public $api;
    /**
     * Create a new controller instance.
     */
    public function __construct()
    {
        $this->api = new Api(env('razorpay_api_key'), env('razorpay_api_secret'));
    }
    /**
    * purpose Create Plan in razorpay
    * @param array $data
    * @author Brainvire Inc. <https://www.brainvire.com/>
    * @return string
    */
    public function createRazorpayPlan(array $data):string
    {
        switch ($data['validity']) {
            case 'month':
                $period='monthly';
                break;
            case 'year':
                $period='yearly';
                break;
            case 'week':
                $period='weekly';
                break;

            default:
                $period='monthly';
        }
        $plan = $this->api->plan->create(
            array(
                                  'period' => $period,
                                  'interval' => 1,
                                  'item' => array(
                                    'name' => $data['name'],
                                    'description' => $data['description'],
                                    'amount' =>$data['price'],
                                    'currency' => 'INR'
                                    )
                                  )
        );
        return isset($plan)?$plan->id:'';
    }

    /**
     * purpose Create subscription in razorpay
     * @param int $planId
     * @author Brainvire Inc. <https://www.brainvire.com/>
     * @return json
     */

    public function createRazorpaySubscription(string $planId):array
    {
        $subscription  = $this->api->subscription->create(
            array(
            'plan_id' =>$planId,
            'customer_notify' => 1,
            'total_count' => 6,
            'start_at' => strtotime("tomorrow") + rand(0, 86400)
            )
        );
        if (isset($subscription)) {
            $data=array(
                'plan_id'=>$subscription->plan_id,
                'subcription_id'=>$subscription->id,
                'short_url'=>$subscription->short_url,
                'charge_at'=>$subscription->charge_at,
                'start_at'=>$subscription->start_at,
                'end_at'=>$subscription->end_at,
                'total_count'=>$subscription->total_count,
                'paid_count'=>$subscription->paid_count,
                'customer_notify'=>$subscription->customer_notify,
                'subscription_created_at'=>$subscription->created_at,
                'remaining_count'=>$subscription->remaining_count,
            );
            return $data;
        } else {
            return array();
        }
    }
    /**
     * purpose Webhook in razorpay for feching event
     * @param  $request
     * @author Brainvire Inc. <https://www.brainvire.com/>
     * @return json
     */
    public function webHookOfRazorpay(Request $request)
    {
        $sampleResponse='';
        $json = !empty(file_get_contents('php://input'))?file_get_contents('php://input'):$sampleResponse;
        $sampleArray=json_decode($json, true);
        $path=public_path().'/razorpay_webhook_response';
        $reportFileName=$path.'/'.date('Y-m-d').'_'.rand().'.txt';
        //Create directory if not exists
        if (!file_exists($path)) {
            mkdir($path);
            chmod($path, 0755);
        }
        //Create file if not exists
        if (!is_file($reportFileName)) {
            chmod($path, 0755);
            file_put_contents($reportFileName, $json, FILE_APPEND);
            chmod($reportFileName, 0777);
        } else {
            //Write file in new file
            $handle = fopen($reportFileName, "a+");
            $numbytes = fwrite($handle, PHP_EOL.PHP_EOL.PHP_EOL.$json);
            chmod($reportFileName, 0777);
        }
        if (isset($sampleArray['event']) && $sampleArray['event']=='subscription.charged') {
            $userId=RazorpaySubscription::getUserId($sampleArray);
            $subcriptionId=$sampleArray['payload']['subscription']['entity']['id'];
            $sampleArray['user_id']=$userId;
            $orderHistoryId=SubscriptionHistory::createOrderHistory($sampleArray);

            if (!empty($orderHistoryId)) {
                Transaction::createTransaction($orderHistoryId, $sampleArray);
            }
        }
    }
}
