<?php

namespace BVIPackage\RazorpayPaymentGateway;

use Laravel\Lumen\Routing\Controller as BaseController;
use BVIPackage\Banner\ResponseTrait;

/**
 * Category Module Parent Controller
 * @author Brainvire Inc.
 * @link https://www.brainvire.com/
 */
class Controller extends BaseController
{
    use ResponseTrait;
}
