<?php

use BVIPackage\Banner\Banner;

class BannerTest extends TestCase
{
    public $header;
    
    /**
     *@test
     */
    public function setUp()
    {
        parent::setUp();
        
        $this->header = ['Accept' => 'application/json'];
        $response = $this->call('POST', 'api/v1/oauth/signin', [
            'email'  => 'nikunjkumar.kabariya@brainvire.com',
            'password'  => 'admin123',
            'role'  => 'ADMIN'
            ], [], [], $this->header);
        if ($response->status() == 200) {
            $token  = json_decode($response->getContent())->data->access_token;
            $this->header['HTTP_Authorization'] = 'Bearer '.$token;
        }
        $this->assertEquals(200, $response->status());
    }
}
