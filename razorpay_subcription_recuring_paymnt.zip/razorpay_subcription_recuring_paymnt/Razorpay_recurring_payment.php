
Razorpay recurring payment
=============================

URl:www.razorpay.com
-goes on login (comman account for test/live mode)
-credentials:
  rupesh.rathod@brainvire.com (used for developing)
  Brain@2019

DOCUMENT :- https://razorpay.com/docs/payment-gateway/server-integration/php/usage/

"razorpay/razorpay": "2.*",

FLOW:
-----
1.You create a plan by calling api with pass parameter type equal to razorpay.
2.edit/delete plan api is not provided by razorpay.(Already discussed)
3.For frontend, call api for get all razorpay plan
4.Select plan & call the api for create subcription by passing type & plan id  params.
5.from backend on base of type & plan id create subcription & retuning the subscription short url to frontend also save created subcrtion details with plan_id & user_id(that is used when webhook called & dump the order data).
6.The customer click the link and is taken to the Razorpay Checkout form.
The customer enters the card details and clicks Pay to make the payment. This acts as an authentication transaction and on a successful payment, a customer is created and linked to the subscription
Automated charges on the subscription are now made as per the schedule defined by you while creating the plan.
7.By creating & setting webhook, we will get the payment transaction payload & save it in our db.

Webhook
https://razorpay.com/docs/webhooks/payloads/
subcription.charged & cancelled method used for getting all transaction data.

Note: only public url webhook set, can't set localhost url as webhook.
      so test webhook by this steps : https://razorpay.com/docs/webhooks/#test-webhooks

Do payment by this account
gulammustufa.momin@brainvire.com
Brain@2019

FOR RAZORPAY
SMS  +380 uk
https://sms.freeje.com/#sms-block
Master card
5104 0600 0000 0008

Step to do payment & start subcription
-run the short url
-enter email (email of gulam) & above cell num & card num.
-Firstly call the subscription.authenticated event
-Goes in to console & click on subscription id then open window on left
-Click on  "Charge this for now" button
-so subscription.charged event called & get response in webhook url
-for sample response see doc :https://razorpay.com/docs/webhooks/payloads/







