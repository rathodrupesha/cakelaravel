<?php

namespace App\Http\Controllers\Front\Api\V1;

use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Validator;
use App\Http\Helpers\CommonTrait;
use App\Http\Helpers\UploadImageTrait;
use App\Http\Helpers\PostTrait;
use DB;
use App\Models\Contact;
use Illuminate\Support\Facades\File;
use App\Events\Elastica;
use App\Models\PostSearch\SearchRBPost;
use Illuminate\Http\JsonResponse;
use DateTime;
use DrewM\MailChimp\MailChimp; //LARAVEL PACKAGE : https://github.com/drewm/mailchimp-api
use Newsletter;

/**
 * Contact Controller
 * User, can create contact list
 *
 * @author Brainvire Inc.
 * @link   https://www.brainvire.com/
 */

class MailchimpListController extends Controller
{

    use CommonTrait, PostTrait;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->currentUser = app('auth')->guard()->user();
    }

    /**
     * @purpose Create Contact
     * @param   request $request
     * @return  String \Illuminate\Http\Response
     */
    public function createList(Request $request)
    {
        $MailChimp = new MailChimp(env('MAILCHIMP_APIKEY'));
        try {
            $api_param = [
                'name'                => $request->name,
                'contact'             => [
                    'company'  => $request->company,
                    'address1' => '',
                    'address2' => '',
                    'city'     => '',
                    'state'    => '',
                    'zip'      => '',
                    'country'  => ''
                ],
                'permission_reminder' => $request->permission_reminder,
                'campaign_defaults'   => [
                    'from_name'  => $request->from_name,
                    'from_email' => $request->from_email,
                    'subject'    => $request->subject,
                    'language'   => $request->language
                ],
                'email_type_option'   => (bool) $request->email_type_option
            ];
            $result = $MailChimp->post("/lists", $api_param);
            if ($MailChimp->success()) {
                return $this->success([], 'Details Updated successfully', 201, $this->setLangCode());
            } else {
                return response($result, 400);
            }
        } catch (\Exception $exp) {
            return $this->error('ERROR', 422, $this->setLangCode(), $exp);
        }
    }

    /**
     * @purpose Get audience list from a list
     * @param   request $request
     * @return  String \Illuminate\Http\Response
     */
    public function getAudienceList()
    {
        try {
            $list_id = env('MAILCHIMP_LIST_ID');
            $MailChimp = new MailChimp(env('MAILCHIMP_APIKEY'));
            $result = $MailChimp->get("lists/$list_id/members");
            if ($MailChimp->success()) {
                return $this->success($result, 'List of Audience', 201, $this->setLangCode());
            } else {
                return response($result, 400);
            }
        } catch (Exception $exp) {
            return response()->json('ERROR', 422, $this->setLangCode());
        }
    }

    /**
     * @purpose Add user into mailchimp
     * @param   request $request
     * @return  String \Illuminate\Http\Response
     */
    public function subscribeUser(Request $request)
    {
        $validation = Validator::make($request->all(), config('validations.mailchimp_subscribe'));
        if ($validation->fails()) {
            return $this->validationError($validation);
        }
        try {
            $list_id = env('MAILCHIMP_LIST_ID');
            $MailChimp = new MailChimp(env('MAILCHIMP_APIKEY'));
            $api_param = [
                'email_address' => $request->email,
                'merge_fields'  => ['FNAME' => $request->fname, 'LNAME' => $request->lname],
                'status'        => $request->status,
                'tags'          => ([$request->tags]) ? [$request->tags] : ''
            ];
            $result = $MailChimp->post("lists/$list_id/members", $api_param);

            if ($MailChimp->success()) {
                return $this->success($result, 'Email Subscribed', 201, $this->setLangCode());
            } else {
                return response($result, 400);
            }
        } catch (Exception $e) {
            return ['status' => false, 'message' => $e->getMessage()];
        }
    }

    /**
     * @purpose Update audience details
     * @param   request $request
     * @return  String \Illuminate\Http\Response
     */
    public function updateSubscriberDetail(Request $request)
    {
        $validation = Validator::make($request->all(), config('validations.mailchimp_update'));
        if ($validation->fails()) {
            return $this->validationError($validation);
        }
        try {
            $list_id = env('MAILCHIMP_LIST_ID');
            $MailChimp = new MailChimp(env('MAILCHIMP_APIKEY'));
            $subscriber_hash = MailChimp::subscriberHash($request->email);
            $api_param = [
                'merge_fields' => ['FNAME' => $request->fname, 'LNAME' => $request->lname]
            ];
            $result = $MailChimp->patch("lists/$list_id/members/$subscriber_hash", $api_param);

            if ($MailChimp->success()) {
                return $this->success([], 'Details Updated successfully', 201, $this->setLangCode());
            } else {
                return response($result, 400);
            }
        } catch (Exception $e) {
            return $this->error('ERROR', 422, $this->setLangCode());
        }
    }

    /**
     * @purpose Delete audience from the list
     * @param   request $request
     * @return  String \Illuminate\Http\Response
     */
    public function removeSubscriber(Request $request)
    {
        $validation = Validator::make($request->all(), config('validations.mailchimp_delete'));
        if ($validation->fails()) {
            return $this->validationError($validation);
        }
        try {
            $list_id = env('MAILCHIMP_LIST_ID');
            $MailChimp = new MailChimp(env('MAILCHIMP_APIKEY'));
            $subscriber_hash = $MailChimp->subscriberHash($request->email);
            $result = $MailChimp->delete("lists/$list_id/members/$subscriber_hash");

            if ($MailChimp->success()) {
                return $this->success([], 'Subscriber Removed Successfully', 201, $this->setLangCode());
            } else {
                return response($result, 400);
            }
        } catch (Exception $e) {
            return $this->error('ERROR', 422, $this->setLangCode());
        }
    }
}
