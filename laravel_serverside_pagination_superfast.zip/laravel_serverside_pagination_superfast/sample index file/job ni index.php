@extends('back.layout.master')
@section('page_css')
<link href="{{URL::asset('assets/back/css/daterangepicker.css')}}" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="{{URL::asset('assets/back/vendors/datatables/css/dataTables.bootstrap.css')}}">

<!-- SLider -->
<!--Plugin CSS file with desired skin-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ion-rangeslider/2.3.0/css/ion.rangeSlider.min.css"/>


<style type="text/css">
  input[type=number]::-webkit-inner-spin-button, 
  input[type=number]::-webkit-outer-spin-button { 
  -webkit-appearance: none; 
    margin: 0; 
  }
   input[type=number] {
      -moz-appearance:textfield;
        }
div.table-responsive > div.dataTables_wrapper > div.row {
    margin-right: -15px;
    margin-left: -15px;
}
.table-scroll .col-sm-12{
  padding: 0;
  width: 100%;
  overflow: auto;
}
</style>
@stop
@section('content')
@section('title',"Jobs")

<!-- Loader -->
 <div id="page_loader" style="display: none;">
      <i class="fa-li fa fa-spinner fa-spin fa-3x"></i>
  </div>

<section class="content-header">

  <h1>{{trans('messages.jobs.jobs')}}
  </h1>
  <div class="add_new_user">
    <!-- <a href="{{ url('/admin/user/create') }}" class="btn btn-sm btn-primary"><span class="glyphicon glyphicon-plus"></span> {{trans('messages.users_management.create_user')}}</a> -->
  </div>
  <ol class="breadcrumb">
    <li class="">
      <i class="fa fa-newspaper-o"></i>
      </i>
      {{trans('messages.jobs.jobs')}}
    </li>
  </ol>

</section>
<section class="content">
  <div class="row">
    <div class="col-lg-12">
      <div class="panel panel-primary filterable">
        @if ($message = Session::get('success'))
        <div class="alert alert-success alert-block laravel-flash">
          <button type="button" class="close" data-dismiss="alert">×
          </button> 
          <strong>{{ $message }}
          </strong>
        </div>
        @endif
        
        <!-- for delete record -->
        <div class="alert alert-success remove_from_job_msg" style="display: none">
          <strong>Success!
          </strong> Tile designer has been removed successfully from job.
        </div>
        <div class="alert alert-success takeup-success-msg" style="display: none">
          <strong>Success!
          </strong> Job take up Successfully  Done.
        </div>
        <div class="alert alert-danger blacklist-error-msg" style="display: none">
          <strong> Access denied by Admin to take up this job for you.
          </strong>
        </div>
        <div class="alert alert-danger restriction-error-msg" style="display: none">
          <strong> You have already reach at maximum takeup limit.
          </strong> 
        </div>
        </br>
      <div class="panel-body table-responsive">
        <div class="well well-sm ">
          <div class="row">
            <div class="col-md-4">
              <label class="wdthfull">{{(\Auth::user()->user_type==2)?'Select Status':'Select Date'}}</label>
              <div class="input-group">
                <?php
if(\Auth::user()->user_type==2){
?>
                <select class="form-control" id="change_status_filter">
                  <option value="select_status">--Select Status--
                  </option>
                  <option value="0">Queue
                  </option>
                  <!-- <option value="1">Pending
                  </option> -->
                  <option value="2">In Progress
                  </option>
                 <!--  <option value="3">Review
                  </option> -->
                  <option value="4"> Completed
                  </option>
                </select>
                <div class="input-group-addon btn btn-primary" id="status_filter_btn">
                  <i class="glyphicon glyphicon-search">
                  </i>
                </div>
                <?php
}
if(\Auth::user()->user_type==3){
?>
                <input type="text" class="form-control start_date" name="start_end_date"  id="daterange1" placeholder="Select Date Range" autocomplete="off">
                <div class="input-group-addon btn btn-primary" id="daterange_filter_btn">
                  <i class="glyphicon glyphicon-search">
                  </i>
                </div>
                <?php  
}
?>
              </div>
            </div>
            <div class="col-md-4">
              <label class="wdthfull">Amount</label>
              <div class="amount-area">
                <!-- <input type="number" name="amount" class="form-control" id="amount_filter" min="0" placeholder="Amount">
                <div class="input-group-addon btn btn-primary" id="amount_filter_btn">
                  <i class="glyphicon glyphicon-search">
                  </i>
                </div> -->
                <div class="reinit_amount">
                 <input type="text" class="js-range-slider cost_estimated_filter" name="my_range" value="" id="amount_filter"/>
               </div>
                <div class=" btn btn-primary amount-area-f-btn" id="amount_filter_btn">
                  <i class="glyphicon glyphicon-search"></i>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <label class="wdthfull">Area</label>
              <div class="amount-area">
                <!-- <input type="number" name="area" class="form-control" id="area_filter" min="0" placeholder="Area">
                <div class="input-group-addon btn btn-primary" id="area_filter_btn">
                  <i class="glyphicon glyphicon-search">
                  </i>
                </div> -->
                <div class="reinit_area">
                  <input type="text" class="js-area-slider area_filter" name="my_range" value="" id="area_filter"/>
                </div>
                <div class=" btn btn-primary amount-area-f-btn" id="area_filter_btn">
                  <i class="glyphicon glyphicon-search"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="customefilter pull-right">
          <input type="text" class="search" placeholder=" Search" aria-controls="table1">
          <button id="search_btn" class="btn btn-sm btn-primary">Search
          </button>
          <button id="reset" class="btn btn-sm btn-primary">Reset
          </button>
        </div>
        <div class="table-scroll">
        <table class="table table-bordered " id="jobs-table">
          <thead>
            <tr>
               <th>{{trans('messages.user_field.map_id')}}
              </th>
              <?php
if(\Auth::user()->user_type==2){
?>
              <th>
                <span>{{trans('messages.users_management.name')}}
                </span>
              </th>
              <th>{{trans('messages.users_management.email')}}
              </th>
              <?php
}
?>

              <th>{{trans('messages.jobs.map_name')}}
              </th>
              <th>{{trans('messages.jobs.area')}}
              </th>
              <th>{{trans('messages.jobs.cost_estimated')}}
              </th>
            <?php
          if(\Auth::user()->user_type==2){
          ?>     
              <!--  <th>{{trans('messages.common.status')}}
              </th> -->
             
              <th>{{trans('messages.jobs.jobs_stauts')}}
          <?php
          }
          ?>      
              </th>
             
              <th>{{trans('messages.common.created_at')}}
              </th>
              <?php
// if(\Auth::user()->user_type==3){
?>
              <th>{{trans('messages.common.action')}}
              </th>
              <?php
// }
?>
            </tr>
          </thead>
        </table>
      </div>
      </div>
    </div>
  </div>
  </div>
<!--/row-->
</section>


<!-- Modal -->
  <div class="modal fade remove-tile-designer-modal" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Remove Tile Designer</h4>
        </div>
        <div class="modal-body">
          <p><label>Map/Job Unique Id :</label> <span id="job_uniuuq_id"></span></p>
          <p><label>Map Name :</label> <span id="map_name"></span></p>
          <p><label>Tile Designer Name :</label> <span id="tile_des_name"></span></p>
          <p><label>Tile Designer Unique Id :</label> <span id="tile_des_unique"></span></p>
          <p><label>Tile Designer Email :</label> <span id="tile_des_email"></span></p>
         
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default remove-tile-designer" job_id="" tile_des_id=""   tile_des_email="" tile_des_name="" map_name="" map_id="">Remove</button>
          <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>





@stop
@section('page_script')
<script type="text/javascript" src="{{URL::asset('assets/back/vendors/datatables/js/jquery.dataTables.js')}}">
</script>
<script type="text/javascript" src="{{URL::asset('assets/back/vendors/datatables/js/dataTables.bootstrap.js')}}">
</script>
<script type="text/javascript" src="{{URL::asset('assets/back/vendors/datatables/js/dataTables.responsive.js')}}">
</script>
<script src="{{URL::asset('assets/back/js/daterangepicker.js')}}" type="text/javascript">
</script>

<!-- bootbox -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.js"></script>

<!--Slider-->

<!--Plugin JavaScript file rangeSlider-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/ion-rangeslider/2.3.0/js/ion.rangeSlider.min.js"></script>

<!-- <script type="text/javascript" src="{{URL::asset('assets/back/js/pages/users/user-list.js')}}"></script> -->
<script>
  var user_type = "{{ \Auth::user()->user_type }}";

  var unique_id={
      data: 'unique_id',render:function (data, type, full, meta) {
        if(full.unique_id=='' || full.unique_id==null ){
          return "<center>__</center>";
        }
        else{
          return ucwords(full.unique_id);
        }
      }
    }

  var columns=[
    
    
    {
      data: 'map_name',render:function (data, type, full, meta) {
        if(full.map_name=='' || full.map_name==null ){
          return "<center>__</center>";
        }
        else{
          return ucwords(full.map_name);
        }
      }
    },
    {
      data: 'area', name: 'area' }
    ,
    {
      data: 'cost_estimated', render:function (data, type, full, meta) {
        if(full.cost_estimated=='' || full.cost_estimated==null ){
          return "<center>__</center>";
        }
        else{
          return full.cost_estimated;
        }
      }
    }
    
    // {
    //   data: 'job_status',
    //   render:function (data, type, full, meta) {
    //     if(full.job_status==0 || full.job_status==1){
    //       return "<span class='badge' style='background-color:lightred;'>Queue</span>";
    //     }
    //     // if(full.job_status==1){
    //     //   return "<span class='badge' style='background-color:lightyellow;'>Pending</span>";
    //     // }
    //     if(full.job_status==2){
    //       return "<span class='badge' style='background-color:#F82A69;'>In Progress</span>";
    //     }
    //     if(full.job_status==3){
    //       return "<span class='badge' style='background-color:#9D01FF;'>Review</span>";
    //     }
    //     if(full.job_status==4){
    //       return "<span class='badge' style='background-color:#357AE8;'>Completed</span>";
    //     }
    //   }
    // }
    // ,
    // {
    //   data: "is_active",
    //   render:function (data, type, full, meta) {
    //     if(full.is_active==1){
    //       return "<span class='btn btn-success btn-xs badge'  current_status='1' style='cursor: text;'>Active</span>";
    //     }
    //     else{
    //       return "<span class='btn btn-danger btn-xs badge'  current_status='0' style='cursor: text;'>DeActive</span>";
    //     }
    //   },
    //   "orderable": false 
    // }
    ,
    {
      data: 'created_at',
      render:function (data, type, full, meta) {
        
        return dateConvert(full.created_at);
      }
    }
    ,
    {
      data: 'action',
      "searchable": false,
      "orderable": false 
    }
  ];
  var order_col_num=4;
  var url='{{ url('tile-designer/jobs-ajaxPaggination') }}';
  /* for Admin  take user name,email column & remove view(action col)*/
  if(user_type == '2') {
    var namecol={
      data: 'name',render:function (data, type, full, meta) {
        return ucwords(full.belongs_user.full_name);
      }
    }
    var emailcol={
      data: 'email',render:function (data, type, full, meta) {
        return full.belongs_user.email;
      }
    }

    var job_status={
      data: 'job_status',
      render:function (data, type, full, meta) {
       

         if(full.job_status=="Queue"){
          return "<span class='badge' style='background-color:lightred;'>Queue</span>";
        }
        if(full.job_status=="Pending"){
          return "<span class='badge' style='background-color:lightyellow;'>Pending</span>";
        }
        if(full.job_status=="In Progress"){
          return "<span class='badge status_"+full.id+"' style='background-color:#F82A69;'>In Progress</span>";
        }
        if(full.job_status=="Review"){
          return "<span class='badge' style='background-color:#9D01FF;'>Review</span>";
        }
        if(full.job_status=="Completed"){
          return "<span class='badge' style='background-color:#357AE8;'>Completed</span>";
        }

      }
    };

    var status={
      data: "is_active",
      render:function (data, type, full, meta) {
        if(full.is_active==1){
          return "<span class='btn btn-success btn-xs badge'  current_status='1' style='cursor: text;'>Active</span>";
        }
        else{
          return "<span class='btn btn-danger btn-xs badge'  current_status='0' style='cursor: text;'>DeActive</span>";
        }
      },
      "orderable": false 
    };

    
    // columns.splice(4, 0,status);
    columns.splice(3, 0, job_status);
    columns.unshift(emailcol);
    columns.unshift(namecol);
    columns.unshift(unique_id);
    
    // columns.pop();
    order_col_num=7;
    var url='{{ url('admin/jobs-ajaxPaggination') }}';
  }else{
    columns.unshift(unique_id);

  }
  $(function() {

    $('#jobs-table').DataTable({
      "stateSave": true,
      order: [[ order_col_num, "desc" ]], 
      processing: true,
      serverSide: true, 
      // ajax: '{{ url('admin/user-ajaxPaggination') }}', //get method
      "ajax": {
        url:url ,
        type: "post", // method  , by default get
        beforeSend: function () {
                        
                    },
        data: function (d) {
            d.filter_status=$('#change_status_filter').val(),
            d.amount_filter=$('#amount_filter').val(),
            d.area_filter=$('#area_filter').val(),
            d.daterange=$('#daterange1').val(),
            d.amt_range=$('#myRange').val(),
            d.price_min=$('#price-min').val()
            
        },
        error: function(xhr) { // check for session expire
         
           if(xhr.status==419)
           {
             window.location.href = "{{url('admin/login')}}";
           }
        },
      }
      ,
      columns:columns 
    }
    );
  }
   );
</script>
<script type="text/javascript">
  /* Hide original search */
  $( document ).ready(function() {
    $('#jobs-table_filter').hide();
  } );

/*data table page change then scroll to top */
$('#jobs-table').on( 'page.dt', function () {
    $('html, body').animate({
        scrollTop: 0
    }, 6000);
} );


  //custom Reset button
  $('#reset').click( function (e) {

    $('#daterange1').val('');
    $('#amount_filter').val('');
    $('#area_filter').val('');
    $('#change_status_filter').val('');
    $("#change_status_filter option[value=select_status]").prop("selected", true);

    $('.search').val('');
    $('#jobs-table').DataTable().search('').draw();
    //search reset     
    $('#jobs-table').DataTable().order([order_col_num, 'desc']).draw();
    //sort reset
    $('#jobs-table').DataTable().page.len(10).draw();
    // show enrty reset


    /*Re-initialize the filter*/
   $('.reinit_amount').empty();
   // setTimeout(function(){ 

    $('.reinit_amount').html('<input type="text" class="js-range-slider cost_estimated_filter" name="my_range" value="" id="amount_filter"/>'); 
   
      $(".js-range-slider").ionRangeSlider({
            type: "double",
            grid: true,
            min: 0,
            max:1000,
            from: 0,
            to: 0,
            prefix: "$",
            prettify_enabled: true,
            prettify_separator: ","

        });

    // }, 100);

   $('.reinit_area').empty();
   // setTimeout(function(){ 

    $('.reinit_area').html(' <input type="text" class="js-area-slider area_filter" name="my_range" value="" id="area_filter"/>'); 
   
      $(".js-area-slider").ionRangeSlider({
        type: "double",
        grid: true,
        min: 0,
        max: 20,
        from: 0,
        to: 0,
        prefix: "Acres ",

    });

     // }, 1000);

  });
  /*cutom search button event*/
  $(document).on('click', '#search_btn', function (event) {
    var value_of_custom_search_text_box=$('.search').val();
    //get value of custom serchbox
    $('#jobs-table').DataTable().search(value_of_custom_search_text_box).draw();
  });

  /* serch on press of enter */
    $('.search').keypress(function(event){
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if(keycode == '13'){
           var value_of_custom_search_text_box=$('.search').val();
           $('#jobs-table').DataTable().search(value_of_custom_search_text_box).draw();
        }
    });

  /* change custom filter*/
  $(document).on('click', '#status_filter_btn', function() {
    if($('#change_status_filter').val()!=''){
      $('#jobs-table').DataTable().draw();
    }
  } );

  $(document).on('click', '#amount_filter_btn', function() {
  var csf=$(".cost_estimated_filter").val();
  
    if($('#amount_filter').val()!=''){
      $('#jobs-table').DataTable().draw();
    }
  });

  $(document).on('change', '#myRange', function() {

    var slider = document.getElementById("myRange");
    var output = document.getElementById("demo");
    output.innerHTML = slider.value;
 $('#jobs-table').DataTable().draw();
    slider.oninput = function() {
        
        output.innerHTML = this.value;
       
      }
    
  });



  $('#amount_filter').keypress(function(e){
        if(e.which == 13){//Enter key pressed
            $('#amount_filter_btn').click();//Trigger search button click event
        }
    });

  $(document).on('click', '#area_filter_btn', function() {
    if($('#area_filter').val()!=''){
      $('#jobs-table').DataTable().draw();
    }
  });

   $('#area_filter').keypress(function(e){
        if(e.which == 13){//Enter key pressed
            $('#area_filter_btn').click();//Trigger search button click event
        }
    });
   
  $(document).on('click', '#daterange_filter_btn', function() {
    if($('#daterange1').val()!=''){
      $('#jobs-table').DataTable().draw();
    }
  });
  function ucwords (str) {
    return (str + '').replace(/^([a-z])|\s+([a-z])/g, function ($1) {
      return $1.toUpperCase();
    });
  }
  function dateConvert(edate)
  {

    var myDate = new Date(edate);
    var d = myDate.getDate(); 
    var m =  myDate.getMonth();
    m += 1;
    if(m <= "9"){
      m="0"+m;
    }
    if(d <= "9"){
      d="0"+d;
    }
    var y = myDate.getFullYear();
    var h = myDate.getHours();
    if(h <= "9"){
      h="0"+h;
    }
    var min = myDate.getMinutes();
    if(min <= "9"){
      min="0"+min;
    }
    var i = myDate.getSeconds();
    if(i <= "9"){
      i="0"+i;
    }
    var newdate=(m+ "-" + d + "-" + y + " "+h+":"+min+":"+i);
    return newdate;
  }
  $(document).on('click', '.delete-record', function(event) {
    var id = $(this).attr("id");
    if(confirm('Are you sure want to remove this record ?'))
    {
      $.ajax({
        url: "{{ url('/admin/ajax-delete-advertisement') }}/"+id,
        type: 'GET',
        success: function(data) {
          if(data=="1"){
            $('.del-success-msg').show().fadeOut(3000);
            setTimeout(function(){
              location.reload();
            }
                       , 3000);
          }
          else{
            $('.del-error-msg').show().fadeOut(3000);
          }
        }
      });
    }
  });

  $(document).on('click', '.change_status', function(event) {
        
           var id = $(this).attr("id");
           var current_status=$(this).attr("current_status");
           var self = this;

           event.preventDefault();

           bootbox.confirm({
                  title: "Confirm",
                  message: "Are you sure want to change status ?",
                  buttons: {
                              cancel: {
                                  label: 'Cancel'
                              },
                              confirm: {
                                  label: 'Confirm'
                              }
                          },
                callback: function (result) {
                           if(result==true){
                                $.ajax({
                                   url: "{{ url('/admin/ajax-change-status') }}/"+id+"/"+current_status,
                                   type: 'GET',
                                   success: function(data) {
                                     
                                       if(data=="1"){

                                        if(current_status==1){
                                          $(self).prop( "checked", false );
                                          $(self).attr("current_status",0);
                                        }else{
                                           $(self).prop( "checked", true );
                                           $(self).attr("current_status",1);
                                        }
                                        $('.status-success-msg').show().fadeOut(3000);
                                        // setTimeout(function(){ location.reload(); }, 3000);
                                        
                                       }else{
                                        $('.status-error-msg').show().fadeOut(3000);
                                        
                                       }
                                   }
                                });
                           }
                           else{
                                  event.preventDefault();
                                }
                }
            });
            
         }); 

 
  /* TAKE UP JOB */
  $(document).on('click', '.job-takeup', function(event) {
    $(this).attr("disabled",true);
    var id = $(this).attr("job-id");
    var self=this;


          bootbox.confirm({
                  title: "Confirm",
                  message: "Are you sure want to take up this job ?",
                  buttons: {
                              cancel: {
                                  label: 'Cancel'
                              },
                              confirm: {
                                  label: 'Confirm'
                              }
                          },
                callback: function (result) {
                           if(result==true){
                              
                              $.ajax({
                                url: "{{ url('/tile-designer/take-up-job-by-designer') }}/"+id,
                                type: 'GET',
                                beforeSend: function(){
                                     $('#page_loader').show();
                                 },
                                success: function(data) {
                                  $('#page_loader').hide();
                                  $(self).attr("disabled",false);
                                  if(data=="-1"){
                                    $("html, body").animate({
                                      scrollTop: 0 }, "slow");
                                    $('.blacklist-error-msg').show().fadeOut(5000);
                                  }
                                  else if(data=="0"){
                                    $("html, body").animate({
                                      scrollTop: 0 }, "slow");
                                    $('.restriction-error-msg').show().fadeOut(5000);
                                  }
                                  else if(data=="1"){
                                    $("html, body").animate({
                                      scrollTop: 0 }, "slow");
                                    $('.takeup-success-msg').show().fadeOut(5000);
                                    setTimeout(function(){
                                      window.location.href = "{{ url('/tile-designer/ongoing-jobs/view') }}/"+id;    
                                     }, 3000);
                                  }
                                }
                              });
                           }
                           else{
                                     $(self).attr("disabled",false);
                                }
                }
            });

  });

  $("#daterange1").daterangepicker({
        locale: {
          format: 'MM/DD/YYYY'
        }
      }
   ).val('');
  /* Laravel Flash msg remove after 5 sec*/
  $("document").ready(function(){
    setTimeout(function(){
      $(".laravel-flash").remove();
    }, 5000 );// 5 secs
  });

  /*Range Filter*/
 /*For amount*/
 $(".js-range-slider").ionRangeSlider({
        type: "double",
        grid: true,
        min: 0,
        max:1000,
        from: 0,
        to: 0,
        prefix: "$",
        prettify_enabled: true,
        prettify_separator: ","

    });
  /*For area*/
 $(".js-area-slider").ionRangeSlider({
        type: "double",
        grid: true,
        min: 0,
        max: 20,
        from: 0,
        to: 0,
        prefix: "Acres ",

    });
 

/*Open Model & Append Values*/
  $(document).on('click', '.inprog_model', function (event) {
    
      var job_id=$(this).attr('job_id');
      var job_unique_id=$(this).attr('job_unique_id');
      var map_name=$(this).attr('map_name');
      var tile_des=$(this).attr('tile-des');
      var tile_des_email=$(this).attr('tile-des-email');
      var unique_id=$(this).attr('unique_id');
      var tile_des_id=$(this).attr('tile_des_id');
      
      $("#job_uniuuq_id").html(job_unique_id);
      $("#map_name").html(map_name);
      $("#tile_des_name").html(tile_des);
      $("#tile_des_unique").html(unique_id);
      $("#tile_des_email").html(tile_des_email);

      $(".remove-tile-designer").attr("job_id",job_id);
      $(".remove-tile-designer").attr("tile_des_id",tile_des_id);

      $(".remove-tile-designer").attr("tile_des_email",tile_des_email);
      $(".remove-tile-designer").attr("tile_des_name",tile_des);

      $(".remove-tile-designer").attr("map_name",map_name);
      $(".remove-tile-designer").attr("map_id",job_unique_id);

      $(this).addClass("remove_row_btn_"+job_id);

  });

    /*On click of model remove button*/
    $(document).on('click', '.remove-tile-designer', function (event) {
    
      var job_id=$(this).attr('job_id');
      var user_id=$(this).attr('tile_des_id');

      var tile_des_email=$(this).attr('tile_des_email');
      var tile_des_name=$(this).attr('tile_des_name');
      var map_name=$(this).attr('map_name');
      var map_id=$(this).attr('map_id');
  
      
     bootbox.confirm({
                      title: "Confirmation",
                      message: "Are you sure want to remove tile designer from this job ?.",
                      buttons: {
                          cancel: {
                              label: 'Cancel'
                          },
                          confirm: {
                              label: 'Confirm'
                          }
                      },
                      callback: function (result) {
                        
                         if(result==true){
                            $("#myModal").modal("hide");
                               $.ajax({
                                url: "{{ url('/admin/remove-tiledesigner') }}/"+job_id+"/"+user_id,
                                type: 'GET',
                                data:{
                                  "tile_des_email":tile_des_email,"tile_des_name":tile_des_name,"map_name":map_name,"map_id":map_id
                                },
                                beforeSend: function(){
                                     $('#page_loader').show();
                                 },
                                success: function(data) {

                                  $('#page_loader').hide();
                                  
                                   $("html, body").animate({
                                      scrollTop: 0 }, "slow");
                                    $('.remove_from_job_msg').show().fadeOut(5000);

                                  $(".remove_row_btn_"+job_id).parent().html("-");
                                  $(".status_"+job_id).parent().html("<span class='badge' style='background-color:lightred;'>Queue</span>");
                                  

                                }
                              });
                         }else{
                           $("#myModal").modal("hide");
                         }
                      }
                  });

  });

</script>
@stop









<!-- 1 . Open model  -->
<!-- 2. Change status code -->
3. ionRangeSlider
4. Laravel Flash msg remove after 5 sec
5. change_status  by toggle btn
6. delete-record   delete record  on clicl of delete btn
7. dateConvert & ucwords
8 custom search reset & page change scroll to top
9. ajax paggination check session expire or not if expire then redirect on login page
10. custom filter
