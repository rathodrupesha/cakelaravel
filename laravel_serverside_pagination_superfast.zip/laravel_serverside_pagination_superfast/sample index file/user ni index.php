@extends('back.layout.master')
@section('page_css')
<link rel="stylesheet" type="text/css" href="{{URL::asset('assets/back/vendors/datatables/css/dataTables.bootstrap.css')}}">
<!-- for toggle -->
<link rel="stylesheet" type="text/css" href="{{URL::asset('assets/back/css/toggleswitch.css')}}">
@stop
@section('content')
@section('title',"Users")
<section class="content-header">
    <h1>{{trans('messages.users_management.user')}}</h1>
   <!--  <div class="add_new_user">
        <a href="{{ url('/admin/user/create') }}" class="btn btn-sm btn-primary"><span class="glyphicon glyphicon-plus"></span> {{trans('messages.users_management.create_user')}}</a>
    </div> -->
<!--     <ol class="breadcrumb">
        <li class="">
           <i class="livicon" data-name="user" data-size="14" data-loop="true"></i>
          {{trans('messages.users_management.user')}}
        </li>
    </ol> -->
</section>

<section class="content">
    <div class="row">
 
        <div class="col-lg-12">
            <div class="panel panel-primary filterable">
                @if ($message = Session::get('success'))
                <div class="alert alert-success alert-block laravel-flash">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                        <strong>{{ $message }}</strong>
                </div>
                @endif
                <!-- for delete record -->
                <div class="alert alert-success del-success-msg" style="display: none">
                  <strong>Success!</strong> Record deleted Successfully.
                </div>
                <div class="alert alert-danger del-error-msg" style="display: none">
                  <strong>Danger!</strong> Record not deleted try again.
                </div>
                <!-- for status Change -->
                <div class="alert alert-success status-success-msg" style="display: none">
                  <strong>Success!</strong> Status change Successfully.
                </div>
                <div class="alert alert-danger status-error-msg" style="display: none">
                  <strong>Error!</strong> Status not change try again.
                </div>
               
                <div class="panel-body table-responsive">
                   <div class="customefilter pull-right">
                    <input type="text" class="search" placeholder=" Search" aria-controls="table1">
                    <button id="search_btn" class="btn btn-sm btn-primary">Search</button>
                    <button id="reset" class="btn btn-sm btn-primary">Reset</button>
                  </div>
                    <table class="table table-bordered " id="userdata-table">
                        <thead>
                            <tr>
                                <th><span>Unique Id</span></th>
                                <th><span>{{trans('messages.users_management.name')}}</span></th>
                                <th>{{trans('messages.users_management.profile_image')}}</th>
                                <th>{{trans('messages.users_management.email')}}</th>
                                <th>{{trans('messages.users_management.phone_no')}}</th>
                                <th>{{trans('messages.users_management.address')}}</th>
                                <th>{{trans('messages.common.status')}}</th>
                                <th width="120">{{trans('messages.common.created_at')}}</th>
                                <th>{{trans('messages.common.action')}}</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!--/row-->
</section>
@stop

@section('page_script')
<script type="text/javascript" src="{{URL::asset('assets/back/vendors/datatables/js/jquery.dataTables.js')}}"></script>
<script type="text/javascript" src="{{URL::asset('assets/back/vendors/datatables/js/dataTables.bootstrap.js')}}"></script>
<script type="text/javascript" src="{{URL::asset('assets/back/vendors/datatables/js/dataTables.responsive.js')}}"></script>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.js"></script>
<!-- <script type="text/javascript" src="{{URL::asset('assets/back/js/pages/users/user-list.js')}}"></script> -->
       <script>
         $(function() {
               $('#userdata-table').DataTable({
               "stateSave": true,
               "stateSaveParams": function (settings, data) {
                 data.search_text = $('.search').val();
                
                },
                "stateLoadParams": function (settings, data) {
                    $('.search').val(data.search_text);
                    
                },
               order: [[ 7, "desc" ]], 
               processing: true,
               serverSide: true,
               // ajax: '{{ url('admin/user-ajaxPaggination') }}',
               "ajax": {
                url:'{{ url('admin/user-ajaxPaggination') }}' ,
                error: function(xhr) { // if error occured
                 
                   if(xhr.status==419 || xhr.status==401)
                   {
                     window.location.href = "{{url('admin/login')}}";
                   }
                }
              },
               columns: [
                        { data: 'customer_id',render:function (data, type, full, meta) {
                                return ucwords(full.customer_id); 
                            } }, 
                        { data: 'full_name',render:function (data, type, full, meta) {
                                return ucwords(full.full_name); 
                            } },
                        { data: 'image',
                          "orderable": false,
                        render:function (data, type, full, meta) {
                               
                                if(full.image==''){
                                   return "<strong><center>__</center></strong>";
                                }else{
                                   return "<img src='"+full.image+"' width='50px' height='50px'>";
                                }
                                 
                            }
                         },
                        { data: 'email', name: 'email' },
                        { data: 'phone_no', render:function (data, type, full, meta) {
                                
                                if(full.phone_no==null ||  full.phone_no==''){
                                    return "<strong><center>__</center></strong>";
                                }else{
                                    return full.phone_no;
                                }
                              
                            }},
                        { data: 'address', render:function (data, type, full, meta) {
                                
                                if(full.address==null || full.address==''){
                                    return "<strong><center>__</center>";
                                }else{
                                    return full.address;
                                }
                              
                            } },
                        
                        {data: "is_active",
                        render:function (data, type, full, meta) {
                               
                                if(full.is_active==1){
                                  var checked='checked';
                                  var current_status='1';

                                }else{
                                  var checked='';
                                  var current_status='0';

                                }
                              return "<label class='switch'><input type='checkbox'  class='change_status' id='"+full.id+"' current_status='"+current_status+"' "+checked+"><span class='slider round'></span></label>";
                            }
                        },   
                        { data: 'created_at',
                        render:function (data, type, full, meta) {
                                return dateConvert(full.created_at);
                              
                            }},
                        { data: 'action',
                          "searchable": false,
                          "orderable": false 
                        } 
                     ]
            });
         });

         </script>

         <script type="text/javascript">

          /* Hide original search */
          $( document ).ready(function() {
             $('#userdata-table_filter').hide();
          });

           /*data table page change then scroll to top */
            $('#userdata-table').on( 'page.dt', function () {
              
                $('html, body').animate({
                    scrollTop: 0
                }, 3000);
            } );

           //custom Reset button
           $('#reset').click( function (e) {
              $('.search').val('');
              $('#userdata-table').DataTable().search('').draw();    //search reset     
              $('#userdata-table').DataTable().order([7, 'desc']).draw();//sort reset
              $('#userdata-table').DataTable().page.len(10).draw(); // show enrty reset
          });
          
          /*cutom search button event*/
          $(document).on('click', '#search_btn', function (event) {
            var value_of_custom_search_text_box=$('.search').val(); //get value of custom serchbox
             $('#userdata-table').DataTable().search(value_of_custom_search_text_box).draw();

          });

          /* serch on press of enter */
          $('.search').keypress(function(event){
             var value_of_custom_search_text_box=$('.search').val(); //get value of custom serchbox
             $('#userdata-table').DataTable().search(value_of_custom_search_text_box).draw();
          });    


          function ucwords (str) {
                return (str + '').replace(/^([a-z])|\s+([a-z])/g, function ($1) {
                    return $1.toUpperCase();
                });
           }

           function dateConvert(edate)
          {
         
            var myDate = new Date(edate);
            console.log(myDate);
            var d = myDate.getDate();
            var m =  myDate.getMonth();

            m += 1; 
            if(m <= "9"){
              m="0"+m;
            }
             
            if(d <= "9"){
              d="0"+d;
            }
            var y = myDate.getFullYear();
            var h = myDate.getHours();
            if(h <= "9"){
              h="0"+h;
            }
            var min = myDate.getMinutes();
             if(min <= "9"){
              min="0"+min;
            }
            var i = myDate.getSeconds();
            if(i <= "9"){
              i="0"+i;
            }

             var newdate=(m+ "-" + d + "-" + y + " "+h+":"+min+":"+i);
             return newdate;
          } 
             
         $(document).on('click', '.delete-record', function(event) {
        
           var id = $(this).attr("id");
         
            if(confirm('Are you sure want to remove this record ?'))
            {
                $.ajax({
                   url: "{{ url('/admin/ajax-delete-advertisement') }}/"+id,
                   type: 'GET',
                   success: function(data) {
                    
                       if(data=="1"){
                        $('.del-success-msg').show().fadeOut(3000);
                        setTimeout(function(){ location.reload(); }, 3000);
                        
                       }else{
                        $('.del-error-msg').show().fadeOut(3000);
                        
                       }
                   }
                });
            }
         });

        $(document).on('click', '.change_status', function(event) {
        
           var id = $(this).attr("id");
           var current_status=$(this).attr("current_status");
           var self = this;

           event.preventDefault();

           bootbox.confirm({
                  title: "Confirm",
                  message: "Are you sure want to change status ?",
                  buttons: {
                              cancel: {
                                  label: 'Cancel'
                              },
                              confirm: {
                                  label: 'Confirm'
                              }
                          },
                callback: function (result) {
                           if(result==true){
                                $.ajax({
                                   url: "{{ url('/admin/ajax-change-status') }}/"+id+"/"+current_status,
                                   type: 'GET',
                                   success: function(data) {
                                     
                                       if(data=="1"){

                                        if(current_status==1){
                                          $(self).prop( "checked", false );
                                          $(self).attr("current_status",0);
                                        }else{
                                           $(self).prop( "checked", true );
                                           $(self).attr("current_status",1);
                                        }
                                        $('.status-success-msg').show().fadeOut(3000);
                                        // setTimeout(function(){ location.reload(); }, 3000);
                                        
                                       }else{
                                        $('.status-error-msg').show().fadeOut(3000);
                                        
                                       }
                                   }
                                });
                           }
                           else{
                                  event.preventDefault();
                                }
                }
            });
            
         });

         /* Laravel Flash msg remove after 5 sec*/
          $("document").ready(function(){
              setTimeout(function(){
                 $("div.laravel-flash").remove();
              }, 5000 ); // 5 secs
          });
        
         </script>
@stop

