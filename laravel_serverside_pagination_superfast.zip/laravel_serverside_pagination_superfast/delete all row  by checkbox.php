 
@extends('layouts.master')
@section('title')
 blank-page
@endsection

   @section('contents')
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    
    <!-- Content Header (Page header) -->
    <section class="content-header">
      
      <h1>
      <!-- Users -->
        
      </h1>
     
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">Users</h3>

        </div>
        <div class="box-body">
          
 
                        <a href="{{ url('/admin/user/create') }}" class="btn btn-success btn-sm pull-right" title="Add New Userclaim">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add New
                        </a>
                       
                        <button class="btn btn-danger btn-sm pull-right delete_all" ><i class="fa fa-trash-o" aria-hidden="true"></i> Delete All</button>
                       

                        <br/>
                        <br/>
                        <div class="table-responsive">
                            <table class="table" id="example1">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><input type="checkbox" name="" id="master_checkbox"></th>
                                        <th>firstname</th>
                                        <th>lastname</th>
                                        <th>email</th>
                                        <th>gender</th>
                                        <th>hobby</th>
                                        <th>city</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                @foreach($user as $item)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td><input type="checkbox" name="" class="sub_checkbox" data-id="<?php echo $item->id; ?>"></td>
                                        <td>{{ $item->firstname }}</td>
                                        <td>{{ $item->lastname }}</td>
                                        <td>{{ $item->email }}</td>
                                        <td>{{ $item->gender }}</td>
                                        <td>{{ $item->hobby }}</td>
                                        <td>{{ $item->city }}</td>
                                        <td>
                                            <a href="{{ url('/admin/user/' . $item->id) }}" title="View Userclaim"><button class="btn btn-info btn-sm"><i class="fa fa-eye" aria-hidden="true"></i> View</button></a>
                                            <a href="{{ url('/admin/userclaims/' . $item->id . '/edit') }}" title="Edit Userclaim"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</button></a>

                                            <form method="POST" action="{{ url('/admin/user' . '/' . $item->id) }}" accept-charset="UTF-8" style="display:inline">
                                                {{ method_field('DELETE') }}
                                                {{ csrf_field() }}
                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete Userclaim" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                          
                        </div>


        </div>
        <!-- /.box-body -->
        <div class="box-footer">
          <!-- Footer -->
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

   <script>
   
     $('#master_checkbox').on('click', function(e) {
        
         if($(this).is(':checked',true))  
         {
            $(".sub_checkbox").prop('checked', true);  
         } else {  
            $(".sub_checkbox").prop('checked',false);  
         }  
        });

 /* on click of delete all */
      $('.delete_all').on('click', function(e) {
 
            var allVals = [];  
            $(".sub_checkbox:checked").each(function() {  
                allVals.push($(this).attr('data-id'));
            });  
       
            if(allVals.length <=0)  
            {  
                alert("Please select row.");  
            }  else {  
 
                var check = confirm("Are you sure you want to delete this row?");  
                if(check == true){  
 
                    var join_selected_values = allVals.join(","); 
                   alert(join_selected_values);
 
                  $.ajaxSetup({

                              headers: {

                                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                 }
                             });

                    $.ajax({
                        url: "{{ url('/deleteAll') }}",
                        type: 'POST',
                        data: 'ids='+join_selected_values,
                        success: function (data) {
                          console.log(data);
                          $(".sub_checkbox:checked").each(function() {  
                              $(this).parents("tr").remove();
                          });
                          alert("Item Deleted successfully.");
                        },
                        error: function (data) {
                            alert(data.responseText);
                        }
                    });
 
                  // $.each(allVals, function( index, value ) {
                  //     $('table tr').filter("[data-row-id='" + value + "']").remove();
                  // });
                }  
            }  
        });


    
 
    </script>

 @endsection

