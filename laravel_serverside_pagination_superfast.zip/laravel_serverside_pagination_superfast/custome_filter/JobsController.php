<?php

namespace App\Http\Controllers\Back;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\UserFields;
use App\Setting;
use App\JobTakeup;
use App\User;

use Illuminate\Http\Request;
use Carbon\Carbon;

/*Mail*/
use Illuminate\Support\Facades\Mail;
use App\Mail\JobTaken;
use App\Mail\JobWorkStart;

/*laravel JOb*/
use App\Jobs\SendEmailToAllAdmin;

class JobsController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $keyword = $request->get('search');
        $perPage = 25;

        return view('back.jobs.index', compact('jobs'));
    }

    public function ajaxPaggination(Request $request)
    {
        $requestData=$request->all();
       

        $whereData = [
                        ['is_deleted', '0']
                    ];

        if (!empty($requestData['daterange'])) {
            $range=explode('-', $requestData['daterange']);
            $start_date=date("Y-m-d H:i:s", strtotime($range[0]));
            $end_date=date("Y-m-d H:i:s", strtotime($range[1]));
            $created_at_start=['created_at','>=',$start_date];
            $created_at_end=['created_at','<=',$end_date];
            array_push($whereData, $created_at_start);
            array_push($whereData, $created_at_end);
        }
          
        if (!empty($requestData['filter_status'])) {
            $job_status=['job_status',$requestData['filter_status']];
            array_push($whereData, $job_status);
        }

        if (!empty($requestData['area_filter'])) {
            $area=['area',$requestData['area_filter']];
            array_push($whereData, $area);
        }

        if (!empty($requestData['amount_filter'])) {
            $cost_estimated=['cost_estimated',$requestData['amount_filter']];
            array_push($whereData, $cost_estimated);
        }
        /* display all jobs that are in queue only*/
        $data=UserFields::with('belongsUser')->where($whereData)->where('job_status', '0')->get()->toArray();
        
        return datatables($data)->addColumn('name', function ($data) {
            return $data['belongs_user']['full_name'];
        })->addColumn('email', function ($data) {
            return $data['belongs_user']['email'];
        })->addColumn('action', function ($data) {
            foreach ($data as $key => $value) {
                $id=$value;
                $url=url('/admin/jobs/'.$id.'/edit');
                $viewurl=url('/admin/jobs/'.$id);
                if ($data['job_status']==0) {
                    $action="<a href='".$viewurl."' class='btn btn-xs btn-primary edit-record'><i class='glyphicon glyphicon-eye-open'></i> View</a></br><button class='btn btn-xs btn-warning job-takeup' job-id='".$id."'><i class='fa fa-reply'></i> Take Up</button>";
                } else {
                    $action="<a href='".$viewurl."' class='btn btn-xs btn-primary edit-record'><i class='glyphicon glyphicon-eye-open'></i> View</a>";
                }
                return $action;
            }
        })->toJson();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('jobs.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(Request $request)
    {
        $requestData = $request->all();
        
        Job::create($requestData);

        return redirect('admin/jobs')->with('flash_message', 'Job added!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $UserFields=UserFields::with('outlets')->where('id', $id)->get()->toArray();
        // echo "<pre>";print_r($UserFields);exit;
        $title = trans('messages.jobs.jobs_details');

        return view('back.jobs.show', compact('UserFields', 'title'));
    }
    
    public function takeUpJobByTileDesigner($job_id)
    {

        $job_restriction=Setting::first();
        $tile_designer_id=\Auth::user()->id;

        $is_blacklist=JobTakeup::where('user_id', $tile_designer_id)->where('user_field_id', $job_id)->where('is_blacklist', '1')->count();

        if ($is_blacklist==0) {
            $total_job_taken=JobTakeup::where('user_id', $tile_designer_id)->where('is_blacklist', '0')->count();
           
            if ($job_restriction->restriction_on_no_of_jobs !='0' && $total_job_taken >= $job_restriction->restriction_on_no_of_jobs) {
                return '0';  //restriction apply
            } else {
                /*job take up by tile designer*/
                JobTakeup::create(['user_id' =>$tile_designer_id, 'user_field_id' =>$job_id]);
                /* update job status 'in preogress' */
                UserFields::where('id', $job_id)
                          ->update([
                                      'job_status'=>'2',
                                      'updated_at' => Carbon::now()
                                   ]);
                 /* mail to All admin & send job details + tile designer details*/
                 $getAllAdmin=User::where('user_type','2')->where('is_active','1')->where('is_deleted','0')->get(['email'])->toArray();

                 $allAdminEmails=array();

                 foreach ($getAllAdmin as $key => $value) {
                    $allAdminEmails[]=$value['email'];
                 }  

                /*job details*/
                $UserFields=UserFields::with('outlets')->where('id',$job_id)->get()->toArray();
                /*user details*/
                $userData=User::where('id',$UserFields[0]['user_id'])->first()->toArray();
                 /*tile designer details*/
                $tileDesignrer_details=\Auth::user()->toArray();
                

                /* Mail to Admin for job taken notification*/
                SendEmailToAllAdmin::dispatch($UserFields, $tileDesignrer_details,$allAdminEmails);
                // Mail::to('rupesh.rathod@dispostable.com')->send(new JobTaken($UserFields, $tileDesignrer_details));

                /* Mail to user for inform to start work*/
                //Mail::to('rupesh.rathod@dispostable.com')->send(new JobWorkStart($userData));
                Mail::to($userData['email'])->send(new JobWorkStart($userData));
                    
                return '1';
            }
        } else {
            return '-1'; //black list for this job
        }
    }
    

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $job = Job::findOrFail($id);

        return view('jobs.edit', compact('job'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(Request $request, $id)
    {
        $requestData = $request->all();
        
        $job = Job::findOrFail($id);
        $job->update($requestData);

        return redirect('admin/jobs')->with('flash_message', 'Job updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        Job::destroy($id);

        return redirect('admin/jobs')->with('flash_message', 'Job deleted!');
    }
    public function jobDetails($id)
    {
        $UserFields=UserFields::with('outlets')->where('id', $id)->get()->toArray();
        return json_encode($UserFields);
    }

    public function myOngoingJobs(Request $request)
    {
        $keyword = $request->get('search');
        $perPage = 25;

        return view('back.jobs.index', compact('jobs'));
    }

    public function myOngoingJobsAjaxPaggination(Request $request)
    {
        $requestData=$request->all();
       

        $whereData = [
                        ['is_deleted', '0']
                    ];

        if (!empty($requestData['daterange'])) {
            $range=explode('-', $requestData['daterange']);
            $start_date=date("Y-m-d H:i:s", strtotime($range[0]));
            $end_date=date("Y-m-d H:i:s", strtotime($range[1]));
            $created_at_start=['created_at','>=',$start_date];
            $created_at_end=['created_at','<=',$end_date];
            array_push($whereData, $created_at_start);
            array_push($whereData, $created_at_end);
        }
          
        if (!empty($requestData['filter_status'])) {
            $job_status=['job_status',$requestData['filter_status']];
            array_push($whereData, $job_status);
        }

        if (!empty($requestData['area_filter'])) {
            $area=['area',$requestData['area_filter']];
            array_push($whereData, $area);
        }

        if (!empty($requestData['amount_filter'])) {
            $cost_estimated=['cost_estimated',$requestData['amount_filter']];
            array_push($whereData, $cost_estimated);
        }
        /* display all jobs that are in progress only*/
        $data=UserFields::with('belongsUser')->where($whereData)->where('job_status', '2')->get()->toArray();
        
        return datatables($data)->addColumn('name', function ($data) {
            return $data['belongs_user']['full_name'];
        })->addColumn('email', function ($data) {
            return $data['belongs_user']['email'];
        })->addColumn('action', function ($data) {
            foreach ($data as $key => $value) {
                $id=$value;
                $url=url('/admin/jobs/'.$id.'/edit');
                $viewurl=url('/admin/jobs/'.$id);
                if ($data['job_status']==0) {
                    $action="<a href='".$viewurl."' class='btn btn-xs btn-primary edit-record'><i class='glyphicon glyphicon-eye-open'></i> View</a></br><button class='btn btn-xs btn-warning job-takeup' job-id='".$id."'><i class='fa fa-reply'></i> Take Up</button>";
                } else {
                    $action="<a href='".$viewurl."' class='btn btn-xs btn-primary edit-record'><i class='glyphicon glyphicon-eye-open'></i> View</a>";
                }
                return $action;
            }
        })->toJson();
    }

    public function submitJobByTiledesigner(Request $request)
    {
        // $keyword = $request->get('search');
        // $perPage = 25;

        // return view('back.jobs.index', compact('jobs'));
    }

}
