@extends('back.layout.master')
@section('page_css')
<link href="{{URL::asset('assets/back/css/daterangepicker.css')}}" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="{{URL::asset('assets/back/vendors/datatables/css/dataTables.bootstrap.css')}}">
@stop
@section('content')
@section('title',"Jobs")
<section class="content-header">
    <h1>{{trans('messages.jobs.jobs')}}</h1>
    <div class="add_new_user">
        <!-- <a href="{{ url('/admin/user/create') }}" class="btn btn-sm btn-primary"><span class="glyphicon glyphicon-plus"></span> {{trans('messages.users_management.create_user')}}</a> -->
    </div>
    <ol class="breadcrumb">
        <li class="">
           <i class="livicon" data-name="notebook" data-size="14" data-loop="true"></i>
          {{trans('messages.jobs.jobs')}}
        </li>
    </ol>
</section>

<section class="content">
    <div class="row">
 
        <div class="col-lg-12">
            <div class="panel panel-primary filterable">
                @if ($message = Session::get('success'))
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                        <strong>{{ $message }}</strong>
                </div>
                @endif
                <!-- for delete record -->
                <div class="alert alert-success takeup-success-msg" style="display: none">
                  <strong>Success!</strong> Job take up Successfully  Done !.
                </div>
                <div class="alert alert-danger blacklist-error-msg" style="display: none">
                  <strong> You are not eligible for take up this job.!</strong>
                </div>
                
                <div class="alert alert-danger restriction-error-msg" style="display: none">
                  <strong> You had already reach at maximum takeup limit !</strong> 
                </div>
              </br>
              
               
                <div class="panel-body table-responsive">
                
                  <div class="well well-sm ">
                    <div class="row">
                      <div class="col-md-4">
                        <div class="input-group">
                        <?php
                         if(\Auth::user()->user_type==2){
                        ?>

                        <select class="form-control" id="change_status_filter">
                          <option value="">--Select Status--</option>
                          <option value="0">Queue</option>
                          <option value="1">Pending</option>
                          <option value="2">In Progress</option>
                          <option value="3">Review</option>
                          <option value="4"> Complated</option>
                        </select>
                         <div class="input-group-addon" id="status_filter_btn">
                                   <i class="glyphicon glyphicon-search"></i>
                          </div>
                        <?php
                        }
                        if(\Auth::user()->user_type==3){
                        ?>
                       
                             <input type="text" class="form-control start_date" name="start_end_date"  id="daterange1" placeholder="Select Date Range" autocomplete="off">
                              <div class="input-group-addon" id="daterange_filter_btn">
                                   <i class="glyphicon glyphicon-search"></i>
                              </div>

                        <?php  
                        }
                        ?>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="input-group">
                        <input type="number" name="amount" class="form-control" id="amount_filter" min="0" placeholder="Amount">
                         <div class="input-group-addon" id="amount_filter_btn">
                                  <i class="glyphicon glyphicon-search"></i>
                        </div>
                       
                       </div>
                      </div>
                      <div class="col-md-4">
                        <div class="input-group">
                        <input type="number" name="area" class="form-control" id="area_filter" min="0" placeholder="Area">
                         <div class="input-group-addon" id="area_filter_btn">
                                  <i class="glyphicon glyphicon-search"></i>
                        </div>
                      </div>
                    </div>
                  </div>
                  </div>

                   <div class="customefilter pull-right">
                    <input type="text" class="search" placeholder=" Search" aria-controls="table1">
                    <button id="search_btn" class="btn btn-sm btn-primary">Search</button>
                    <button id="reset" class="btn btn-sm btn-primary">Reset</button>
                  </div>
                    <table class="table table-bordered " id="jobs-table">
                        <thead>
                            <tr>
                               <?php
                                 if(\Auth::user()->user_type==2){
                               ?>
                                <th><span>{{trans('messages.users_management.name')}}</span></th>
                                <th>{{trans('messages.users_management.email')}}</th>
                                <?php
                                  }
                                ?>
                                <th>{{trans('messages.jobs.map_name')}}</th>
                                 <th>{{trans('messages.jobs.location')}}</th>
                                <th>{{trans('messages.jobs.area')}}</th>
                                <th>{{trans('messages.jobs.cost_estimated')}}</th>
                                 <th>{{trans('messages.jobs.jobs_stauts')}}</th>
                                <th>{{trans('messages.common.status')}}</th>
                                <th>{{trans('messages.common.created_at')}}</th>
                                <?php
                                 if(\Auth::user()->user_type==3){
                                 ?>
                                <th>{{trans('messages.common.action')}}</th>
                                <?php
                                  }
                                ?>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!--/row-->
</section>
@stop

@section('page_script')
<script type="text/javascript" src="{{URL::asset('assets/back/vendors/datatables/js/jquery.dataTables.js')}}"></script>
<script type="text/javascript" src="{{URL::asset('assets/back/vendors/datatables/js/dataTables.bootstrap.js')}}"></script>
<script type="text/javascript" src="{{URL::asset('assets/back/vendors/datatables/js/dataTables.responsive.js')}}"></script>
<script src="{{URL::asset('assets/back/js/daterangepicker.js')}}" type="text/javascript"></script>
<!-- <script type="text/javascript" src="{{URL::asset('assets/back/js/pages/users/user-list.js')}}"></script> -->
       <script>
        var user_type = "{{ \Auth::user()->user_type }}";
        var columns=[

                       
                        { data: 'map_name',render:function (data, type, full, meta) {
                              if(full.map_name=='' || full.map_name==null ){
                                    return "<center>__</center>";
                              }else{
                                return ucwords(full.map_name);
                              }
                        } },
                        { data: 'location',render:function (data, type, full, meta) {
                              if(full.location=='' || full.location==null ){
                                    return "<center>__</center>";
                              }else{
                                return full.location;
                              }
                        } },
                        { data: 'area', name: 'area' },
                        { data: 'cost_estimated', render:function (data, type, full, meta) {
                              if(full.cost_estimated=='' || full.cost_estimated==null ){
                                    return "<center>__</center>";
                              }else{
                                return full.cost_estimated;
                              }
                        } },
                        {data: 'job_status',
                        render:function (data, type, full, meta) {
                               
                                if(full.job_status==0){
                                    return "<span class='badge' style='background-color:lightred;'>Queue</span>";
                                }
                                if(full.job_status==1){
                                    return "<span class='badge' style='background-color:lightyellow;'>Pending</span>";
                                }
                                if(full.job_status==2){
                                    return "<span class='badge' style='background-color:#F82A69;'>In Progress</span>";
                                }
                                if(full.job_status==3){
                                    return "<span class='badge' style='background-color:#9D01FF;'>Review</span>";
                                }
                                if(full.job_status==4){
                                    return "<span class='badge' style='background-color:#357AE8;'>Completed</span>";
                                }
                              
                            }
                        },
                        
                        {data: "is_active",
                        render:function (data, type, full, meta) {
                               
                                if(full.is_active==1){
                                    return "<button class='btn btn-success'  current_status='1' >Active</button>";
                                }else{
                                    return "<button class='btn btn-danger'  current_status='0' title='Click to change'>DeActive</button>";
                                }
                              
                            }
                        },
                        { data: 'created_at',
                        render:function (data, type, full, meta) {
                                return dateConvert(full.created_at);
                              
                            }},
                        { data: 'action',
                          "searchable": false,
                          "orderable": false 
                        }
                         
                     ];

            /* for Admin  take user name,email column & remove view(action col)*/
            var order_col_num=6;  
            if(user_type == '2') {
               var namecol={ data: 'name',render:function (data, type, full, meta) {
                                    return ucwords(full.belongs_user.full_name); 
                                } }
              var emailcol={ data: 'email',render:function (data, type, full, meta) {
                                    return full.belongs_user.email; 
                                } }
         
              columns.unshift(emailcol);
              columns.unshift(namecol);
              columns.pop();
              order_col_num=8;
             }

         $(function() {
             
               $('#jobs-table').DataTable({
               "stateSave": true,
               order: [[ order_col_num, "desc" ]], 
               processing: true,
               serverSide: true,
               // ajax: '{{ url('admin/jobs-ajaxPaggination') }}',
               "ajax": {
                           url: '{{ url('admin/jobs-ajaxPaggination') }}',
                           type: "post", // method  , by default get
                           data: function (d) {
                                   d.filter_status=$('#change_status_filter').val(),
                                   d.amount_filter=$('#amount_filter').val(),
                                   d.area_filter=$('#area_filter').val(),
                                   d.daterange=$('#daterange1').val()
                                   
                                },
               
                },
               columns:columns 
            });
         });

         </script>

         <script type="text/javascript">

          /* Hide original search */
          $( document ).ready(function() {
             $('#jobs-table_filter').hide();
          });
           //custom Reset button
           $('#reset').click( function (e) {
              $('.search').val('');
              $('#jobs-table').DataTable().search('').draw();    //search reset     
              $('#jobs-table').DataTable().order([order_col_num, 'desc']).draw();//sort reset
              $('#jobs-table').DataTable().page.len(10).draw(); // show enrty reset
          });
          
          /*cutom search button event*/
          $(document).on('click', '#search_btn', function (event) {
            var value_of_custom_search_text_box=$('.search').val(); //get value of custom serchbox
             $('#jobs-table').DataTable().search(value_of_custom_search_text_box).draw();

          });
          

          /* change custom filter*/
          $(document).on('click', '#status_filter_btn', function() {
                if($('#change_status_filter').val()!=''){
                  $('#jobs-table').DataTable().draw();
                } 
           });

          $(document).on('click', '#amount_filter_btn', function() {
                if($('#amount_filter').val()!=''){  
                  $('#jobs-table').DataTable().draw();
                }
           });

          $(document).on('click', '#area_filter_btn', function() {
               if($('#area_filter').val()!=''){
                  $('#jobs-table').DataTable().draw();
                }
           });

          $(document).on('click', '#daterange_filter_btn', function() {
                if($('#daterange1').val()!=''){
                  $('#jobs-table').DataTable().draw();
                }
           });



          function ucwords (str) {
                return (str + '').replace(/^([a-z])|\s+([a-z])/g, function ($1) {
                    return $1.toUpperCase();
                });
           }

           function dateConvert(edate)
          {
         
            var myDate = new Date(edate);
            console.log(myDate);
            var d = myDate.getDate();
            var m =  myDate.getMonth();

            m += 1; 
            if(m <= "9"){
              m="0"+m;
            }
             
            if(d <= "9"){
              d="0"+d;
            }
            var y = myDate.getFullYear();
            var h = myDate.getHours();
            if(h <= "9"){
              h="0"+h;
            }
            var min = myDate.getMinutes();
             if(min <= "9"){
              min="0"+min;
            }
            var i = myDate.getSeconds();
            if(i <= "9"){
              i="0"+i;
            }

             var newdate=(m+ "-" + d + "-" + y + " "+h+":"+min+":"+i);
             return newdate;
          } 
             
         $(document).on('click', '.delete-record', function(event) {
        
           var id = $(this).attr("id");
         
            if(confirm('Are you sure want to remove this record ?'))
            {
                $.ajax({
                   url: "{{ url('/admin/ajax-delete-advertisement') }}/"+id,
                   type: 'GET',
                   success: function(data) {
                    
                       if(data=="1"){
                        $('.del-success-msg').show().fadeOut(3000);
                        setTimeout(function(){ location.reload(); }, 3000);
                        
                       }else{
                        $('.del-error-msg').show().fadeOut(3000);
                        
                       }
                   }
                });
            }
         });

        $(document).on('click', '.change_status', function(event) {
        
           var id = $(this).attr("id");
           var current_status=$(this).attr("current_status");
           var self = this;
            if(confirm('Are you sure want to change status ?'))
            {
                $.ajax({
                   url: "{{ url('/admin/ajax-change-status') }}/"+id+"/"+current_status,
                   type: 'GET',
                   success: function(data) {
    
                       if(data=="1"){
                        $('.status-success-msg').show().fadeOut(3000);
                        setTimeout(function(){ location.reload(); }, 3000);
                        
                       }else{
                        $('.status-error-msg').show().fadeOut(3000);
                        
                       }
                   }
                });
            }
         });
        /* TAKE UP JOB */
        $(document).on('click', '.job-takeup', function(event) {
           $(this).attr("disabled",true);
           var id = $(this).attr("job-id");
           var self=this;
            if(confirm('Are you sure want to take up this job ?'))
            {
                $.ajax({
                   url: "{{ url('/admin/take-up-job-by-designer') }}/"+id,
                   type: 'GET',
                   success: function(data) {
                       $(self).attr("disabled",false);
                       if(data=="-1"){
                        $("html, body").animate({ scrollTop: 0 }, "slow");
                        $('.blacklist-error-msg').show().fadeOut(5000);
                       }
                       else if(data=="0"){
                         $("html, body").animate({ scrollTop: 0 }, "slow");
                        $('.restriction-error-msg').show().fadeOut(5000);
                       
                       }else if(data=="1"){
                         $("html, body").animate({ scrollTop: 0 }, "slow");
                        $('.takeup-success-msg').show().fadeOut(5000);
                        setTimeout(function(){ location.reload(); }, 3000);
                       }
                   }
                });
            }
         });

    $("#daterange1").daterangepicker({
      locale: {
          format: 'MM/DD/YYYY'
      }
    }).val('');

/* Laravel Flash msg remove after 5 sec*/
$("document").ready(function(){
    setTimeout(function(){
       $("div.alert").remove();
    }, 5000 ); // 5 secs
});
        
</script>
@stop

