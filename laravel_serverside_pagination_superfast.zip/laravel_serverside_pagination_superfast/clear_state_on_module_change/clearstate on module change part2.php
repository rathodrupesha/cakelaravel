<!-- Write IN FOOTER  Change segement numer as per your requirement-->
<script type="text/javascript">
	/* for state remove when module change */
var BASE_REQUEST_SEGMENT = '<?php echo Request::segment(2); ?>';

function clearDatatableFIilterOnModuleChange() {

    var archive = {}, // Notice change here
        keys = Object.keys(localStorage),
        i = keys.length;

    while ( i-- ) {
        var str1 = keys[i];
       console.log(BASE_REQUEST_SEGMENT);
        var str2 = BASE_REQUEST_SEGMENT;
        var str3 = 'DataTables';
        
        if(str1.indexOf(str3) != -1){
            if(str1.indexOf(str2) == -1) {
                localStorage.removeItem(keys[i]);
            }
        }
        archive[ keys[i] ] = localStorage.getItem( keys[i] );
    }

    return archive;
}
clearDatatableFIilterOnModuleChange();
</script>