@extends('back.layout.master')
@section('page_css')
<link rel="stylesheet" type="text/css" href="{{URL::asset('assets/back/vendors/datatables/css/dataTables.bootstrap.css')}}">

<!-- for toggle -->
<link rel="stylesheet" type="text/css" href="{{URL::asset('assets/back/css/toggleswitch.css')}}">
<style type="text/css">
td {
  word-break: break-word;
}
</style>
@stop
@section('content')
@section('title',"Advertisement")
<section class="content-header">
    <h1>{{trans('messages.advertisement.advertisement')}}</h1>
    <div class="add_new_user">
        <a href="{{ url('/admin/advertisements/create') }}" class="btn btn-sm btn-primary"><span class="glyphicon glyphicon-plus"></span> {{trans('messages.advertisement.create')}}</a>
    </div>
<!--     <ol class="breadcrumb">
        <li class="">
          <i class="fa fa-fw fa-indent"></i>
          {{trans('messages.advertisement.advertisement')}}
        </li>
    </ol> -->
</section>

<section class="content">
    <div class="row">

        <div class="col-lg-12">
            <div class="panel panel-primary filterable">
                @if ($message = Session::get('success'))
                <div class="alert alert-success alert-block laravel-flash">
                    <button type="button" class="close" data-dismiss="alert">×</button> 
                        <strong>{{ $message }}</strong>
                </div>
                @endif
                <div class="alert alert-success del-success-msg" style="display: none">
                  <strong>Success!</strong>Record deleted Successfully.
                </div>
                <div class="alert alert-danger del-error-msg" style="display: none">
                  <strong>Danger!</strong>Record not deleted try again.
                </div>

                 <!-- for status Change -->
                <div class="alert alert-success status-success-msg" style="display: none">
                  <strong>Success!</strong> Status change Successfully.
                </div>
                <div class="alert alert-danger status-error-msg" style="display: none">
                  <strong>Error!</strong> Status not change try again.
                </div>
                
                <div class="panel-body table-responsive">
                   <div class="customefilter pull-right">
                    <input type="text" class="search" placeholder=" Search" aria-controls="table1">
                    <button id="search_btn" class="btn btn-sm btn-primary">Search</button>
                    <button id="reset" class="btn btn-sm btn-primary">Reset</button>
                  </div>
                    <table class="table table-bordered " id="advertisement-table">
                        <thead>
                            <tr>
                                <th><span>{{trans('messages.advertisement.name')}}</span></th>
                                <th>{{trans('messages.advertisement.plan')}}</th>
                                <th>{{trans('messages.advertisement.click_count')}}</th>
                                <th>{{trans('messages.advertisement.view_count')}}</th>
                                <th style="width: 63px";>{{trans('messages.advertisement.start_date')}}</th>
                                <th style="width: 63px";>{{trans('messages.advertisement.end_date')}}</th>
                                <th>{{trans('messages.common.status')}}</th>
                                <th style="width: 63px";>{{trans('messages.common.created_at')}}</th>
                                <th>{{trans('messages.common.action')}}</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!--/row-->
</section>
@stop

@section('page_script')
<script type="text/javascript" src="{{URL::asset('assets/back/vendors/datatables/js/jquery.dataTables.js')}}"></script>
<script type="text/javascript" src="{{URL::asset('assets/back/vendors/datatables/js/dataTables.bootstrap.js')}}"></script>
<script type="text/javascript" src="{{URL::asset('assets/back/vendors/datatables/js/dataTables.responsive.js')}}"></script>
<!-- <script type="text/javascript" src="{{URL::asset('assets/back/js/pages/users/user-list.js')}}"></script> -->
       <script>

         $(function() {
               $('#advertisement-table').DataTable({
               "stateSave": true,
                 "stateSaveParams": function (settings, data) {
                 data.search_text = $('.search').val();
                
                },
                "stateLoadParams": function (settings, data) {
                    $('.search').val(data.search_text);
                    
                },
               order: [[7, "desc" ]], 
               processing: true,
               serverSide: true,
               ajax: '{{ url('admin/advertisement-ajaxPaggination') }}',
               columns: [
                        { data: 'advertisement_name',render:function (data, type, full, meta) {
                                return ucwords(full.advertisement_name); 
                            } },
                        { data: 'name',render:function (data, type, full, meta) {
                                return ucwords(full.name); 
                            } },
                       
                       
                       
                        { data: 'click_count', name: 'click_count',
                          render:function (data, type, full, meta) {
                                if(full.assign_plan_clicks==0){
                                  return "<center>_</center>"
                                }else{
                                  return full.click_count;
                                }
                              
                            } },
                        { data: 'view_count', name: 'view_count',
                          render:function (data, type, full, meta) {
                                if(full.assign_plan_views==0){
                                  return "<center>_</center>"
                                }else{
                                  return full.view_count;
                                }
                              
                            } },
                        { data: 'start_date',
                        render:function (data, type, full, meta) {
                                return dateConvert(full.start_date,'yes');
                              
                            }},
                        { data: 'end_date',
                        render:function (data, type, full, meta) {
                                return dateConvert(full.end_date,'yes');
                              
                            }},
                        {data: "status",
                        render:function (data, type, full, meta) {
                               
                                if(full.status==1){
                                  var checked='checked';
                                  var current_status='1';

                                }else{
                                  var checked='';
                                  var current_status='0';

                                }
                                if(full.click_count!=0 && full.click_count==full.assign_plan_clicks)
                                {
                                  var disabaled='disabled';
                                  var checked='';
                                  var style='cursor:none;';
                                }else{
                                  var disabaled='';
                                  var style="";
                                }
                              return "<label class='switch'><input type='checkbox'  class='change_status' id='"+full.id+"' current_status='"+current_status+"' "+checked+"  "+disabaled+" style="+style+"><span class='slider round'></span></label>";
                            }
                        },
                        { data: 'created_at',
                        render:function (data, type, full, meta) {
                                return dateConvert(full.created_at);
                              
                            }},
                        { data: 'action',
                          "searchable": false,
                          "orderable": false 
                        } 
                     ]
            });
         });

         </script>

         <script type="text/javascript">

         /* Hide original search */
          $( document ).ready(function() {
             $('#advertisement-table_filter').hide();

             // $('#advertisement-table').DataTable().state.clear();
             
              // $('.search').val('');
              // $('#advertisement-table').DataTable().search('').draw();    //search reset     
              // $('#advertisement-table').DataTable().order([7, 'desc']).draw();//sort reset
              // $('#advertisement-table').DataTable().page.len(10).draw(); // show enrty reset
          });
           //custom Reset button
           $('#reset').click( function (e) {
              $('.search').val('');
              $('#advertisement-table').DataTable().search('').draw();    //search reset     
              $('#advertisement-table').DataTable().order([7, 'desc']).draw();//sort reset
              $('#advertisement-table').DataTable().page.len(10).draw(); // show enrty reset
          });
          
          /*cutom search button event*/
          $(document).on('click', '#search_btn', function (event) {
            var value_of_custom_search_text_box=$('.search').val(); //get value of custom serchbox
             $('#advertisement-table').DataTable().search(value_of_custom_search_text_box).draw();

          });

           /* serch on press of enter */
          $('.search').keypress(function(event){
              var keycode = (event.keyCode ? event.keyCode : event.which);
              if(keycode == '13'){
                var value_of_custom_search_text_box=$('.search').val(); //get value of custom serchbox
                $('#advertisement-table').DataTable().search(value_of_custom_search_text_box).draw();
              }
          });

          function ucwords (str) {
                return (str + '').replace(/^([a-z])|\s+([a-z])/g, function ($1) {
                    return $1.toUpperCase();
                });
           }

          function dateConvert(edate,spl=null)
          {
         
            var myDate = new Date(edate);
           
            var d = myDate.getDate();
            var m =  myDate.getMonth();

            m += 1; 
            if(m <= "9"){
              m="0"+m;
            }
             
            if(d <= "9"){
              d="0"+d;
            }
            var y = myDate.getFullYear();
            var h = myDate.getHours();
            if(h <= "9"){
              h="0"+h;
            }
            var min = myDate.getMinutes();
             if(min <= "9"){
              min="0"+min;
            }
            var i = myDate.getSeconds();
            if(i <= "9"){
              i="0"+i;
            }
            if(spl=='yes'){
                 var newdate=(m+ "-" + d + "-" + y);  
            }else{
                 var newdate=(m+ "-" + d + "-" + y + " "+h+":"+min+":"+i);
            }
            
             return newdate;
          } 
             
         $(document).on('click', '.delete-record', function(event) {
        
           var id = $(this).attr("id");

            if(confirm('Are you sure want to remove this record ?'))
            {
                $.ajax({
                   url: "{{ url('/admin/ajax-delete-advertisement') }}/"+id,
                   type: 'GET',
                   success: function(data) {
                    
                       if(data=="1"){
                        $('#advertisement-table').DataTable().search('').draw();    //search reset
                        $('.del-success-msg').show().fadeOut(3000);
                        setTimeout(function(){ location.reload(); }, 3000);
                        
                       }else{
                        $('.del-error-msg').show().fadeOut(3000);
                        
                       }
                   }
                });
            }
         });

          $(document).on('click', '.change_status', function(event) {
  
           var id = $(this).attr("id");
           var current_status=$(this).attr("current_status");
           var self = this;
            if(confirm('Are you sure want to change status ?'))
            {
                $.ajax({
                   url: "{{ url('/admin/ajax-change-status-advt') }}/"+id+"/"+current_status,
                   type: 'GET',
                   success: function(data) {
    
                       if(data=="1"){
                        $('.status-success-msg').show().fadeOut(3000);
                        setTimeout(function(){ location.reload(); }, 3000);
                        
                       }else{
                        $('.status-error-msg').show().fadeOut(3000);
                        
                       }
                   }
                });
            }
            else{
              event.preventDefault();
            }
         });

         /* Laravel Flash msg remove after 5 sec*/
          $("document").ready(function(){
              setTimeout(function(){
                 $("div.laravel-flash").remove();
              }, 5000 ); // 5 secs
          }); 
        
         </script>
@stop

