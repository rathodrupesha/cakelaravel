<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Datatables;
use App\User;
use App\Roles;
class DisplayDataController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public $roles;
   public function __construct(Roles $roles)
    {
       $this->roles=$roles;
    }


    public function index()
    {
        
          $c=User::with(['roles'])->get()->toArray();  //join role table with user
        // echo "<pre>";print_r($c);exit;
//           Array
// (
//     [0] => Array
//         (
//             [id] => 1
//             [role_id] => 1
//             [first_name] => 
//             [last_name] => 
//             [email] => ansariakram6478@gmail.com
//             [mobile_no] => 98988
//             [otp] => 0
//             [role] => 0
//             [created_at] => 2018-07-20 00:00:00
//             [updated_at] => 2018-06-26 00:00:00
//             [roles] => Array
//                 (
//                     [id] => 1
//                     [name] => adminrole
//                     [created_at] => 2018-12-04 11:14:39
//                     [updated_at] => -0001-11-30 00:00:00
//                 )

//         )

//     [1] => Array
//         (
//             [id] => 5
//             [role_id] => 2
//             [first_name] => qwerty
//             [last_name] => erfg
//             [email] => test@gmail.com
//             [mobile_no] => 98988456
//             [otp] => 0
//             [role] => 0
//             [created_at] => 2018-07-20 00:00:00
//             [updated_at] => 2018-06-26 00:00:00
//             [roles] => Array
//                 (
//                     [id] => 2
//                     [name] => userrole
//                     [created_at] => 2018-12-04 11:14:39
//                     [updated_at] => -0001-11-30 00:00:00
//                 )

//         )

// )
        
        return datatables($c)->addColumn('new_added_column', function($c) {
                    return $c['roles']['name'];   //here fetch per user's row data (no need to foreach)
                })->addColumn('action', function ($c) {
           
                $id=$c['id'];
                $editurl=url('/admin/advertisements/'.$id.'/edit');
                $viewurl=url('/admin/advertisements/'.$id);
                $action="<a href='".$viewurl."' class='btn btn-xs btn-primary edit-record'><i class='glyphicon glyphicon-eye-open'></i> View</a>&nbsp;<a href='".$editurl."' class='btn btn-xs btn-primary edit-record'><i class='glyphicon glyphicon-edit'></i> Edit</a>&nbsp;<button type='button' class='btn btn-xs btn-primary delete-record' id='".$id."'><i class='glyphicon glyphicon-trash'></i> Delete</button>";
                return $action;
            }
        })->addColumn('image', function ($data) {
            $img_path = "storage/uploads/".$data['profile_image'];
            $path=asset($img_path);
            if (!empty($data['profile_image']) && file_exists($img_path)) {
                $src=$path;
            } else {
                $src='';
            }
            return $src;
        })->toJson();
    }

       public function changeStaus($id, $curent_status)
    {
        if ($curent_status=='1') {
            $is_active=0;
        }

        if ($curent_status=='0') {
            $is_active=1;
        }
     
        $isUpdate=User::where('id',$id)
                        ->update([
                                  'is_active'=> $is_active,
                                  'updated_at' => Carbon::now()
                                ]);
        if ($isUpdate) {
            return '1';
        } else {
            return '0';
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //  $c=User::with(['roles'])->get()->toArray();
        // echo "<pre>";print_r($c);exit;
        return view('displaydata');
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
