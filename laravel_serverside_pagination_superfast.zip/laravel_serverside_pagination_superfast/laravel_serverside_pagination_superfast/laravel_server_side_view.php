
<html lang="en">
<head>
    <title>Laravel DataTables Tutorial Example</title>
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">  
        <link  href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
</head>
      <body>
         <div class="container">
               <h2>Laravel DataTables Tutorial Example</h2>

               <!-- -----------DELETE FLASH MESSAGE START---------------------->
                <div class="alert alert-success del-success-msg" style="display: none">
                  <strong>Success!</strong>Record deleted Successfully !.
                </div>
                <div class="alert alert-danger del-error-msg" style="display: none">
                  <strong>Danger!</strong>Record not deleted try again !.
                </div> 
             <!-- -----------DELETE FLASH MESSAGE END---------------------->

            <table class="table table-stipped" id="table">
               <thead>
                  <tr>
                     <th>Id</th>
                     <th>Name</th>
                     <th>Email</th>
                    <!--  <th>roles</th> -->
                     <th>New col</th>
                      <th>Status</th>
                       <th>Created At</th>
                        <th>Action</th>
                  </tr>
               </thead>
            </table>
         </div>
       <script>
         $(function() {
               $('#table').DataTable({
                order: [[ 8, "desc" ]],    //DEFAULT ORDER CREATED AT COLM
               processing: true,
               serverSide: true,
               ajax: '{{ url('index') }}',
               columns: [
                        { data: 'id', name: 'id' },
                        { data: 'first_name', name: 'name' },
                        { data: 'email', name: 'email' },
                        // { data: 'created_at', name: 'create' },

                        // {data: "roles",
                        // render:function (data, type, full, meta) {
                        //         console.log(full);
                        //        return full.roles.name
                        //     },
                        // "searchable": false,
                        // "orderable": false

                        // },
                        
                        { data: 'new_added_column' } ,

                        {data: "status",
                        render:function (data, type, full, meta) {
                                console.log(full);
                                if(full.status==1){
                                    return "<button class='btn btn-success'>Active</button>";
                                }else{
                                    return "<button class='btn btn-danger'>DeActive</button>";
                                }
                              
                            }
                        },
                        { data: 'created_at',
                        render:function (data, type, full, meta) {
                                return dateConvert(full.created_at);
                              
                            }},

                        { data: 'action',
                          "searchable": false,
                          "orderable": false 
                        }
                     ]
            });
         });
         </script>


          <script type="text/javascript">

          function ucwords (str) {
                return (str + '').replace(/^([a-z])|\s+([a-z])/g, function ($1) {
                    return $1.toUpperCase();
                });
           }

          function dateConvert(edate)
          {
         
            var myDate = new Date(edate);
            console.log(myDate);
            var d = myDate.getDate();
            var m =  myDate.getMonth();

            m += 1; 
            if(m <= "9"){
              m="0"+m;
            }
            var y = myDate.getFullYear();
            var h = myDate.getHours();
            var min = myDate.getMinutes();
            var i = myDate.getSeconds();

             var newdate=(m+ "-" + d + "-" + y + " "+h+":"+min+":"+i);
             return newdate;
          } 
             
         $(document).on('click', '.delete-record', function(event) {
        
           var id = $(this).attr("id");

            if(confirm('Are you sure want to remove this record ?'))
            {
                $.ajax({
                   url: "{{ url('/admin/ajax-delete-advertisement') }}/"+id,
                   type: 'GET',
                   success: function(data) {
                    
                       if(data=="1"){
                        $('.del-success-msg').show().fadeOut(3000);
                        setTimeout(function(){ location.reload(); }, 3000);
                        
                       }else{
                        $('.del-error-msg').show().fadeOut(3000);
                        
                       }
                   }
                });
            }
         });
        
         </script>
   </body>
</html>