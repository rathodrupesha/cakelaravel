<?php

  require __DIR__ . '/vendor/autoload.php';
 // require('pusher-php-server-master/lib/Pusher.php');

  $options = array(
    'cluster' => 'ap2',//mt1
    'encrypted' => true
  );
  $pusher = new Pusher\Pusher(
    '6d9ff427d55c80504327',
    '4dfb551e78130c719bbf',
    '581124',
    $options
  );
  
  $data['message'] = '<div id="London" class="tabcontent"><h3>London</h3><p>London is the capital city of England.</p></div>';
  $data['message2']="this is my channel 2 for event 2";
  $c=$pusher->trigger('my-channel', 'my-event', $data);



//   $batch = array();
// $batch[] = array('channel' => 'my-channel1', 'name' => 'my_event1', 'data' => array('hello' => 'world'));
// $batch[] = array('channel' => 'my-channel2', 'name' => 'my_event2', 'data' => array('myname' => 'bob'));
// $pusher->triggerBatch($batch);


 
 // echo $c; 

?>