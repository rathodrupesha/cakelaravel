@extends('layout.master')
@section('title','Sales List')
@section('bread_2','>> Sales')
@section('contents')

    <div class="inner_content_w3_agile_info two_in">
        <h2 class="w3_inner_tittle">Sales</h2>
        <div class="blank_w3ls_agile">
            <div class="blank-page agile_info_shadow">
                
                <div class="row well">
                     <?php
                      if(!empty($sp) || !empty($st) || !empty($year) || !empty($month_year) || !empty($week) || !empty($daily) || !empty($custome) || !empty($stock)){

                        $stock_div_style="style='margin-top: -7px;'";
                     ?>
                      <div class="row">
                      <a href="{{url('admin/deals')}}">
                       <button class="btn pull-right btn-warning btn-sm" style="margin-top:-19px;margin-right: -4px;padding: 5px; "> Reset
                       </button>
                      </a>
                      </div>
                     <?php }else{
                        $stock_div_style="";
                      } ?>
                    <div class="col-md-3 ">
                     <strong>Salesperson :</strong>
                     <select class="form-control" id="salesperson_filter">
                      <option value="default">--Select option--</option>
                      <?php foreach($SalesPersondata as $key => $value) {

                         if($value['DTUser_id']==$sp){
                            $selected='selected';
                         }else{
                            $selected='';
                         }
                         
                      ?>
                        <option value="{{$value['DTUser_id']}}" <?php echo $selected;?>>{{ $value['name']}}</option>
                      <?php } ?>  
                     </select>
                    </div>
                    <div class="col-md-3">
                      <strong>Date :</strong>
                      <div class="ymwdc_div"> 
                        <?php 
                        if(!empty($year)){
                          $year_style='style="display: block;"';
                          $yr_selected='selected';
                          $year_value=$year;
                        }else{
                          $year_style='style="display: none;"';
                          $yr_selected='';
                          $year_value='';
                        } 

                        if(!empty($month_year)){
                          $month_yr_style='style="display: block;"';
                          $month_yr_selected='selected';
                          $month_year_array=explode("-",$month_year);
                          $month1=$month_year_array[0];
                          $month2=$month_year_array[1];
                        }else{
                          $month_yr_style='style="display: none;"';
                          $month_yr_selected='';
                          $month_year_value='';
                          $month1='';
                          $month2='';
                        }

                        if(!empty($week)){
                          $week_style='style="display: block;"';
                          $week_selected='selected';
                          $week_value=$week;
                        }else{
                          $week_style='style="display: none;"';
                          $week_selected='';
                          $week_value='';
                        } 

                        if(!empty($daily)){
                          $daily_style='style="display: block;"';
                          $daily_selected='selected';
                          $daily_value=$daily;
                        }else{
                          $daily_style='style="display: none;"';
                          $daily_selected='';
                          $daily_value='';
                        } 

                        if(!empty($custome)){
                          $custome_style='style="display: block;"';
                          $custome_selected='selected';
                          $custome_value=$custome;
                        }else{
                          $custome_style='style="display: none;"';
                          $custome_selected='';
                          $custome_value='';
                        } 

                        ?>



                        <select class="form-control" id="date_filter">
                         <option value="default">--Select option--</option>
                         <option value="Yearly" <?php echo $yr_selected;?>>Yearly</option>
                         <option value="Monthly" <?php echo $month_yr_selected;?>>Monthly</option>
                         <option value="Weekly" <?php echo $week_selected;?>>Weekly</option>
                         <option value="Daily" <?php echo $daily_selected;?>>Daily</option>
                         <option value="Custom" <?php echo $custome_selected;?>>Custom</option>
                       </select>
                      </div>
                     
                      <div class="year_div" <?php echo $year_style; ?>> 
                       <select class="form-control" id="year_id">
                          <option value="default">--Select years--</option> 
                       <?php  
                         $yearsRange=range("2000",date("Y")); 
                         foreach ($yearsRange as $key => $value) {  ?>
                          <option value="<?php echo $value; ?>" <?php if($value==$year_value){echo $yr_selected;} ?>><?php echo $value; ?></option>
                        <?php } ?> 
                        </select>
                      </div>

                      <div class="month_div" <?php echo $month_yr_style; ?>> 
                            
                             <select class="form-control" id="month_id1">
                                <option value="default">--Select Month--</option> 
                              <?php  
                                
                               for ($m=1; $m<=12; $m++){ ?>    
                                  $month_name=date('F', mktime(0,0,0,$m, 1, date('Y')));
                                  <option value="<?php echo $m; ?>" <?php if($m==$month1){ echo $month_yr_selected;}?>><?php echo date('F', mktime(0,0,0,$m, 1, date('Y'))); ?></option>
                              <?php } ?>

                              </select>
                            
                           
                               <select class="form-control" id="month_id2">
                                <option value="default">--Select years--</option> 
                                 <?php  
                                   $yearsRange=range("2015",date("Y")); 
                                   foreach ($yearsRange as $key => $value) {  ?>
                                    <option value="<?php echo $value; ?>" <?php if($value==$month2){ echo $month_yr_selected;}?>><?php echo $value; ?></option>
                                  <?php } ?> 
                              </select>
                            
                      </div>

                      <div class="week_div" <?php echo $week_style; ?>> 
                         
                          <select class="form-control" id="week_id">
                             <option value="default">--Select Week--</option> 
                              <?php 
                               $year=date('Y');
                               $week=52;
                               $weekNumber = date("W"); 
                              for($i=1;$i<=$weekNumber;$i++){
                                $time = strtotime("1 January $year", time());
                                $day = date('w', $time);
                                // $time += ((7*$i)+1-$day)*24*3600;
                                $time += ((7*$i)-$day)*24*3600;
                                $dates[0] = date('j/n/Y', $time);
                                $time += 6*24*3600;
                                $dates[1] = date('j/n/Y', $time);
                                $dateRange=$dates[0]." - ".$dates[1]; 
                                
                               ?> 
                              <option value="<?php echo $dateRange; ?>" <?php if($dateRange==$week_value){echo $week_selected; }?>><?php echo $dateRange; ?></option>
                             <?php } ?>
                          </select>
                      </div>

                      <div class="daily_div" <?php echo $daily_style; ?>>  
                          <input type="text" class="form-control dateinput" name="daily_datepicker" id="daily_id" placeholder="select date" value="<?php echo $daily_value;?>" onchange="dailyFilter()">
                          
                      </div>
                           
                      <div class="custome_div" <?php echo $custome_style; ?>>  
                           <input type="text" class="form-control " name="custome_daterange" id='custome_id' placeholder="select Date-Range"  >
                      </div>

                    </div>
                    <div class="col-md-3">
                      <strong>Type of Sales :</strong>
                      <select class="form-control" id="salesType_filter">
                        
                       <option value="default">--Select option--</option>
                       <option value="C" <?php if($st=="C"){ echo "selected";}?>>Cash/Bank Drafts</option>
                       <option value="I" <?php if($st=="I"){ echo "selected";}?>>In-House</option>
                       <option value="O" <?php if($st=="O"){ echo "selected";}?>>Outside Finance</option>
                     </select>
                    </div>
                    <div class="col-md-3" >
                      <strong>Stock number :</strong>
                     <input type="text" class="form-control" name="search_by_stockno" id="stock_search" placeholder="Enter Stock Number">
                    </div>
                    
                </div>
                
               
                 <!--  <a href="{{ url('/admin/users/create') }}" class="btn btn-success btn-sm" title="Add New role" style="margin-bottom:15px;">
                      <i class="fa fa-plus" aria-hidden="true"></i> Add New
                  </a> --> 
                </br>
              
                <table class="table table-striped csv_export_table" id="myTable">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>DealID</th>
                    <th>Deal Created</th>
                    <th>Deal Type</th>
                    <th>Fullname <br>Cellphone <br> Email</th>
                    <th>Desired Vehicle Desc</th>
                    <th>SalesPerson</th>
                    <th>Funded Flage</th>
                    <th>Deal Status Desc</th>
                  </tr>
                </thead>
                <tbody>
      
                       @foreach($dealsdata as $key=>$value)
                          
                      <tr>
                        <td>{{ ++$key }}</td>
                        <td>{{ $value['Deal_ID'] }}</td>
                        <td>{{ $value['DateCreated'] }}</td>
                        <td>
                         <?php
                             if($value['DealType']=='F'){
                              echo "Finance Deal";
                             }elseif($value['DealType']=='I'){
                              echo "Inhouse Finance Deal";
                             }elseif($value['DealType']=='C'){
                              echo "Cash Deal";
                             }elseif($value['DealType']=='O'){
                              echo "Outside Finance Deal";
                             }

                         ?>
                       </td>
                        <td>{{ $value['FName'] }}</br> {{ $value['LName'] }}</br>{{ $value['CPhone']}}</br>{{$value['Email']}} </td>
                        <td></td>
                        <td>{{ $value['name'] }}</td>
                        <td>
                          <?php 
                              if($value['Funded']==1){ $funded_flage="<span class='label label-info'><strongYes</strong</span>";} else{$funded_flage="<span class='label label-default'><strong>No</strong</span>"; }
                              echo $funded_flage;
                          ?> 
                          
                        </td>
                        <td>{{ $value['StatusDesc'] }}</td>  
                      </tr>
                      @endforeach  
                </tbody>
              </table>
              <div class="row" id="resetbutton_id">
                  <button class="btn pull-right btn-warning btn-sm csv_export_button" style="margin-right:10px;" ><i class="fa fa-arrow-down" aria-hidden="true"></i> Export to CSV
                  </button>
              </div>
            </div>
                   
        </div>
    </div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $("#date_filter").change(function(){
      var date_filter_value=$(this).val();
        
        if(date_filter_value !="default"){ 
            
            switch (date_filter_value) {
                  case "Yearly":
                        $('.year_div').show();
                        $('.month_div').hide();
                        $('.week_div').hide();
                        $('.daily_div').hide();
                        $('.custome_div').hide();                      
                      break;
                  case "Monthly":
                        $('.month_div').show();
                        $('.year_div').hide();
                        $('.week_div').hide();
                        $('.daily_div').hide();
                        $('.custome_div').hide();
                      break;
                  case "Weekly":
                        $('.week_div').show();
                        $('.year_div').hide();
                        $('.month_div').hide();
                        $('.daily_div').hide();
                        $('.custome_div').hide(); 
                      break;
                  case "Daily":
                        $('.daily_div').show();
                        $('.year_div').hide();
                        $('.month_div').hide();
                        $('.week_div').hide();
                        $('.custome_div').hide(); 
                      break;
                  case "Custom":
                        $('.custome_div').show();
                        $('.year_div').hide();
                        $('.month_div').hide();
                        $('.week_div').hide();
                        $('.daily_div').hide();
                      break;
                 
              }
        }else{
                $('.custome_div').hide();
                $('.year_div').hide();
                $('.month_div').hide();
                $('.week_div').hide();
                $('.daily_div').hide();


        }
    });
});
</script>
<script>
         $(document).ready(function(){
            $('#salesperson_filter').change(function(e){
             
                var id=$(this).val();
                var isGET = $(location).attr('search'); //get method exist or not
                if(isGET!=''){
                       
                        //chedck other filter value is present or not
                        if(window.location.href.indexOf('st=') > 0 || window.location.href.indexOf('year') > 0 || window.location.href.indexOf('week=') > 0 || window.location.href.indexOf('daily=') > 0 || window.location.href.indexOf('custome=') > 0 || window.location.href.indexOf('stock=') > 0 || window.location.href.indexOf('month_year=') > 0){
                              
                             // var replaceUrl=urlParams.replace("&st="+old_st_value, "&st="+id);
                              //if this filter(sp) value present  with other then if othre wise else for only this filter value append
                              if (window.location.href.indexOf('sp=') > 0)  //check in url sp= present or not
                              {  
                                /* sp & st both present*/  /* then value update of st param*/
                                 var urlParams = $(location).attr('search');// get "?blah.." (query string)
                                 var old_st_value = GetURLParameter('sp'); //get url pram of sp's value
                                 var replaceUrl=urlParams.replace("sp="+old_st_value, "sp="+id);
                                 
                                 window.location.href=replaceUrl;
                              }
                              else{
                                    /* only sp present */
                                   var urlParams = $(location).attr('search');// get "?blah.." (query string)
                                   //var urlParams1=urlParams+"&st="+id;
                                   var url=window.location.href;
                                   window.location.href=url+"&sp="+id;

                              }

                        }
                        else{
                              if (window.location.href.indexOf('sp=') > 0)  //check in url sp= present or not
                              {  
                                       /* value update of st param*/
                                       var urlParams = $(location).attr('search');// get "?blah.." (query string)
                                       var old_st_value = GetURLParameter('sp'); //get url pram of sp's value
                                       var replaceUrl=urlParams.replace("sp="+old_st_value, "sp="+id);
                                       
                                       window.location.href=replaceUrl;
                              }
                            } 

                }else{
                   if(id!="default")
                   {  
                    var url=window.location.href;
                    window.location.href=url+"?sp="+id;
                   }
                }

            });
         


      $('#salesType_filter').change(function(e){
               
                var id=$(this).val();
                var isGET = $(location).attr('search'); //get method exist or not
                if(isGET!='')
                {
                       
                        if(window.location.href.indexOf('sp=') > 0 || window.location.href.indexOf('year') > 0 || window.location.href.indexOf('week=') > 0 || window.location.href.indexOf('daily=') > 0 || window.location.href.indexOf('custome=') > 0 || window.location.href.indexOf('stock=') > 0 || window.location.href.indexOf('month_year=') > 0){
                              
                             // var replaceUrl=urlParams.replace("&st="+old_st_value, "&st="+id);
                              if (window.location.href.indexOf('st=') > 0)  //check in url sp= present or not
                              {  
                                /* sp & st both present*/  /* then value update of st param*/
                                 var urlParams = $(location).attr('search');// get "?blah.." (query string)
                                 var old_st_value = GetURLParameter('st'); //get url pram of sp's value
                                 var replaceUrl=urlParams.replace("st="+old_st_value, "st="+id);
                                 
                                 window.location.href=replaceUrl;
                              }
                              else{
                                    /* only sp present & st not present */
                                   var urlParams = $(location).attr('search');// get "?blah.." (query string)
                                   //var urlParams1=urlParams+"&st="+id;
                                   var url=window.location.href;
                                   window.location.href=url+"&st="+id;

                              }

                        }
                        else{
                              if (window.location.href.indexOf('st=') > 0)  //check in url sp= present or not
                              {  
                                       /* value update of st param*/
                                       var urlParams = $(location).attr('search');// get "?blah.." (query string)
                                       var old_st_value = GetURLParameter('st'); //get url pram of sp's value
                                       var replaceUrl=urlParams.replace("st="+old_st_value, "st="+id);
                                       
                                       window.location.href=replaceUrl;
                              }
                            }  

                        

                }else{
                   if(id!="default")
                   {  
                    var url=window.location.href;
                    window.location.href=url+"?st="+id;
                   }
                }

      });
      

     $('#year_id').change(function(e){
          var year=$(this).val();
          var isGET = $(location).attr('search'); //get method exist or not
                if(isGET!='')
                {
                       
                        if(window.location.href.indexOf('sp=') > 0 || window.location.href.indexOf('st=') > 0 || window.location.href.indexOf('week=') > 0 || window.location.href.indexOf('daily=') > 0 || window.location.href.indexOf('custome=') > 0 || window.location.href.indexOf('stock=') > 0 || window.location.href.indexOf('month_year=') > 0){
                              
                             // var replaceUrl=urlParams.replace("&st="+old_st_value, "&st="+id);
                              if (window.location.href.indexOf('year=') > 0)  //check in url sp= present or not
                              {  
                                /* sp & st both present*/  /* then value update of st param*/
                                 var urlParams = $(location).attr('search');// get "?blah.." (query string)


                                 var urlParams=urlParams.replace("month_year="+GetURLParameter('month_year'), "");
                                 var urlParams=urlParams.replace("week="+GetURLParameter('week'), "");
                                 var urlParams=urlParams.replace("daily="+GetURLParameter('daily'), "");
                                 var urlParams=urlParams.replace("custome="+GetURLParameter('custome'), "");


                                 var old_year_value = GetURLParameter('year'); //get url pram of sp's value
                                 var replaceUrl=urlParams.replace("year="+old_year_value, "year="+year);
                                 
                                 window.location.href=replaceUrl;
                              }
                              else{
                                    /* only sp present & st not present */
                                   var urlParams = $(location).attr('search');// get "?blah.." (query string)
                                    var urlParams=urlParams.replace("month_year="+GetURLParameter('month_year'), "");
                                   var urlParams=urlParams.replace("week="+GetURLParameter('week'), "");
                                   var urlParams=urlParams.replace("daily="+GetURLParameter('daily'), "");
                                   var urlParams=urlParams.replace("custome="+GetURLParameter('custome'), "");
                                   window.location.href=urlParams+"&year="+year;
                                   // var url=window.location.href;
                                   // window.location.href=url+"&year="+year;

                              }

                        }
                        else{
                              if (window.location.href.indexOf('year=') > 0)  //check in url sp= present or not
                              {  
                                       /* value update of st param*/
                                       var urlParams = $(location).attr('search');// get "?blah.." (query string)
                                       var old_year_value = GetURLParameter('year'); //get url pram of sp's value
                                       var replaceUrl=urlParams.replace("year="+old_year_value, "year="+year);
                                       
                                       window.location.href=replaceUrl;
                              }
                            }  

                        

                }else{
                   if(year!="default")
                   {  
                    var url=window.location.href;
                    window.location.href=url+"?year="+year;
                   }
                }
      });


      $('#month_id2').change(function(e){

        var month=$('#month_id1').val();
        var m_year=$(this).val();
        var month_year=month+"-"+m_year;

        var isGET = $(location).attr('search'); //get method exist or not
        if(isGET!='')
        {
               
                if(window.location.href.indexOf('sp=') > 0 || window.location.href.indexOf('st=') > 0 || window.location.href.indexOf('year=') > 0 || window.location.href.indexOf('daily=') > 0 || window.location.href.indexOf('week=') > 0 || window.location.href.indexOf('custome=') > 0 || window.location.href.indexOf('stock=') > 0){
                      
                     // var replaceUrl=urlParams.replace("&st="+old_st_value, "&st="+id);
                      if (window.location.href.indexOf('month_year=') > 0)  //check in url sp= present or not
                      {  
                        /* sp & st both present*/  /* then value update of st param*/
                         var urlParams = $(location).attr('search');// get "?blah.." (query string)

 
                       var urlParams=urlParams.replace("year="+GetURLParameter('year'), "");
                       var urlParams=urlParams.replace("week="+GetURLParameter('week'), "");
                       var urlParams=urlParams.replace("daily="+GetURLParameter('daily'), "");
                       var urlParams=urlParams.replace("custome="+GetURLParameter('custome'), "");

                         var old_month_year_value = GetURLParameter('month_year'); //get url pram of sp's value
                         var replaceUrl=urlParams.replace("month_year="+old_month_year_value, "month_year="+month_year);
                         
                         window.location.href=replaceUrl;
                      }
                      else{
                             //only sp present & st not present 
                           var urlParams = $(location).attr('search');// get "?blah.." (query string)
                           var urlParams=urlParams.replace("year="+GetURLParameter('year'), "");
                           var urlParams=urlParams.replace("week="+GetURLParameter('week'), "");
                           var urlParams=urlParams.replace("daily="+GetURLParameter('daily'), "");
                           var urlParams=urlParams.replace("custome="+GetURLParameter('custome'), "");
                           window.location.href=urlParams+"&month_year="+month_year;
                           // var url=window.location.href;
                           // window.location.href=url+"&month_year="+month_year;

                      }

                }
                else{
                      if (window.location.href.indexOf('month_year=') > 0)  //check in url sp= present or not
                      {  
                               /* value update of st param*/
                               var urlParams = $(location).attr('search');// get "?blah.." (query string)
                               var old_month_year_value = GetURLParameter('month_year'); //get url pram of sp's valueweek
                               var replaceUrl=urlParams.replace("month_year="+old_month_year_value, "month_year="+month_year);
                               
                               window.location.href=replaceUrl;
                      }
                    }  


        }else{
           if(month!="default" && m_year!="default")
           {  
            var url=window.location.href;
            window.location.href=url+"?month_year="+month_year;
           }
        }
        

     });


      $('#week_id').change(function(e){
          var week=$(this).val();
          var isGET = $(location).attr('search'); //get method exist or not
                if(isGET!='')
                {
                       
                        if(window.location.href.indexOf('sp=') > 0 || window.location.href.indexOf('st=') > 0 || window.location.href.indexOf('year=') > 0 || window.location.href.indexOf('daily=') > 0 || window.location.href.indexOf('custome=') > 0 || window.location.href.indexOf('stock=') > 0 || window.location.href.indexOf('month_year=') > 0){
                              
                             // var replaceUrl=urlParams.replace("&st="+old_st_value, "&st="+id);
                              if (window.location.href.indexOf('week=') > 0)  //check in url sp= present or not
                              {  
                                /* sp & st both present*/  /* then value update of st param*/
                                 
                              var urlParams = $(location).attr('search');// get "?blah.." (query string)
                              var urlParams=urlParams.replace("year="+GetURLParameter('year'), "");
                              var urlParams=urlParams.replace("week="+GetURLParameter('month_year'), "");
                              var urlParams=urlParams.replace("daily="+GetURLParameter('daily'), "");
                              var urlParams=urlParams.replace("custome="+GetURLParameter('custome'), "");
                               

                                 var old_week_value = GetURLParameter('week'); //get url pram of sp's value
                                 var replaceUrl=urlParams.replace("week="+old_week_value, "week="+week);
                                 
                                 window.location.href=replaceUrl;
                              }
                              else{
                                    /* only sp present & st not present */
                                   var urlParams = $(location).attr('search');// get "?blah.." (query string)
                                  
                                   var urlParams=urlParams.replace("year="+GetURLParameter('year'), "");
                                   var urlParams=urlParams.replace("month_year="+GetURLParameter('month_year'), "");
                                   var urlParams=urlParams.replace("daily="+GetURLParameter('daily'), "");
                                   var urlParams=urlParams.replace("custome="+GetURLParameter('custome'), "");
                                   window.location.href=urlParams+"&week="+week;
                                   // var url=window.location.href;
                                   // window.location.href=url+"&week="+week;

                              }

                        }
                        else{
                              if (window.location.href.indexOf('week=') > 0)  //check in url sp= present or not
                              {  
                                       /* value update of st param*/
                                       var urlParams = $(location).attr('search');// get "?blah.." (query string)
                                       var old_week_value = GetURLParameter('week'); //get url pram of sp's valueweek
                                       var replaceUrl=urlParams.replace("week="+old_week_value, "week="+week);
                                       
                                       window.location.href=replaceUrl;
                              }
                            }  

                        

                }else{
                   if(week!="default")
                   {  
                    var url=window.location.href;
                    window.location.href=url+"?week="+week;
                   }
                }
      });


     $('#custome_id').change(function(e){
          var custome=$(this).val();
          var isGET = $(location).attr('search'); //get method exist or not
                if(isGET!='')
                {
                       
                        if(window.location.href.indexOf('sp=') > 0 || window.location.href.indexOf('st=') > 0 || window.location.href.indexOf('year=') > 0 || window.location.href.indexOf('daily=') > 0 || window.location.href.indexOf('week=') > 0 || window.location.href.indexOf('stock=') > 0 || window.location.href.indexOf('month_year=') > 0){
                              
                             // var replaceUrl=urlParams.replace("&st="+old_st_value, "&st="+id);
                              if (window.location.href.indexOf('custome=') > 0)  //check in url sp= present or not
                              {  
                                /* sp & st both present*/  /* then value update of st param*/
                              
                              var urlParams = $(location).attr('search');// get "?blah.." (query string)
                              var urlParams=urlParams.replace("year="+GetURLParameter('year'), "");
                              var urlParams=urlParams.replace("month_year="+GetURLParameter('month_year'), "");
                              var urlParams=urlParams.replace("daily="+GetURLParameter('daily'), "");
                              var urlParams=urlParams.replace("week="+GetURLParameter('week'), "");


                                 var old_custome_value = GetURLParameter('custome'); //get url pram of sp's value
                                 var replaceUrl=urlParams.replace("custome="+old_custome_value, "custome="+custome);
                                 
                                 window.location.href=replaceUrl;
                              }
                              else{
                                    /* only sp present & st not present */
                                  
                                   var urlParams = $(location).attr('search');// get "?blah.." (query string)
                                  var urlParams=urlParams.replace("year="+GetURLParameter('year'), "");
                                  var urlParams=urlParams.replace("month_year="+GetURLParameter('month_year'), "");
                                  var urlParams=urlParams.replace("daily="+GetURLParameter('daily'), "");
                                  var urlParams=urlParams.replace("week="+GetURLParameter('week'), "");
                                  window.location.href=urlParams+"&custome="+custome;
                                   // var url=window.location.href;
                                   // window.location.href=url+"&custome="+custome;

                              }

                        }
                        else{
                              if (window.location.href.indexOf('custome=') > 0)  //check in url sp= present or not
                              {  
                                       /* value update of st param*/
                                       var urlParams = $(location).attr('search');// get "?blah.." (query string)
                                       var old_custome_value = GetURLParameter('custome'); //get url pram of sp's valueweek
                                       var replaceUrl=urlParams.replace("custome="+old_custome_value, "custome="+custome);
                                       
                                       window.location.href=replaceUrl;
                              }
                            }  

                        

                }else{
                   if(custome!="default")
                   {  
                    var url=window.location.href;
                    window.location.href=url+"?custome="+custome;
                   }
                }
     });

    
    $('#stock_search').on('keyup', function() {

        var stock_ch_length=$(this).val().length;
        var stock=$(this).val();

        if(stock_ch_length>=3)
        {
 
          var isGET = $(location).attr('search'); //get method exist or not
                if(isGET!='')
                {
                       
                        if(window.location.href.indexOf('sp=') > 0 || window.location.href.indexOf('st=') > 0 || window.location.href.indexOf('year=') > 0 || window.location.href.indexOf('daily=') > 0 || window.location.href.indexOf('week=') > 0 || window.location.href.indexOf('custome=') > 0 || window.location.href.indexOf('month_year=') > 0){
                              
                             // var replaceUrl=urlParams.replace("&st="+old_st_value, "&st="+id);
                              if (window.location.href.indexOf('stock=') > 0)  //check in url sp= present or not
                              {  
                                /* sp & st both present*/  /* then value update of st param*/
                                 var urlParams = $(location).attr('search');// get "?blah.." (query string)
                                 var old_stock_value = GetURLParameter('stock'); //get url pram of sp's value
                                 var replaceUrl=urlParams.replace("stock="+old_stock_value, "stock="+stock);
                                 
                                 window.location.href=replaceUrl;
                              }
                              else{
                                     //only sp present & st not present 
                                   var urlParams = $(location).attr('search');// get "?blah.." (query string)
                                   //var urlParams1=urlParams+"&st="+id;
                                   var url=window.location.href;
                                   window.location.href=url+"&stock="+stock;

                              }

                        }
                        else{
                              if (window.location.href.indexOf('stock=') > 0)  //check in url sp= present or not
                              {  
                                       /* value update of st param*/
                                       var urlParams = $(location).attr('search');// get "?blah.." (query string)
                                       var old_stock_value = GetURLParameter('stock'); //get url pram of sp's valueweek
                                       var replaceUrl=urlParams.replace("stock="+old_stock_value, "stock="+stock);
                                       
                                       window.location.href=replaceUrl;
                              }
                            }  

                        

                }else{
                   if(stock!="default")
                   {  
                    var url=window.location.href;
                    window.location.href=url+"?stock="+stock;
                   }
                }
        }

     });



  });



     function dailyFilter(){
        
         var daily=$('#daily_id').val();
         var isGET = $(location).attr('search'); //get method exist or not
                if(isGET!='')
                {
                       
                        if(window.location.href.indexOf('sp=') > 0 || window.location.href.indexOf('st=') > 0 || window.location.href.indexOf('year=') > 0 || window.location.href.indexOf('week=') > 0 || window.location.href.indexOf('custome=') > 0 || window.location.href.indexOf('stock=') > 0 || window.location.href.indexOf('month_year=') > 0){
                              
                             // var replaceUrl=urlParams.replace("&st="+old_st_value, "&st="+id);
                              if (window.location.href.indexOf('daily=') > 0)  //check in url sp= present or not
                              {  
                                /* sp & st both present*/  /* then value update of st param*/
                                
                                var urlParams = $(location).attr('search');// get "?blah.." (query string)
                                var urlParams=urlParams.replace("year="+GetURLParameter('year'), "");
                                var urlParams=urlParams.replace("month_year="+GetURLParameter('month_year'), "");
                                var urlParams=urlParams.replace("custome="+GetURLParameter('custome'), "");
                                var urlParams=urlParams.replace("week="+GetURLParameter('week'), "");


                                 var old_daily_value = GetURLParameter('daily'); //get url pram of sp's value
                                 var replaceUrl=urlParams.replace("daily="+old_daily_value, "daily="+daily);
                                 
                                 window.location.href=replaceUrl;
                              }
                              else{
                                    /* only sp present & st not present */
                                   var urlParams = $(location).attr('search');// get "?blah.." (query string)
                                   var urlParams=urlParams.replace("year="+GetURLParameter('year'), "");
                                  var urlParams=urlParams.replace("month_year="+GetURLParameter('month_year'), "");
                                  var urlParams=urlParams.replace("custome="+GetURLParameter('custome'), "");
                                  var urlParams=urlParams.replace("week="+GetURLParameter('week'), "");
                                  window.location.href=urlParams+"&daily="+daily;

                                   // var url=window.location.href;
                                   // window.location.href=url+"&daily="+daily;

                              }

                        }
                        else{
                              if (window.location.href.indexOf('daily=') > 0)  //check in url sp= present or not
                              {  
                                       /* value update of st param*/
                                       var urlParams = $(location).attr('search');// get "?blah.." (query string)
                                       var old_daily_value = GetURLParameter('daily'); //get url pram of sp's valueweek
                                       var replaceUrl=urlParams.replace("daily="+old_daily_value, "daily="+daily);
                                       
                                       window.location.href=replaceUrl;
                              }
                            }  

                        

                }else{
                   if(daily!="default")
                   {  
                    var url=window.location.href;
                    window.location.href=url+"?daily="+daily;
                   }
                }
               

     }




   function GetURLParameter(sParam)
  {

     var sPageURL = window.location.search.substring(1);
      var sURLVariables = sPageURL.split('&');
      for (var i = 0; i < sURLVariables.length; i++)
      {
          var sParameterName = sURLVariables[i].split('=');
          if (sParameterName[0] == sParam)
          {
              return sParameterName[1];
          }
     }
  }



</script>

@endsection


