<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
/* repository*/ 
use App\Repositories\Admin\UsersRepository;
use App\Repositories\Admin\DealsRepository;

class DealsController extends Controller
{
     protected $users_repo;
     protected $deals_repo;

     public function __construct(UsersRepository $usersRepository,DealsRepository $dealsRepository)
    {
        $this->middleware('auth');
        $this->users_repo = $usersRepository;
        $this->deals_repo = $dealsRepository;
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {  
       
        $sp=isset($_GET['sp'])?$_GET['sp']:'';
        
        $year=isset($_GET['year'])?$_GET['year']:'';
        $month_year=isset($_GET['month_year'])?$_GET['month_year']:'';
        $week=isset($_GET['week'])?$_GET['week']:'';
        $daily=isset($_GET['daily'])?$_GET['daily']:'';
        $custome=isset($_GET['custome'])?$_GET['custome']:'';

        $st=isset($_GET['st'])?$_GET['st']:'';
        $stock=isset($_GET['stock'])?$_GET['stock']:'';

       
        $dealsdata = $this->deals_repo->getwithuser($sp,$year,$month_year,$week,$daily,$custome,$st,$stock);
        $SalesPersondata=$this->users_repo->getAllSalesPerson();
        //dd($dealsdata);
        return view('admin.deals.index', compact('dealsdata','SalesPersondata','sp','st','year','month_year','week','daily','custome','stock'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
