<?php
/**
 * Created by PhpStorm.
 * User: Rupesh
 * Date: 5/7/17
 * Time: 4:01 PM
 */

namespace App\Repositories\Admin;

use App\Deals;

/**
 * Class SettingsRepository
 * @package App\Repositories\Backend
 */
class DealsRepository
{
    /**
     * UsersRepository constructor.
     * @param \App\Models\Setting $setting
     */
    function __construct(Deals $Deals)
    {
        $this->model = $Deals;
    }

    /**
     * @return mixed
     */
  /* used */
    public function  getAll()
    {
        return $this->model->all()->toArray();
    }

    public function getwithuser($sp,$year,$month_year,$week,$daily,$custome,$st,$stock)
    { 
        $authosiderUserDtUserId=\Auth::user()->DTUser_id; 

       if($authosiderUserDtUserId==0){
          $clauses = [['users.DTUser_id','!=',0]];  //for admin ,to show all deals
       }else{
          $clauses = [['users.DTUser_id','=',$authosiderUserDtUserId]];//for other show their own deals data only
       }   

       
        if(!empty($sp)){
           array_push($clauses,['deals.EnteredByDTUser_ID',$sp]);
        }

        if(!empty($st)){

           //array_push($clauses,['deals.DesiredDealType',$st]); 
           array_push($clauses,['deals.DealType',$st]);
        }
    
        if(!empty($year)){

           array_push($clauses,[\DB::raw('YEAR(deals.DateCreated)'),$year]);
            
        }

        if(!empty($month_year)){

           $month_year_array=explode("-",$month_year);

           array_push($clauses,[\DB::raw('MONTH(deals.DateCreated)'),$month_year_array[0]]);
           array_push($clauses,[\DB::raw('YEAR(deals.DateCreated)'),$month_year_array[1]]);
           
        }

         if(!empty($week)){

           $week_array=explode("-",$week);
          
           array_push($clauses,['deals.DateCreated','>=',$week_array[0]]);
           array_push($clauses,['deals.DateCreated','<=',$week_array[1]]);
           
        }

         if(!empty($custome)){

           $custome_array=explode("-",$custome);
          
           array_push($clauses,['deals.DateCreated','>=',$custome_array[0]]);
           array_push($clauses,['deals.DateCreated','<=',$custome_array[1]]);
           
        }
     
 
        if(!empty($daily)){

           array_push($clauses,['deals.DateCreated',$daily]);
        }

       //echo "<pre>"; print_r($clauses); exit;
    
  
    return $this->model->join('users', function($join)
                                      {
                                         $join->on('users.DTUser_id', '=', 'deals.EnteredByDTUser_ID');
                                         
                                      })->join('applicants', function($join)
                                      {
                                         
                                         $join->on('deals.Deal_ID', '=', 'applicants.Deal_ID');

                                      })
                                     ->select('*') 
				     //->where('users.DTUser_id','!=',0)
                                     ->where($clauses)
				     ->get()->toArray();

 // return $this->model->with('users')->get()->toArray();
      
    }

    

    

     public function checkemail_isExists($email,$id)
     {
       $emailRecord=$this->model->where('id', '!=', $id)
                   ->where('email', '=', $email)
                   ->get()->toArray();
        if(count($emailRecord)>0){

            $isPresent="yes";
        }else{
            $isPresent="no";

        }    
        return $isPresent; 

     }
    
}
