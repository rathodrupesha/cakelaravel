<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Core\Configure;
use Cake\Utility\Text;
use Cake\Network\Exception\NotFoundException;
use App\Error\AppError;
use Cake\ORM\TableRegistry;

/**
 * Roles Controller
 *
 * @property \App\Model\Table\RolesTable $Roles
 */
class RolesController extends AppController
{

    public function beforeFilter(Event $event)
    {
        $this->Auth->allow(['add']);
        parent::beforeFilter($event);
    }

    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $request = $this->request->data;
        $roles = $this->Roles->find('all', $request);
        $count = $roles->count();
        if($count > 0)
        {
            $this->serialize(200, 'Record Found',$roles);
        }
        else
        {
            $this->serialize(400, 'No Record Found',$roles);
        }
    }

    /**
     * View method
     *
     * @param string|null $id Role id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $request = $this->request->data;
        $roles = $this->Roles->find('all', $request);
        $this->set('Roles', $roles);
        $this->set('_serialize', ['Roles']);
    }

    /**
     * Add method
     * URL : http://localhost/api_cakedemo/roles/add.json
     * Request = {"name":"user1@gmail.com"}
     * Responce = { "code": 200, "url": "Roles\/add.json", "message": "The role name has been saved.", "Roles": { "name": "test", "created": "2017-03-24T12:03:33", "modified": "2017-03-24T12:03:33", "id": 8 } }
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $roles = $this->Roles->newEntity();
        if ($this->request->is('post'))
        {
            $name_check = $this->Roles->role_check($this->request->data['name']);
            if ($name_check)
            {
                    $this->serialize(100, 'Role Name already exists.',$roles = array());
            }
            else
            {
                $roles = $this->Roles->patchEntity($roles, $this->request->getData());
                if ($this->Roles->save($roles))
                {
                    $this->serialize(200, 'The role name has been saved.',$roles);
                }
                else
                {
                    $this->serialize(400, 'The role name could not be saved. Please, try again.',$roles);
                }
            }
        }
    }

    /**
     * Edit method
     * URL : http://localhost/api_cakedemo/roles/edit.json
     * Request = {"name":"test1","id":"8"}
     * Responce = { "code": 200, "url": "Roles\/edit.json", "message": "The role name has been edit.", "Roles": { "id": 8, "name": "test1", "status": 1, "isDeleted": 0, "created": "2017-03-24T12:03:33", "modified": "2017-03-24T12:05:12" } }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        if ($this->request->is(['patch', 'post', 'put']))
        {
            $role = $this->Roles->findById($this->request->data['id'])->first();
            if (empty($role))
            {
                throw new NotFoundException();
            }
            $name_check = $this->Roles->role_check($this->request->data['name']);
            if ($name_check)
            {
                $this->serialize(100, 'Role Name already exists.',$roles = array());
            }
            else
            {
                $roles = $this->Roles->patchEntity($role, $this->request->getData());
                if ($this->Roles->save($roles))
                {
                    $this->serialize(200, 'The role name has been edit.',$roles);
                }
                else
                {
                    $this->serialize(400, 'The role name could not be saved. Please, try again.',$roles);
                }
            }
        }
    }

    /**
     * Delete method
     * URL : http://localhost/api_cakedemo/roles/delete.json
     * Request = {"id":"5"}
     * Responce = { "code": 200, "url": "Roles\/delete.json", "message": "The role name has been deleted.", "Roles": { "id": 8, "name": "test1", "status": 1, "isDeleted": 1, "created": "2017-03-24T12:03:33", "modified": "2017-03-24T12:06:15" } }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $result = $this->Roles->findById($this->request->data['id'])->first();
        if (empty($result))
        {
            throw new NotFoundException(__('Role not found'), 555);
        }
        if ($this->request->is(['patch', 'post', 'put']))
        {
            $roles = $this->Roles->patchEntity($result, $this->request->data);
            $roles->isDeleted = 1;
            if ($this->Roles->save($roles))
            {
                $this->serialize(200, 'The role name has been deleted.',$roles);
            }
            else
            {
                $this->serialize(400, 'The role name could not be saved. Please, try again.',$roles);
            }
        }
    }
}
