<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Core\Configure;
use Cake\Utility\Text;
use Cake\Network\Exception\NotFoundException;
use App\Error\AppError;
use Cake\ORM\TableRegistry;
use Cake\Mailer\MailerAwareTrait;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 */
class CollagesController extends AppController
{
    use MailerAwareTrait;

    public function beforeFilter(Event $event)
    {
        $this->Auth->allow(['login','add','uploadImage','activeAccount','makeimgurl','forgotpassword']);
        parent::beforeFilter($event);
    }


    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $request = $this->request->data;

        $collages = $this->Collages->find('all', $request);
        
        $count = $collages->count(); 
        if($count > 0)
        {
            $this->serialize(200, 'Record Found',$collages);
        }
        else
        {
            $this->serialize(400, 'No Record Found',$collages);
        }
    }

    /**
     * User Login method
     * URL : http://localhost/bankii/api_bunkii/users/login.json
     * Request Normal User = {"email": "user1@gmail.com","password" :"123456","register_type":"1","role_id":"2"}
     * Request Social User = {"email": "user1@gmail.com","password" :"123456","register_type":"2","role_id":"2"}
     * Responce = { "code": 200, "url": "Users\/login.json", "message": "Login successfully.", "Users": { "id": 9, "role_id": 2, "email": "hardik@technostacks.com", "api_key": "$2y$10$WCjisRdz2tEeGnq1Fu43Te.tm8b26f\/SDCxiW16BAJQNSh8s7kPLy", "api_plain_key": "ed233fecbd44dd40c9e6e60ce1f05e597dbfb7b1", "firstname": "hardik", "lastname": "paghdar", "profile_image": "", "mobile": "", "address": "", "verification_code": "", "status": 1, "isDeleted": 0, "created": "2017-06-17T06:43:39", "modified": "2017-06-17T06:52:39" } }
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function login()
    {
        if ($this->request->is('post'))
        {
           
            $register_type = $this->request->data['register_type'];
            if($register_type == 1)
            {      
                if (isset($this->request->data['email']) && !empty($this->request->data['email']) &&
                    isset($this->request->data['password']) && !empty($this->request->data['password']))
                {
                    $users = $this->Users->getUser(array('email' => $this->request->data['email'], 'password' => md5($this->request->data['password']), 'status' => 1, 'isDeleted' => 0));
    
                    if (empty($users) && $users == NULL)
                    {
                        $this->serialize(100, 'Invalid username or password, try again.',$users = array());
                    }
                    else
                    {
                        $this->Auth->setUser($users);
                        $this->serialize(200, 'Login successfully.',$users);
                    }
                }
                else
                {
                    $this->serialize(400, 'Please provide all required fields.',$users = array());
                }
            }
            else if($register_type == 2)
            {
                $this->socialRegisterLogin($this->request->data);
            }
            else if($register_type == 3)
            {
                $this->socialRegisterLogin($this->request->data);
            }
            else if($register_type == 4)
            {
                $this->socialRegisterLogin($this->request->data);
            }
            else if($register_type == 5)
            {
                $this->socialRegisterLogin($this->request->data);
            }
            else if($register_type == 6)
            {
                $this->socialRegisterLogin($this->request->data);
            }
            else if($register_type == 7)
            {
                $this->socialRegisterLogin($this->request->data);
            }
            else if($register_type == 8)
            {
                $this->socialRegisterLogin($this->request->data);
            }
        }
    }

    /**
    * Social register basc on register_type filed 
    * register_type : 1=Normal,2=Facebook,3=Google+,4=Gmail,5=Linkedin,6=Instagram,7=Twitter,8=Pinterest
    * register_type should be fix can't change
    * request like = {"email": "user1@gmail.com","password" :"123456","register_type":"2","role_id":"2"}
    * If user alreday exist then check only email, And password will be generate on app side.
    */
    public function socialRegisterLogin($request)
    {
        if (isset($request['email']) && !empty($request['email']))
        {
            $email_check = $this->Users->email_check($request['email']);
            if ($email_check)
            {
                $users = $this->Users->getUser(array('email' => $this->request->data['email']));
                $this->Auth->setUser($users);
                $this->serialize(200, 'Login successfully.',$users);
            }
            else
            {
                $addUser = $this->add($request);
                $this->Auth->setUser($addUser);
                $this->serialize(200, 'Login successfully.',$addUser);
            }
        }
        else
        {
            $this->serialize(400, 'Please provide all required fields.',$users = array());
        }
    }

    /**
     * User Logout method
     * URL : http://localhost/api_cakedemo/users/logout.json
     * Request =
     * Responce = { "code": 200, "url": "Users\/logout.json", "message": "User logout sucessfully.", "Users": { "status": 1 } }
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function logout()
    {
        $this->Auth->logout();
        $user = array();
        $user['status'] = 1;
        $this->serialize(200, 'User logout sucessfully.',$user);
    }

    /**
     * View method
     * URL : 192.168.0.133/bankii/api_bunkii/users/view.json
     * Request = {"conditions":{"id":"14"}, "get":"all"}
     * Responce = { "Users": [ { "id": 14, "role_id": 2, "name": "reterert", "email": "erertertret@gmail.com", "school_name": "vidhya vihar sankul", "school_email": "rrrrrr@gmail.com", "api_plain_key": "ceea6e6baf5f553e529b0893467147f419f047af", "api_key": "$2y$10$56pBAR5oSGMlG9H9iPZzz.9exRVP\/M6QDNdrAQH.3RVLd3a.0cowu", "profile_image": "abcd.png", "verification_code": "0512", "register_type": 1, "status": 0, "isDeleted": 0, "created": "2017-09-22T10:44:22", "modified": "2017-09-22T10:44:22" } ] }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $request = $this->request->data;
        $collages = $this->Collages->find('all', $request);
        $count = $collages->count();
        if($count > 0)
        {
            $this->serialize(200, 'Record Found',$collages);
        }
        else
        {
            $this->serialize(400, 'No Record Found',$collages);
        }
    }

    /**
     * Add method
     *URL : 192.168.0.133/bankii/api_bunkii/collages/add.json
     Request : {"user_id":"15", "title":"all","collages_image":"1506491304_982742.jpg"}
     Response : { "code": 200, "url": "Collages\/add.json", "message": "The Favorites has been saved.", "Collages": { "user_id": 15, "title": "all", "collages_image": "1506491304_982742.jpg", "created": "2017-09-27T06:36:24", "modified": "2017-09-27T06:36:24", "id": 3 } }
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        
        $collages = $this->Collages->newEntity();
        if ($this->request->is('post')) {

            $collage = $this->Collages->patchEntity($collages, $this->request->getData());
        
            if ($this->Collages->save($collage)) {

               $this->serialize(200, 'The Favorites has been saved.',$collage);
            }
            else{
                $this->serialize(400, 'The Favorites has not been saved.',$collage);
            }
            
        }
        
    }

    /**
     * Edit method
     * URL : 192.168.0.133/bankii/api_bunkii/users/edit.json
     * Request = {"id":14,"name":"jenis","school_name":"rachna","password":"123456","profile_image":"abcd.png"}
     * Responce = { "code": 200, "url": "Users\/edit.json", "message": "The user has been edit.", "Users": { "id": 14, "role_id": 2, "name": "jenis", "email": "erertertret@gmail.com", "school_name": "rachna", "school_email": "rrrrrr@gmail.com", "api_plain_key": "ceea6e6baf5f553e529b0893467147f419f047af", "api_key": "$2y$10$56pBAR5oSGMlG9H9iPZzz.9exRVP\/M6QDNdrAQH.3RVLd3a.0cowu", "profile_image": "abcd.png", "verification_code": "0512", "register_type": 1, "status": 0, "isDeleted": 0, "created": "2017-09-22T10:44:22", "modified": "2017-09-22T11:18:46" } }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        if ($this->request->is(['patch', 'post', 'put']))
        {
            $user = $this->Users->findById($this->request->data['id'])->first();
            if (empty($user))
            {
                throw new NotFoundException();
            }
            $users = $this->Users->patchEntity($user, $this->request->data);
            if(!empty($this->request->data['password'])){
                $password = md5($users->password);
                $users->password = $password;
            }
            if ($this->Users->save($users))
            {
                $this->serialize(200, 'The user has been edit.',$users);
            }
            else
            {
                $this->serialize(400, 'The user could not be saved. Please, try again.',$users);
            }
        }
    }

    /**
     * Delete method
     * URL : 192.168.0.133/bankii/api_bunkii/users/delete.json
     * Request = {"id":"14"}
     * Responce = { "code": 200, "url": "Users\/delete.json", "message": "The user has been deleted.", "Users": { "id": 14, "role_id": 2, "name": "reterert", "email": "erertertret@gmail.com", "school_name": "vidhya vihar sankul", "school_email": "rrrrrr@gmail.com", "api_plain_key": "ceea6e6baf5f553e529b0893467147f419f047af", "api_key": "$2y$10$56pBAR5oSGMlG9H9iPZzz.9exRVP\/M6QDNdrAQH.3RVLd3a.0cowu", "profile_image": "abcd.png", "verification_code": "0512", "register_type": 1, "status": 0, "isDeleted": 1, "created": "2017-09-22T10:44:22", "modified": "2017-09-22T11:09:11" } }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete()
    {
        $this->request->allowMethod(['post', 'delete']);
        $result = $this->Collages->findById($this->request->data['id'])->first();
        if (empty($result))
        {
            throw new NotFoundException(__('User not found'), 555);
        }
        if ($this->request->is(['patch', 'post', 'put']))
        {
            $collages = $this->Collages->patchEntity($result, $this->request->data);
            $collages->isDeleted = 1;
            if ($this->Collages->save($collages))
            {
                $this->serialize(200, 'The Collages has been deleted.',$collages);
            }
            else
            {
                $this->serialize(400, 'The Collages could not be saved. Please, try again.',$collages);
            }
        }
    }

    /**
     * Upload image method
     API Name : upooad collages image
    URL : 192.168.0.133/bankii/api_bunkii/collages/uploadimage.json
    Request : key : collages_image",
    Response : { "users": { "collages_image": "1506491304_982742.jpg" } }
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function uploadImage()
    {

        $users      = array();
        $result = $this->request->data;
        foreach($result as $key=>$file)
        {
            if(is_array($file))
            {
                $arr = $this->saveImage($file, $key);
                if($arr)
                {
                    $users[$key] = $arr['new_name'];
                }
            }
        }
        $this->set(compact('users'), '_serialize', ['users']);
    }

    /**
     * get role method
     * URL :
     * Request =
     * Responce = roles list
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function getRoles()
    {
        $roles = $this->Users->Roles->find('list',['conditions'=>["Roles.isDeleted" => 0]],['keyField' => 'id', 'valueField' => 'name']);
        if ($roles)
        {
            $this->serialize(200, 'Roles Found.',$roles);
        }
        else
        {
            $this->serialize(400, 'Roles Not found!.',$roles);
        }
    }

    /**
     * Active account method
     * URL :
     * Request = {"ActivationCode":"####"}
     * Responce =
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function activeAccount()
    {
        $ActivationCode = $this->request->data['ActivationCode'];
        $decryptCode = $this->encrypt_decrypt('decrypt',$ActivationCode);
        $this->request->allowMethod(['post', 'delete']);
        $result = $this->Users->findByVerificationCode(trim($decryptCode))->first();
        if (empty($result))
        {
            throw new NotFoundException(__('User not found'), 555);
        }
        if ($this->request->is(['patch', 'post', 'put']))
        {
            $result->status = 1;
            $result->verification_code = '';
            if ($this->Users->save($result))
            {
                $this->serialize(200, 'Your account is activated now.',$result);
            }
            else
            {
                $this->serialize(400, 'Your account is not activated. Please, try again.');
            }
        }
    }

    /**
     * encrypt_decrypt method for verification_code
     * URL :
     * Request =
     * Responce =
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function encrypt_decrypt($action, $string)
    {
        $output = false;
        $key = '$b@bl2I@?%%4K*mC6r273~8l3|6@>D';
        $iv = md5(md5($key));
        if( $action == 'encrypt' )
        {
           $output = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, md5($key), $string, MCRYPT_MODE_CBC, $iv);
           $output = str_replace(array('+', '/'), array('-', '_'), base64_encode($output));
        }
        else if( $action == 'decrypt' )
        {
           $str = base64_decode(str_replace(array('-', '_'), array('+', '/'), $string));
           $output = mcrypt_decrypt(MCRYPT_RIJNDAEL_256, md5($key), $str, MCRYPT_MODE_CBC, $iv);
           $output = rtrim($output, "");
        }
        return $output;
    }

    /**
     * remove profile image
     * URL :
     * Request = {"id":"####","imagename":"####"}
     * Responce =
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function removeImage()
    {
        $request = $this->request->data;
        $result = $this->Users->findById($this->request->data['id'])->first();
        if (empty($result))
        {
            throw new NotFoundException();
        }
        if ($this->request->is(['patch', 'post', 'put'])) {
            unlink(ROOT.'/uploads/profile/'.$this->request->data['imagename']);
            $result->profile_image = '';
            if ($this->Users->save($result))
            {
                $this->serialize(200, 'Profile image remove successfully.',$result);
            }
            else
            {
                $this->serialize(400, 'Profile image not remove. Please, try again.');
            }
        }
    }

    /*
    *For get image url from api side
    *URL : http://localhost/api_cakedemo/geturl/profile/1494926702_987642.png
    */
    function makeimgurl()
    {
        $folderName = $this->request->params['pass'][0];
        $ImageName = $this->request->params['pass'][1];
        $ext = pathinfo($ImageName, PATHINFO_EXTENSION);
        $ImgPath = API_BASE_UPLOAD_PATH.$folderName.'/'.$ImageName;
        if($ext == 'jpg' || $ext == 'jpeg' || $ext == 'gif' || $ext == 'png')
        {
            $Image = file_get_contents($ImgPath);
            header("Content-type: image/".$ext);
        }
        else
        {
            $Image = file_get_contents($ImgPath);
            header("Content-type: image/jpeg");
        }
        echo $Image;exit;
    }

    /**
     * Change Password method
     * URL : http://localhost/api_cakedemo/users/changePassword.json
     * Request = {"id":"22","cur_password" : "123456","new_password":"abc"}
     * Responce = { "code": 200, "url": "Users\/changePassword.json", "message": "Password has been change.", "Users": { "id": 22, "role_id": 2, "username": "hardik1", "email": "hardik@technostacks.com", "api_key": "$2y$10$ApFGrgT0vjq30e3eZGiL0OV8P4TC3lSuEGC9a6n7BR3VrgybqGgGi", "api_plain_key": "6d7b9f292099b74f9353ce4445dcdd267d1028b6", "firstname": "", "lastname": "", "profile_image": "", "cover_image": "", "about": "", "gender": "", "verification_code": "", "register_type": 2, "status": 1, "isDeleted": 0, "created": "2017-07-21T06:00:12", "modified": "2017-07-21T06:22:11" } }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    /* Change Password for admin */
    public function changePassword()
    {
        if ($this->request->is(['patch', 'post', 'put']))
        {
            $user = $this->Users->findById($this->request->data['id'])->first();
            if (empty($user))
            {
                throw new NotFoundException();
            }
            if(md5($this->request->data['cur_password']) == $user->password)
            {
                $password = md5($this->request->data['new_password']); 
                $user->password = $password;   
                if ($this->Users->save($user))
                {
                    $this->serialize(200, 'Password has been change.',$user);
                }
                else
                {
                    $this->serialize(400, 'The password could not be saved. Please, try again.',$user);
                }
            }
            else
            {
                $this->serialize(100, 'Current password does not match.',$user = array());
            }
        }
    }

    /**
     * Forgot password
     * URL : 192.168.0.133/bankii/api_bunkii/users/forgotpassword.json
     * Request = {"role_id":"1","email":"admin@gmail.com"}
     * Responce ={ "code": 200, "url": "Users\/forgotpassword.json", "message": "Email Send Sucessfully", "Users": [] }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function forgotpassword()
    {
        
        if($this->request->data['role_id'] == 1)
        {
            $userid = $this->Users->email_check($this->request->data['email']);
            if($userid)
            {
                $user = $this->Users->findById($userid)->first();
                if($user->role_id == 1)
                {
                    $random_number = mt_rand(100000, 999999);
                    $password = md5($random_number); 
                    $user->password = $password;
                    if ($this->Users->save($user))
                    {
                        $emailData['email'] = $user->email;
                        $emailData['password'] = $random_number;
                        $this->getMailer('User')->send('forgot_password',[$emailData]);
                        $this->serialize(200, 'Email send successfully.',$user);
                    }
                    else
                    {
                        $this->serialize(400, 'The email could not be send. Please, try again.',$user);
                    }   
                }
                else
                {
                    $this->serialize(400, 'Your are not an admin.');    
                }
            }
            else
            {
                $this->serialize(400, 'Your are not an admin.');
            }
        }
        else
        {
            $user = $this->Users->findById($this->request->data['id'])->first();
            $users = $this->Users->patchEntity($user, $this->request->data);
            if ($this->Users->save($users))
            {
                $this->serialize(200, 'Email Send Sucessfully');
                $code = $this->request->data['otp_code'];
                $users->verification_code = $code;
                $this->getMailer('User')->send('forgot',[$users]); // Send email to email address
            }
            else
            {
                $this->serialize(400, 'Email Not Send Please try again');
            }
        }
    }
     /*
      URL : 192.168.0.133/bankii/api_bunkii/users/verification.json
      Request : {"verification_code":"1234"}
      Response :  "code": 200, "url": "Users\/verification.json", "message": "verification  done.", "Users": [] }
     */
  
        public function verification()
    {

        $verification_code=$this->request->data["verification_code"]; 
        $conditions = array('verification_code'=>$verification_code,'status'=>0);
        $fields = array('verification_code'=>'','status'=>1);
        $done=$this->Users->updateAll($fields, $conditions);
        if($done){
            $this->serialize(200, 'verification done.');
           }else{
            $this->serialize(400, 'verification not done.');
           }
     
    }



}
