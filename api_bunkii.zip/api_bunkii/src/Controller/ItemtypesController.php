<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Core\Configure;
use Cake\Utility\Text;
use Cake\Network\Exception\NotFoundException;
use App\Error\AppError;
use Cake\ORM\TableRegistry;
use Cake\Mailer\MailerAwareTrait;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 */
class ItemtypesController extends AppController
{
    use MailerAwareTrait;

    public function beforeFilter(Event $event)
    {
        $this->Auth->allow(['login','add','uploadImage','activeAccount','makeimgurl','forgotpassword','getitems']);
        parent::beforeFilter($event);
    }


    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $request = $this->request->data;
        $itemtypes = $this->Itemtypes->find('all', $request);
        $count = $itemtypes->count();
        if($count > 0)
        {
            $this->serialize(200, 'Record Found',$itemtypes);
        }
        else
        {
            $this->serialize(400, 'No Record Found',$itemtypes);
        }
    }

    
    /**
     * View method
     * URL : 192.168.0.133/bankii/api_bunkii/users/view.json
     * Request = {"conditions":{"id":"14"}, "get":"all"}
     * Responce = { "Users": [ { "id": 14, "role_id": 2, "name": "reterert", "email": "erertertret@gmail.com", "school_name": "vidhya vihar sankul", "school_email": "rrrrrr@gmail.com", "api_plain_key": "ceea6e6baf5f553e529b0893467147f419f047af", "api_key": "$2y$10$56pBAR5oSGMlG9H9iPZzz.9exRVP\/M6QDNdrAQH.3RVLd3a.0cowu", "profile_image": "abcd.png", "verification_code": "0512", "register_type": 1, "status": 0, "isDeleted": 0, "created": "2017-09-22T10:44:22", "modified": "2017-09-22T10:44:22" } ] }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $request = $this->request->data;
        $itemtypes = $this->Itemtypes->find('all', $request);
        $count = $itemtypes->count();
        if($count > 0)
        {
            $this->serialize(200, 'Record Found',$itemtypes);
        }
        else
        {
            $this->serialize(400, 'No Record Found',$itemtypes);
        }
    }

    /**
     * Add method
     URL : http://192.168.0.133/api_bunkii/itemtypes/add.json
     Request : r{"item_id": "1","title" :"blastic pot","description":"this is good","rooms_image":"1506929384_674675.jpg"}
     Response : { "code": 200, "url": "Itemtypes\/add.json", "message": "The item type has been saved.", "Itemtypes": { "item_id": 1, "title": "blastic pot", "description": "this is good", "rooms_image": "1506929384_674675.jpg", "id": 1 } }
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        
        $itemtypes = $this->Itemtypes->newEntity();
        if ($this->request->is('post')) {

            $itemtype = $this->Itemtypes->patchEntity($itemtypes, $this->request->getData());
        
            if ($this->Itemtypes->save($itemtype)) {

               $this->serialize(200, 'The item type has been saved.',$itemtype);
            }
            else{
                $this->serialize(400, 'The item type has not been saved.',$itemtype);
            }
            
        }
        
    }

    /**
     * Edit method
     * URL : 192.168.0.133/bankii/api_bunkii/users/edit.json
     * Request = {"id":14,"name":"jenis","school_name":"rachna","password":"123456","profile_image":"abcd.png"}
     * Responce = { "code": 200, "url": "Users\/edit.json", "message": "The user has been edit.", "Users": { "id": 14, "role_id": 2, "name": "jenis", "email": "erertertret@gmail.com", "school_name": "rachna", "school_email": "rrrrrr@gmail.com", "api_plain_key": "ceea6e6baf5f553e529b0893467147f419f047af", "api_key": "$2y$10$56pBAR5oSGMlG9H9iPZzz.9exRVP\/M6QDNdrAQH.3RVLd3a.0cowu", "profile_image": "abcd.png", "verification_code": "0512", "register_type": 1, "status": 0, "isDeleted": 0, "created": "2017-09-22T10:44:22", "modified": "2017-09-22T11:18:46" } }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        if ($this->request->is(['patch', 'post', 'put']))
        {
            $Itemtype = $this->Itemtypes->findById($this->request->data['id'])->first();
            if (empty($Itemtype))
            {
                throw new NotFoundException();
            }
            $itemtypes = $this->Itemtypes->patchEntity($Itemtype, $this->request->data);
            
            if ($this->Itemtypes->save($itemtypes))
            {
                $this->serialize(200, 'The user has been edit.',$itemtypes);
            }
            else
            {
                $this->serialize(400, 'The user could not be saved. Please, try again.',$itemtypes);
            }
        }
    }

    /**
     * Delete method
     * URL : 192.168.0.133/bankii/api_bunkii/users/delete.json
     * Request = {"id":"14"}
     * Responce = { "code": 200, "url": "Users\/delete.json", "message": "The user has been deleted.", "Users": { "id": 14, "role_id": 2, "name": "reterert", "email": "erertertret@gmail.com", "school_name": "vidhya vihar sankul", "school_email": "rrrrrr@gmail.com", "api_plain_key": "ceea6e6baf5f553e529b0893467147f419f047af", "api_key": "$2y$10$56pBAR5oSGMlG9H9iPZzz.9exRVP\/M6QDNdrAQH.3RVLd3a.0cowu", "profile_image": "abcd.png", "verification_code": "0512", "register_type": 1, "status": 0, "isDeleted": 1, "created": "2017-09-22T10:44:22", "modified": "2017-09-22T11:09:11" } }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete()
    {
        $this->request->allowMethod(['post', 'delete']);
        $result = $this->Itemtypes->findById($this->request->data['id'])->first();
        if (empty($result))
        {
            throw new NotFoundException(__('User not found'), 555);
        }
        if ($this->request->is(['patch', 'post', 'put']))
        {
            $itemtypes = $this->Itemtypes->patchEntity($result, $this->request->data);
            $itemtypes->isDeleted = 1;
            if ($this->Itemtypes->save($itemtypes))
            {
                $this->serialize(200, 'The Collages has been deleted.',$itemtypes);
            }
            else
            {
                $this->serialize(400, 'The Collages could not be saved. Please, try again.',$itemtypes);
            }
        }
    }

    /**
     * Upload image method
     API Name : upooad collages image
    URL : http://192.168.0.133/api_bunkii/itemtypes/uploadImage.json
    Request : key : rooms_image",
    Response : { "users": { "rooms_image": "1506929384_674675.jpg" } }
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function uploadImage()
    {

        $users      = array();
        $result = $this->request->data;
        foreach($result as $key=>$file)
        {
            if(is_array($file))
            {
                $arr = $this->saveImage($file, $key);
                if($arr)
                {
                    $users[$key] = $arr['new_name'];
                }
            }
        }
        $this->set(compact('users'), '_serialize', ['users']);
    }

   
    public function removeImage()
    {
        $request = $this->request->data;
        $result = $this->Itemtypes->findById($this->request->data['id'])->first();
        if (empty($result))
        {
            throw new NotFoundException();
        }
        if ($this->request->is(['patch', 'post', 'put'])) {
            unlink(ROOT.'/uploads/rooms/'.$this->request->data['imagename']);
            $result->rooms_image = '';
            if ($this->Itemtypes->save($result))
            {
                $this->serialize(200, 'Rooms image remove successfully.',$result);
            }
            else
            {
                $this->serialize(400, 'Rooms image not remove. Please, try again.');
            }
        }
    }

    /*
    *For get image url from api side
    *URL : http://localhost/api_cakedemo/geturl/profile/1494926702_987642.png
    */
    function makeimgurl()
    {
        $folderName = $this->request->params['pass'][0];
        $ImageName = $this->request->params['pass'][1];
        $ext = pathinfo($ImageName, PATHINFO_EXTENSION);
        $ImgPath = API_BASE_UPLOAD_PATH.$folderName.'/'.$ImageName;
        if($ext == 'jpg' || $ext == 'jpeg' || $ext == 'gif' || $ext == 'png')
        {
            $Image = file_get_contents($ImgPath);
            header("Content-type: image/".$ext);
        }
        else
        {
            $Image = file_get_contents($ImgPath);
            header("Content-type: image/jpeg");
        }
        echo $Image;exit;
    }




}
