<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Core\Configure;
use Cake\Utility\Text;
use Cake\Network\Exception\NotFoundException;
use App\Error\AppError;
use Cake\ORM\TableRegistry;
use Cake\Mailer\MailerAwareTrait;

/**
 * Schools Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 */
class SchoolsController extends AppController
{
    use MailerAwareTrait;

    public function beforeFilter(Event $event)
    {
        $this->Auth->allow(['login','add','uploadImage','activeAccount','makeimgurl','forgotpassword']);
        parent::beforeFilter($event);
    }


    /**
     * Index method
     *URL:192.168.0.151/api_bunkii/schools/index.json
     {"get":"all","conditions": {"isDeleted":0,"status":1}, "fields": ["name","id"] }
     Response:
     { "code": 200, "url": "Schools\/index.json", "message": "Record Found", "Schools": [ { "name": "sarasvati higher secondery school", "id": 1 }, { "name": "vidhyanagr clg", "id": 2 }, { "name": "mahishmati higher education", "id": 3 } ] }
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $request = $this->request->data;
        //echo "<pre>"; print_r($request); exit();
        $school = $this->Schools->find('all', $request);
        
        $count = $school->count(); 
        if($count > 0)
        {
            $this->serialize(200, 'Record Found',$school);
        }
        else
        {
            $this->serialize(400, 'No Record Found',$school);
        }
    }



    /**
     * View method
     * URL : 192.168.0.133/bankii/api_bunkii/users/view.json
     * Request = {"conditions":{"id":"14"}, "get":"all"}
     * Responce = { "Users": [ { "id": 14, "role_id": 2, "name": "reterert", "email": "erertertret@gmail.com", "school_name": "vidhya vihar sankul", "school_email": "rrrrrr@gmail.com", "api_plain_key": "ceea6e6baf5f553e529b0893467147f419f047af", "api_key": "$2y$10$56pBAR5oSGMlG9H9iPZzz.9exRVP\/M6QDNdrAQH.3RVLd3a.0cowu", "profile_image": "abcd.png", "verification_code": "0512", "register_type": 1, "status": 0, "isDeleted": 0, "created": "2017-09-22T10:44:22", "modified": "2017-09-22T10:44:22" } ] }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $request = $this->request->data;
        $schools = $this->Schools->find('all', $request);
        $count = $schools->count();
        if($count > 0)
        {
            $this->serialize(200, 'Record Found',$schools);
        }
        else
        {
            $this->serialize(400, 'No Record Found',$schools);
        }
    }

    /**
     * Add method
     *URL : 192.168.0.133/bankii/api_bunkii/collages/add.json
     Request : {"user_id":"15", "title":"all","collages_image":"1506491304_982742.jpg"}
     Response : { "code": 200, "url": "Collages\/add.json", "message": "The Favorites has been saved.", "Collages": { "user_id": 15, "title": "all", "collages_image": "1506491304_982742.jpg", "created": "2017-09-27T06:36:24", "modified": "2017-09-27T06:36:24", "id": 3 } }
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        
        $schools = $this->Schools->newEntity();
        if ($this->request->is('post')) {
       
           $email_check = $this->Schools->schoolemail_check_at_school_add($this->request->data['email']);
          // echo "<pre>"; print_r($email_check); exit();
           if(count($email_check)>0){

            $this->serialize(400, 'school Email is Already Exist.');
           }
           else{
                    $schools = $this->Schools->patchEntity($schools, $this->request->getData());
                
                    if ($this->Schools->save($schools)) {

                       $this->serialize(200, 'The schools has been saved.',$schools);
                    }
                    else{
                        $this->serialize(400, 'The schools has not been saved.',$schools);
                    }
                }    
            
        }
        
    }

    /**
     * Edit method
     * URL : 192.168.0.133/bankii/api_bunkii/users/edit.json
     * Request = {"id":14,"name":"jenis","school_name":"rachna","password":"123456","profile_image":"abcd.png"}
     * Responce = { "code": 200, "url": "Users\/edit.json", "message": "The user has been edit.", "Users": { "id": 14, "role_id": 2, "name": "jenis", "email": "erertertret@gmail.com", "school_name": "rachna", "school_email": "rrrrrr@gmail.com", "api_plain_key": "ceea6e6baf5f553e529b0893467147f419f047af", "api_key": "$2y$10$56pBAR5oSGMlG9H9iPZzz.9exRVP\/M6QDNdrAQH.3RVLd3a.0cowu", "profile_image": "abcd.png", "verification_code": "0512", "register_type": 1, "status": 0, "isDeleted": 0, "created": "2017-09-22T10:44:22", "modified": "2017-09-22T11:18:46" } }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        if ($this->request->is(['patch', 'post', 'put']))
        {
            $school = $this->Schools->findById($this->request->data['id'])->first();
            if (empty($school))
            {
                throw new NotFoundException();
            }
            $schools = $this->Schools->patchEntity($school, $this->request->data);
            if(!empty($this->request->data['password'])){
                $password = md5($schools->password);
                $schools->password = $password;
            }
            if ($this->Schools->save($schools))
            {
                $this->serialize(200, 'The schools has been edit.',$schools);
            }
            else
            {
                $this->serialize(400, 'The schools could not be saved. Please, try again.',$schools);
            }
        }
    }

    /**
     * Delete method
     * URL : 192.168.0.133/bankii/api_bunkii/users/delete.json
     * Request = {"id":"14"}
     * Responce = { "code": 200, "url": "Users\/delete.json", "message": "The user has been deleted.", "Users": { "id": 14, "role_id": 2, "name": "reterert", "email": "erertertret@gmail.com", "school_name": "vidhya vihar sankul", "school_email": "rrrrrr@gmail.com", "api_plain_key": "ceea6e6baf5f553e529b0893467147f419f047af", "api_key": "$2y$10$56pBAR5oSGMlG9H9iPZzz.9exRVP\/M6QDNdrAQH.3RVLd3a.0cowu", "profile_image": "abcd.png", "verification_code": "0512", "register_type": 1, "status": 0, "isDeleted": 1, "created": "2017-09-22T10:44:22", "modified": "2017-09-22T11:09:11" } }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete()
    {
        $this->request->allowMethod(['post', 'delete']);
        $result = $this->Schools->findById($this->request->data['id'])->first();
        if (empty($result))
        {
            throw new NotFoundException(__('User not found'), 555);
        }
        if ($this->request->is(['patch', 'post', 'put']))
        {
            $schools = $this->Schools->patchEntity($result, $this->request->data);
            $schools->isDeleted = 1;
            if ($this->Schools->save($schools))
            {
                $this->serialize(200, 'The School has been deleted.',$schools);
            }
            else
            {
                $this->serialize(400, 'The School could not be saved. Please, try again.',$schools);
            }
        }
    }

    /**
     * Upload image method
     API Name : upooad collages image
    URL : 192.168.0.133/bankii/api_bunkii/schools/uploadimage.json
    Request : key : school_image",
    Response : { "users": { "school_image": "1506491304_982742.jpg" } }
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function uploadImage()
    {

        $school      = array();
        $result = $this->request->data;

        foreach($result as $key=>$file)
        {
            if(is_array($file))
            {
                $arr = $this->saveImage($file, $key);
                if($arr)
                {
                    $school[$key] = $arr['new_name'];
                }
            }
        }
        $this->set(compact('school'), '_serialize', ['school']);
    }

    /**
     * get role method
     * URL :
     * Request =
     * Responce = roles list
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function getRoles()
    {
        $roles = $this->Users->Roles->find('list',['conditions'=>["Roles.isDeleted" => 0]],['keyField' => 'id', 'valueField' => 'name']);
        if ($roles)
        {
            $this->serialize(200, 'Roles Found.',$roles);
        }
        else
        {
            $this->serialize(400, 'Roles Not found!.',$roles);
        }
    }

    /**
     * Active account method
     * URL :
     * Request = {"ActivationCode":"####"}
     * Responce =
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function activeAccount()
    {
        $ActivationCode = $this->request->data['ActivationCode'];
        $decryptCode = $this->encrypt_decrypt('decrypt',$ActivationCode);
        $this->request->allowMethod(['post', 'delete']);
        $result = $this->Users->findByVerificationCode(trim($decryptCode))->first();
        if (empty($result))
        {
            throw new NotFoundException(__('User not found'), 555);
        }
        if ($this->request->is(['patch', 'post', 'put']))
        {
            $result->status = 1;
            $result->verification_code = '';
            if ($this->Users->save($result))
            {
                $this->serialize(200, 'Your account is activated now.',$result);
            }
            else
            {
                $this->serialize(400, 'Your account is not activated. Please, try again.');
            }
        }
    }

    /**
     * encrypt_decrypt method for verification_code
     * URL :
     * Request =
     * Responce =
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function encrypt_decrypt($action, $string)
    {
        $output = false;
        $key = '$b@bl2I@?%%4K*mC6r273~8l3|6@>D';
        $iv = md5(md5($key));
        if( $action == 'encrypt' )
        {
           $output = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, md5($key), $string, MCRYPT_MODE_CBC, $iv);
           $output = str_replace(array('+', '/'), array('-', '_'), base64_encode($output));
        }
        else if( $action == 'decrypt' )
        {
           $str = base64_decode(str_replace(array('-', '_'), array('+', '/'), $string));
           $output = mcrypt_decrypt(MCRYPT_RIJNDAEL_256, md5($key), $str, MCRYPT_MODE_CBC, $iv);
           $output = rtrim($output, "");
        }
        return $output;
    }

    /**
     * remove profile image
     * URL :
     * Request = {"id":"####","imagename":"####"}
     * Responce =
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function removeImage()
    {
        $request = $this->request->data;
        $result = $this->Schools->findById($this->request->data['id'])->first();
        if (empty($result))
        {
            throw new NotFoundException();
        }
        if ($this->request->is(['patch', 'post', 'put'])) {
            unlink(ROOT.'/uploads/school/'.$this->request->data['imagename']);
            $result->school_image = '';
            if ($this->Schools->save($result))
            {
                $this->serialize(200, 'School image remove successfully.',$result);
            }
            else
            {
                $this->serialize(400, 'School image not remove. Please, try again.');
            }
        }
    }

    /*
    *For get image url from api side
    *URL : http://localhost/api_cakedemo/geturl/profile/1494926702_987642.png
    */
    function makeimgurl()
    {
        $folderName = $this->request->params['pass'][0];
        $ImageName = $this->request->params['pass'][1];
        $ext = pathinfo($ImageName, PATHINFO_EXTENSION);
        $ImgPath = API_BASE_UPLOAD_PATH.$folderName.'/'.$ImageName;
        if($ext == 'jpg' || $ext == 'jpeg' || $ext == 'gif' || $ext == 'png')
        {
            $Image = file_get_contents($ImgPath);
            header("Content-type: image/".$ext);
        }
        else
        {
            $Image = file_get_contents($ImgPath);
            header("Content-type: image/jpeg");
        }
        echo $Image;exit;
    }

    /**
     * Change Password method
     * URL : http://localhost/api_cakedemo/users/changePassword.json
     * Request = {"id":"22","cur_password" : "123456","new_password":"abc"}
     * Responce = { "code": 200, "url": "Users\/changePassword.json", "message": "Password has been change.", "Users": { "id": 22, "role_id": 2, "username": "hardik1", "email": "hardik@technostacks.com", "api_key": "$2y$10$ApFGrgT0vjq30e3eZGiL0OV8P4TC3lSuEGC9a6n7BR3VrgybqGgGi", "api_plain_key": "6d7b9f292099b74f9353ce4445dcdd267d1028b6", "firstname": "", "lastname": "", "profile_image": "", "cover_image": "", "about": "", "gender": "", "verification_code": "", "register_type": 2, "status": 1, "isDeleted": 0, "created": "2017-07-21T06:00:12", "modified": "2017-07-21T06:22:11" } }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    /* Change Password for admin */
    public function changePassword()
    {
        if ($this->request->is(['patch', 'post', 'put']))
        {
            $user = $this->Users->findById($this->request->data['id'])->first();
            if (empty($user))
            {
                throw new NotFoundException();
            }
            if(md5($this->request->data['cur_password']) == $user->password)
            {
                $password = md5($this->request->data['new_password']); 
                $user->password = $password;   
                if ($this->Users->save($user))
                {
                    $this->serialize(200, 'Password has been change.',$user);
                }
                else
                {
                    $this->serialize(400, 'The password could not be saved. Please, try again.',$user);
                }
            }
            else
            {
                $this->serialize(100, 'Current password does not match.',$user = array());
            }
        }
    }

    /**
     * Forgot password
     * URL : 192.168.0.133/bankii/api_bunkii/users/forgotpassword.json
     * Request = {"role_id":"1","email":"admin@gmail.com"}
     * Responce ={ "code": 200, "url": "Users\/forgotpassword.json", "message": "Email Send Sucessfully", "Users": [] }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function forgotpassword()
    {
        
        if($this->request->data['role_id'] == 1)
        {
            $userid = $this->Users->email_check($this->request->data['email']);
            if($userid)
            {
                $user = $this->Users->findById($userid)->first();
                if($user->role_id == 1)
                {
                    $random_number = mt_rand(100000, 999999);
                    $password = md5($random_number); 
                    $user->password = $password;
                    if ($this->Users->save($user))
                    {
                        $emailData['email'] = $user->email;
                        $emailData['password'] = $random_number;
                        $this->getMailer('User')->send('forgot_password',[$emailData]);
                        $this->serialize(200, 'Email send successfully.',$user);
                    }
                    else
                    {
                        $this->serialize(400, 'The email could not be send. Please, try again.',$user);
                    }   
                }
                else
                {
                    $this->serialize(400, 'Your are not an admin.');    
                }
            }
            else
            {
                $this->serialize(400, 'Your are not an admin.');
            }
        }
        else
        {
            $user = $this->Users->findById($this->request->data['id'])->first();
            $users = $this->Users->patchEntity($user, $this->request->data);
            if ($this->Users->save($users))
            {
                $this->serialize(200, 'Email Send Sucessfully');
                $code = $this->request->data['otp_code'];
                $users->verification_code = $code;
                $this->getMailer('User')->send('forgot',[$users]); // Send email to email address
            }
            else
            {
                $this->serialize(400, 'Email Not Send Please try again');
            }
        }
    }
     /*
      URL : 192.168.0.133/bankii/api_bunkii/users/verification.json
      Request : {"verification_code":"1234"}
      Response :  "code": 200, "url": "Users\/verification.json", "message": "verification  done.", "Users": [] }
     */
  
        public function verification()
    {

        $verification_code=$this->request->data["verification_code"]; 
        $conditions = array('verification_code'=>$verification_code,'status'=>0);
        $fields = array('verification_code'=>'','status'=>1);
        $done=$this->Users->updateAll($fields, $conditions);
        if($done){
            $this->serialize(200, 'verification done.');
           }else{
            $this->serialize(400, 'verification not done.');
           }
     
    }


     public function uploadcsv()
    {
        
        $schools = $this->Schools->newEntity();
        if ($this->request->is('post')) {
        
           $email_check = $this->Schools->schoolemail_check_at_school_add($this->request->data['email']);
          
           if(count($email_check)>0){
             //if alredy exist then update their data
            $conditions = array('email'=>$this->request->data['email']);
            $fields = array('name'=>$this->request->data['name'],
                            'address'=>$this->request->data['address'],
                            'email'=>$this->request->data['email'],
                            'web_address'=>$this->request->data['web_address'],
                            'school_image'=>$this->request->data['school_image']
                          );
            $this->Schools->update_if_exist($fields, $conditions);
            $this->serialize(200, 'The schools has been updated.',$schools);

           }
           else{
                    $schools = $this->Schools->patchEntity($schools, $this->request->getData());
                
                    if ($this->Schools->save($schools)) {

                       $this->serialize(200, 'The schools has been saved.',$schools);
                    }
                    else{
                        $this->serialize(400, 'The schools has not been saved.',$schools);
                    }
                }    
            
        }
        
    }

}
