<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Core\Configure;
use Cake\Utility\Text;
use Cake\Network\Exception\NotFoundException;
use App\Error\AppError;
use Cake\ORM\TableRegistry;
use Cake\Mailer\MailerAwareTrait;

/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 */
class ItemsController extends AppController
{
    use MailerAwareTrait;

    public function beforeFilter(Event $event)
    {
        $this->Auth->allow(['login','add','uploadImage','activeAccount','makeimgurl','forgotpassword','getitems']);
        parent::beforeFilter($event);
    }


    /**
     * Index method
     *
     * @return \Cake\Network\Response|null
     */
    public function index()
    {
        $request = $this->request->data;
        $items = $this->Items->find('all', $request);
        $count = $items->count();
        if($count > 0)
        {
            $this->serialize(200, 'Record Found',$items);
        }
        else
        {
            $this->serialize(400, 'No Record Found',$items);
        }
    }

    
    /**
     * View method
     * URL : 192.168.0.133/bankii/api_bunkii/users/view.json
     * Request = {"conditions":{"id":"14"}, "get":"all"}
     * Responce = { "Users": [ { "id": 14, "role_id": 2, "name": "reterert", "email": "erertertret@gmail.com", "school_name": "vidhya vihar sankul", "school_email": "rrrrrr@gmail.com", "api_plain_key": "ceea6e6baf5f553e529b0893467147f419f047af", "api_key": "$2y$10$56pBAR5oSGMlG9H9iPZzz.9exRVP\/M6QDNdrAQH.3RVLd3a.0cowu", "profile_image": "abcd.png", "verification_code": "0512", "register_type": 1, "status": 0, "isDeleted": 0, "created": "2017-09-22T10:44:22", "modified": "2017-09-22T10:44:22" } ] }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $request = $this->request->data;
        $items = $this->Items->find('all', $request);
        $count = $items->count();
        if($count > 0)
        {
            $this->serialize(200, 'Record Found',$items);
        }
        else
        {
            $this->serialize(400, 'No Record Found',$items);
        }
    }

    /**
     * Add method
     *URL : http://192.168.0.133/api_bunkii/items/add.json
     Request : {"icon_image": "1506927228_647453.jpg","item_name" :"pot"}
     Response : { "code": 200, "url": "Items\/add.json", "message": "The Items has been saved.", "Items": { "icon_image": "1506927228_647453.jpg", "item_name": "pot", "id": 2 } }
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        
        $items = $this->Items->newEntity();
        if ($this->request->is('post')) {

            $item = $this->Items->patchEntity($items, $this->request->getData());
        
            if ($this->Items->save($item)) {

               $this->serialize(200, 'The Items has been saved.',$item);
            }
            else{
                $this->serialize(400, 'The Items has not been saved.',$item);
            }
            
        }
        
    }

    /**
     * Edit method
     * URL : 192.168.0.133/bankii/api_bunkii/users/edit.json
     * Request = {"id":14,"name":"jenis","school_name":"rachna","password":"123456","profile_image":"abcd.png"}
     * Responce = { "code": 200, "url": "Users\/edit.json", "message": "The user has been edit.", "Users": { "id": 14, "role_id": 2, "name": "jenis", "email": "erertertret@gmail.com", "school_name": "rachna", "school_email": "rrrrrr@gmail.com", "api_plain_key": "ceea6e6baf5f553e529b0893467147f419f047af", "api_key": "$2y$10$56pBAR5oSGMlG9H9iPZzz.9exRVP\/M6QDNdrAQH.3RVLd3a.0cowu", "profile_image": "abcd.png", "verification_code": "0512", "register_type": 1, "status": 0, "isDeleted": 0, "created": "2017-09-22T10:44:22", "modified": "2017-09-22T11:18:46" } }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        if ($this->request->is(['patch', 'post', 'put']))
        {
            $item = $this->Items->findById($this->request->data['id'])->first();
            if (empty($item))
            {
                throw new NotFoundException();
            }
            $items = $this->Items->patchEntity($item, $this->request->data);
           
            if ($this->Items->save($items))
            {
                $this->serialize(200, 'The Items has been edit.',$items);
            }
            else
            {
                $this->serialize(400, 'The Items could not be saved. Please, try again.',$items);
            }
        }
    }

    /**
     * Delete method
     * URL : 192.168.0.133/bankii/api_bunkii/users/delete.json
     * Request = {"id":"14"}
     * Responce = { "code": 200, "url": "Users\/delete.json", "message": "The user has been deleted.", "Users": { "id": 14, "role_id": 2, "name": "reterert", "email": "erertertret@gmail.com", "school_name": "vidhya vihar sankul", "school_email": "rrrrrr@gmail.com", "api_plain_key": "ceea6e6baf5f553e529b0893467147f419f047af", "api_key": "$2y$10$56pBAR5oSGMlG9H9iPZzz.9exRVP\/M6QDNdrAQH.3RVLd3a.0cowu", "profile_image": "abcd.png", "verification_code": "0512", "register_type": 1, "status": 0, "isDeleted": 1, "created": "2017-09-22T10:44:22", "modified": "2017-09-22T11:09:11" } }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete()
    {
        $this->request->allowMethod(['post', 'delete']);
        $result = $this->Items->findById($this->request->data['id'])->first();
        if (empty($result))
        {
            throw new NotFoundException(__('User not found'), 555);
        }
        if ($this->request->is(['patch', 'post', 'put']))
        {
            $items = $this->Items->patchEntity($result, $this->request->data);
            $items->isDeleted = 1;
            if ($this->Items->save($items))
            {
                $this->serialize(200, 'The Items has been deleted.',$items);
            }
            else
            {
                $this->serialize(400, 'The Items could not be saved. Please, try again.',$items);
            }
        }
    }

    /**
     * Upload image method
     API Name : upooad collages image
    URL : http://192.168.0.133/api_bunkii/items/uploadImage.json
    Request : key : icon_image",
    Response : { "users": { "icon_image": "1506927228_647453.jpg" } }
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function uploadImage()
    {
         
        $users      = array();
        $result = $this->request->data;
        foreach($result as $key=>$file)
        {
            if(is_array($file))
            {
                $arr = $this->saveImage($file, $key);
                if($arr)
                {
                    $users[$key] = $arr['new_name'];
                }
            }
        }
        $this->set(compact('users'), '_serialize', ['users']);
    }

    /**
     * get role method
     * URL :
     * Request =
     * Responce = roles list
     * @return \Cake\Network\Response|null Redirects on successful add, renders view otherwise.
     */
    public function getRoles()
    {
        $roles = $this->Users->Roles->find('list',['conditions'=>["Roles.isDeleted" => 0]],['keyField' => 'id', 'valueField' => 'name']);
        if ($roles)
        {
            $this->serialize(200, 'Roles Found.',$roles);
        }
        else
        {
            $this->serialize(400, 'Roles Not found!.',$roles);
        }
    }

    /**
     * Active account method
     * URL :
     * Request = {"ActivationCode":"####"}
     * Responce =
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function activeAccount()
    {
        $ActivationCode = $this->request->data['ActivationCode'];
        $decryptCode = $this->encrypt_decrypt('decrypt',$ActivationCode);
        $this->request->allowMethod(['post', 'delete']);
        $result = $this->Users->findByVerificationCode(trim($decryptCode))->first();
        if (empty($result))
        {
            throw new NotFoundException(__('User not found'), 555);
        }
        if ($this->request->is(['patch', 'post', 'put']))
        {
            $result->status = 1;
            $result->verification_code = '';
            if ($this->Users->save($result))
            {
                $this->serialize(200, 'Your account is activated now.',$result);
            }
            else
            {
                $this->serialize(400, 'Your account is not activated. Please, try again.');
            }
        }
    }

    /**
     * encrypt_decrypt method for verification_code
     * URL :
     * Request =
     * Responce =
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function encrypt_decrypt($action, $string)
    {
        $output = false;
        $key = '$b@bl2I@?%%4K*mC6r273~8l3|6@>D';
        $iv = md5(md5($key));
        if( $action == 'encrypt' )
        {
           $output = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, md5($key), $string, MCRYPT_MODE_CBC, $iv);
           $output = str_replace(array('+', '/'), array('-', '_'), base64_encode($output));
        }
        else if( $action == 'decrypt' )
        {
           $str = base64_decode(str_replace(array('-', '_'), array('+', '/'), $string));
           $output = mcrypt_decrypt(MCRYPT_RIJNDAEL_256, md5($key), $str, MCRYPT_MODE_CBC, $iv);
           $output = rtrim($output, "");
        }
        return $output;
    }

    /**
     * remove profile image
     * URL :
     * Request = {"id":"####","imagename":"####"}
     * Responce =
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function removeImage()
    {
        $request = $this->request->data;
        $result = $this->Items->findById($this->request->data['id'])->first();
        if (empty($result))
        {
            throw new NotFoundException();
        }
        if ($this->request->is(['patch', 'post', 'put'])) {
            unlink(ROOT.'/uploads/icon/'.$this->request->data['imagename']);
            $result->icon_image = '';
            if ($this->Items->save($result))
            {
                $this->serialize(200, 'icon image remove successfully.',$result);
            }
            else
            {
                $this->serialize(400, 'icon image not remove. Please, try again.');
            }
        }
    }

    /*
    *For get image url from api side
    *URL : http://localhost/api_cakedemo/geturl/profile/1494926702_987642.png
    */
    function makeimgurl()
    {
        $folderName = $this->request->params['pass'][0];
        $ImageName = $this->request->params['pass'][1];
        $ext = pathinfo($ImageName, PATHINFO_EXTENSION);
        $ImgPath = API_BASE_UPLOAD_PATH.$folderName.'/'.$ImageName;
        if($ext == 'jpg' || $ext == 'jpeg' || $ext == 'gif' || $ext == 'png')
        {
            $Image = file_get_contents($ImgPath);
            header("Content-type: image/".$ext);
        }
        else
        {
            $Image = file_get_contents($ImgPath);
            header("Content-type: image/jpeg");
        }
        echo $Image;exit;
    }

    /**
     * Change Password method
     * URL : http://localhost/api_cakedemo/users/changePassword.json
     * Request = {"id":"22","cur_password" : "123456","new_password":"abc"}
     * Responce = { "code": 200, "url": "Users\/changePassword.json", "message": "Password has been change.", "Users": { "id": 22, "role_id": 2, "username": "hardik1", "email": "hardik@technostacks.com", "api_key": "$2y$10$ApFGrgT0vjq30e3eZGiL0OV8P4TC3lSuEGC9a6n7BR3VrgybqGgGi", "api_plain_key": "6d7b9f292099b74f9353ce4445dcdd267d1028b6", "firstname": "", "lastname": "", "profile_image": "", "cover_image": "", "about": "", "gender": "", "verification_code": "", "register_type": 2, "status": 1, "isDeleted": 0, "created": "2017-07-21T06:00:12", "modified": "2017-07-21T06:22:11" } }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    /* Change Password for admin */
    public function changePassword()
    {
        if ($this->request->is(['patch', 'post', 'put']))
        {
            $user = $this->Users->findById($this->request->data['id'])->first();
            if (empty($user))
            {
                throw new NotFoundException();
            }
            if(md5($this->request->data['cur_password']) == $user->password)
            {
                $password = md5($this->request->data['new_password']); 
                $user->password = $password;   
                if ($this->Users->save($user))
                {
                    $this->serialize(200, 'Password has been change.',$user);
                }
                else
                {
                    $this->serialize(400, 'The password could not be saved. Please, try again.',$user);
                }
            }
            else
            {
                $this->serialize(100, 'Current password does not match.',$user = array());
            }
        }
    }

    /**
     * Forgot password
     * URL : 192.168.0.133/bankii/api_bunkii/users/forgotpassword.json
     * Request = {"role_id":"1","email":"admin@gmail.com"}
     * Responce ={ "code": 200, "url": "Users\/forgotpassword.json", "message": "Email Send Sucessfully", "Users": [] }
     * @param string|null $id User id.
     * @return \Cake\Network\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function forgotpassword()
    {
        
        if($this->request->data['role_id'] == 1)
        {
            $userid = $this->Users->email_check($this->request->data['email']);
            if($userid)
            {
                $user = $this->Users->findById($userid)->first();
                if($user->role_id == 1)
                {
                    $random_number = mt_rand(100000, 999999);
                    $password = md5($random_number); 
                    $user->password = $password;
                    if ($this->Users->save($user))
                    {
                        $emailData['email'] = $user->email;
                        $emailData['password'] = $random_number;
                        $this->getMailer('User')->send('forgot_password',[$emailData]);
                        $this->serialize(200, 'Email send successfully.',$user);
                    }
                    else
                    {
                        $this->serialize(400, 'The email could not be send. Please, try again.',$user);
                    }   
                }
                else
                {
                    $this->serialize(400, 'Your are not an admin.');    
                }
            }
            else
            {
                $this->serialize(400, 'Your are not an admin.');
            }
        }
        else
        {
            $user = $this->Users->findById($this->request->data['id'])->first();
            $users = $this->Users->patchEntity($user, $this->request->data);
            if ($this->Users->save($users))
            {
                $this->serialize(200, 'Email Send Sucessfully');
                $code = $this->request->data['otp_code'];
                $users->verification_code = $code;
                $this->getMailer('User')->send('forgot',[$users]); // Send email to email address
            }
            else
            {
                $this->serialize(400, 'Email Not Send Please try again');
            }
        }
    }
     /*
      URL : 192.168.0.133/bankii/api_bunkii/users/verification.json
      Request : {"verification_code":"1234"}
      Response :  "code": 200, "url": "Users\/verification.json", "message": "verification  done.", "Users": [] }
     */
  
        public function verification()
    {

        $verification_code=$this->request->data["verification_code"]; 
        $conditions = array('verification_code'=>$verification_code,'status'=>0);
        $fields = array('verification_code'=>'','status'=>1);
        $done=$this->Users->updateAll($fields, $conditions);
        if($done){
            $this->serialize(200, 'verification done.');
           }else{
            $this->serialize(400, 'verification not done.');
           }
     
    }

     public function getitems()
    {
       
        $Items = $this->Items->find('all',['conditions'=>["isDeleted" => 0]],['keyField' => 'id', 'valueField' => 'name']);
       

        if ($Items)
        {
            $this->serialize(200, 'Items Found.',$Items);
        }
        else
        {
            $this->serialize(400, 'Items Not found!.',$Items);
        }
    }




}
