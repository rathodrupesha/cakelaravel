<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Auth\DefaultPasswordHasher;
use Cake\Utility\Text;
use Cake\Event\Event;

/**
 * Users Model
 *
 * @property \App\Model\Table\RolesTable|\Cake\ORM\Association\BelongsTo $Roles
 *
 * @method \App\Model\Entity\User get($primaryKey, $options = [])
 * @method \App\Model\Entity\User newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\User[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\User|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\User patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\User[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\User findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class ItemsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('items');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

           $this->hasMany('Itemtypes', [
            'foreignKey' => 'item_id'
        ]);

    
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        // $validator
        //     ->email('email')
        //     ->requirePresence('email', 'create')
        //     ->notEmpty('email');

        /*$validator
            ->requirePresence('password', 'create')
            ->notEmpty('password');*/

        /*$validator
            ->requirePresence('api_key', 'create')
            ->notEmpty('api_key');

        $validator
            ->requirePresence('api_plain_key', 'create')
            ->notEmpty('api_plain_key');

        $validator
            ->requirePresence('firstname', 'create')
            ->notEmpty('firstname');

        $validator
            ->requirePresence('lastname', 'create')
            ->notEmpty('lastname');

        $validator
            ->requirePresence('profile_image', 'create')
            ->notEmpty('profile_image');

        $validator
            ->requirePresence('mobile', 'create')
            ->notEmpty('mobile');

        $validator
            ->requirePresence('address', 'create')
            ->notEmpty('address');

        $validator
            ->requirePresence('verification_code', 'create')
            ->notEmpty('verification_code');

        $validator
            ->integer('status')
            ->requirePresence('status', 'create')
            ->notEmpty('status');

        $validator
            ->integer('isDeleted')
            ->requirePresence('isDeleted', 'create')
            ->notEmpty('isDeleted');*/

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
  

    /**
     * Check duplicate email address
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function email_check($param)
    {
        $email = UsersTable::find('list', [
            'conditions' => ['Users.email'=> $param],
        ])->first();
        return $email;
    }
   
     public function school_email_check($param)
    {
        $email = UsersTable::find('list', [
            'conditions' => ['Users.school_email'=> $param],
        ])->first();
        return $email;
    }
    /**
     * get user details
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function getUser($param)
    {
        $user = UsersTable::find()->where($param)->first();
        return $user;
    }

    /**
     * beforeSave method used to create api key and plain key
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
  

    /**
     * add user
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function addUser($users,$request)
    {
        $users = $this->patchEntity($users, $request);
        $users->role_id = $users->role_id;
        $password = md5($users->password);
        $users->password = $password;
        if($request['register_type'] == 1){
            $users->verification_code = str_pad(rand(0,999), 4, "0", STR_PAD_LEFT);
            $users->status = 0;
        }else{
            $users->verification_code = "";
            $users->status = 1;
        }
        $result = $this->save($users);
        return $result;
    }
}
