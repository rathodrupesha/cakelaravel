<?php
namespace App\Mailer;

use Cake\Mailer\Mailer;

class UserMailer extends Mailer
{
    public function register($user)
    {
        
        $this
            ->setTo($user->school_email)
            ->setSubject('Welcome to Bunkii')
            ->setTemplate('register')
            ->setFrom('developer.technostacks@gmail.com','Bunkii' )
            //->setLayout('default')
            ->setEmailFormat('html')
            ->setTransport('smtp')
            //->setTransport('default')
            ->setViewVars(['name' => $user->name,'verification_code' => $user->verification_code]);
    }

    public function forgot($users)
    {
        $this
            ->setTo($users->email)
            ->setSubject('Reset password')
            ->setTemplate('forgot')
            ->setFrom('developer.technostacks@gmail.com','Technostacks' )
            //->setLayout('default')
            ->setEmailFormat('html')
            ->setTransport('smtp')
            //->setTransport('default')
            ->setViewVars(['firstname' => $users->email,'verification_code' => $users->verification_code]);

    }
    
    public function social_register($user)
    {
        $this
            ->setTo($user['email'])
            ->setSubject('Welcome to Bunkii' )
            ->setTemplate('social_register')
            ->setFrom('developer.technostacks@gmail.com','Bunkii' )
            //->setLayout('default')
            ->setEmailFormat('html')
            ->setTransport('smtp')
            //->setTransport('default')
            ->setViewVars(['username' => $user['email'],'password' => $user['password']]);
    }

    public function forgot_password($user)
    {
        $this
            ->setTo($user['email'])
            ->setSubject('Forgot Password' )
            ->setTemplate('forgot_password')
            ->setFrom('developer.technostacks@gmail.com','Technostacks' )
            //->setLayout('default')
            ->setEmailFormat('html')
            ->setTransport('smtp')
            //->setTransport('default')
            ->setViewVars(['username' => $user['email'],'password' => $user['password']]);
    }
}
