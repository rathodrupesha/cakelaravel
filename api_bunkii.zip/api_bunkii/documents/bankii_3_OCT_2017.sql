-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 03, 2017 at 03:01 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bankii`
--

-- --------------------------------------------------------

--
-- Table structure for table `collages`
--

CREATE TABLE `collages` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `collages_image` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '1=active, 0=inactive',
  `isDeleted` int(11) NOT NULL DEFAULT '0' COMMENT '0=no,1=yes',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `collages`
--

INSERT INTO `collages` (`id`, `user_id`, `title`, `collages_image`, `status`, `isDeleted`, `created`, `modified`) VALUES
(1, 14, 'all', '1506491304_982742.jpg', 1, 0, '0000-00-00 00:00:00', '2017-09-27 07:30:43'),
(2, 15, 'all', '1506491304_982742.jpg', 1, 0, '0000-00-00 00:00:00', '2017-09-27 06:35:28'),
(3, 15, 'all', '1506491304_982742.jpg', 1, 0, '0000-00-00 00:00:00', '2017-09-27 12:07:06');

-- --------------------------------------------------------

--
-- Table structure for table `favorites`
--

CREATE TABLE `favorites` (
  `id` int(11) NOT NULL,
  `fromuser_id` int(11) NOT NULL,
  `touser_id` int(11) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '1=active, 0=inactive',
  `isDeleted` int(1) NOT NULL DEFAULT '0' COMMENT '1=yes, 0=no',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `favorites`
--

INSERT INTO `favorites` (`id`, `fromuser_id`, `touser_id`, `status`, `isDeleted`, `created`, `modified`) VALUES
(7, 14, 19, 1, 0, '2017-09-26 06:34:19', '2017-09-26 06:34:19'),
(8, 5, 20, 1, 0, '2017-09-26 06:34:19', '2017-09-26 06:34:19');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `icon_image` varchar(255) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '1=active, 0=inactive',
  `isDeleted` int(1) NOT NULL DEFAULT '0' COMMENT '1=yes, 0=no',
  `created` datetime NOT NULL,
  `modify` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `icon_image`, `item_name`, `status`, `isDeleted`, `created`, `modify`) VALUES
(1, '1507021170_90980.jpg', 'pot', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, '1507021170_90980.jpg', 'pot', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, '1507021170_90980.jpg', 'sadf', 1, 0, '2017-10-02 10:30:20', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `itemtypes`
--

CREATE TABLE `itemtypes` (
  `id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `rooms_image` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '1=active, 0=inactive',
  `isDeleted` int(1) NOT NULL DEFAULT '0' COMMENT '1=yes, 0=no',
  `created` datetime NOT NULL,
  `modify` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `itemtypes`
--

INSERT INTO `itemtypes` (`id`, `item_id`, `title`, `description`, `rooms_image`, `status`, `isDeleted`, `created`, `modify`) VALUES
(1, 1, 'blastic pot', 'this is good', '1506929384_674675.jpg', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 1, 'blastic pot', 'this is good', '1506929384_674675.jpg', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 8, 'sdfe', 'dgr', '', 1, 0, '2017-10-03 09:04:21', '0000-00-00 00:00:00'),
(4, 8, 'sdfe', 'dgr', '1507024661_971524.jpg', 1, 0, '2017-10-03 09:05:20', '0000-00-00 00:00:00'),
(5, 1, 'gr', 'htrh', '1507025621_334953.jpg', 1, 0, '2017-10-03 09:06:22', '0000-00-00 00:00:00'),
(6, 8, 'test', 'testing', '1507025850_976317.jpg', 1, 0, '2017-10-03 10:17:36', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '1=active, 0=inactive',
  `isDeleted` int(1) NOT NULL DEFAULT '0' COMMENT '1=yes, 0=no',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `status`, `isDeleted`, `created`, `modified`) VALUES
(1, 'admin', 1, 0, '2017-09-22 08:20:00', '2017-09-22 00:18:18'),
(2, 'user', 1, 0, '2017-09-22 08:21:18', '2017-09-22 06:15:13'),
(3, 'super', 1, 1, '2017-09-25 10:37:48', '2017-09-25 10:37:55');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `school_name` varchar(255) NOT NULL,
  `school_email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `api_plain_key` varchar(255) NOT NULL,
  `api_key` varchar(255) NOT NULL,
  `profile_image` varchar(255) NOT NULL,
  `verification_code` varchar(20) NOT NULL,
  `register_type` int(11) NOT NULL DEFAULT '1' COMMENT '1=normal,2=facebook,3=google+',
  `favorites_counter` int(11) NOT NULL,
  `class_of` int(11) NOT NULL,
  `cleanliness` int(11) NOT NULL,
  `sleeper` int(11) NOT NULL,
  `noise_level` int(11) NOT NULL,
  `graduation_year` int(11) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1' COMMENT '1=active, 0=inactive',
  `isDeleted` int(1) NOT NULL DEFAULT '0' COMMENT '1=yes, 0=no',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role_id`, `name`, `email`, `school_name`, `school_email`, `password`, `api_plain_key`, `api_key`, `profile_image`, `verification_code`, `register_type`, `favorites_counter`, `class_of`, `cleanliness`, `sleeper`, `noise_level`, `graduation_year`, `status`, `isDeleted`, `created`, `modified`) VALUES
(14, 1, 'admin', 'admin@gmail.com', 'oxford', 'rrrrrr@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'ceea6e6baf5f553e529b0893467147f419f047af', '$2y$10$56pBAR5oSGMlG9H9iPZzz.9exRVP/M6QDNdrAQH.3RVLd3a.0cowu', '1496673581_71447.jpg', '0512', 1, 2, 0, 0, 0, 0, 0, 1, 0, '2017-09-22 10:44:22', '2017-09-25 12:13:35'),
(19, 2, 'usert1', 'user@gmail.com', 'user school 1', 'rupesh@technostacks.com', 'e10adc3949ba59abbe56e057f20f883e', '6a20c39cc9fcb46559eaf8245595565380d89ac5', '$2y$10$jdeuzOLxnyCKDWCq8PR1vespOvVUwA0aDHKrxJMRKwCtOWlOhIRze', '1496673589_653973.jpg', '0198', 1, 0, 0, 0, 0, 0, 0, 1, 0, '2017-09-22 10:45:08', '2017-09-25 08:45:05'),
(27, 2, 'mike grabs', 'mike123@gmail.com', 'atlantica chiild school', 'schoo123@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'fd562780ea711ff5883cf84f84a0a00dfaf8093f', '$2y$10$qkEKk1Zy8N9/fS4wTuIbHObyt8z2/Bx4dC6vJhlXcduFroDDX91AW', '1506329277_17154.jpg', '', 1, 0, 0, 0, 0, 0, 0, 1, 0, '2017-09-25 07:11:41', '2017-09-25 09:30:26'),
(28, 2, 'jenis', 'jenishfdcf@gmail.com', 'vidhya vihar sankul', 'developer.laravel@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'b89ed29c32cc09e5cd052e0b777ca2b4fae8c7c0', '$2y$10$Z7kNcp571o918PSJHZ8gLeIsKA7skl/IJh432GdGAPlq5wol8VFRm', 'abcd.png', '0568', 1, 0, 0, 0, 0, 0, 0, 0, 0, '2017-09-26 10:16:49', '2017-09-26 10:16:49'),
(55, 2, 'a', 'a@gmail.com', 'aschool', 'aschool@Gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '4967732c5c1796d455edd0d864ce44c5d257d2a2', '$2y$10$nrTaM1tJiz3.ADDgGarqeeaiYswsGofEonHR0VO0qN6R.VwuvvCqC', '', '', 1, 0, 0, 0, 0, 0, 0, 1, 0, '2017-09-28 07:05:58', '2017-09-28 07:05:58'),
(64, 2, 'username', 'username@gmail.com', 'school', 'school@gmail.edu', 'e10adc3949ba59abbe56e057f20f883e', '133cfd8d7e4fd6d89982f887e1d6656e6dffba7f', '$2y$10$UW9PTuN0P08N2xnOy5MxmeNDFLHyiBurGx3UmoX8JQSzixhCeS8gG', '', '', 1, 0, 0, 0, 0, 0, 0, 1, 0, '2017-09-28 08:36:43', '2017-09-28 08:36:43'),
(65, 2, 'diyaa', 'diyaa@gmail.com', 'test', 'diyaa@student.edu', 'e10adc3949ba59abbe56e057f20f883e', 'c51007ee730bfab79f3788d6c892d8105c0072aa', '$2y$10$kfUyl3zmLBb81ixaxGgrXO1Csj9/jLGqCvsJmW8vg/isQx7LNVKdi', 'abcd.png', '0658', 1, 0, 0, 0, 0, 0, 0, 0, 0, '2017-09-28 08:38:01', '2017-09-28 08:38:01'),
(66, 2, 'technostacks', 'testing.technostacks1@gmail.com', 'testing', 't@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '2c39345405e339f1d01a0f058c53d937c5744c76', '$2y$10$DLFeB.w.WfVgDcBmyufwCevw4l1WbtjY10q9y4wtjLgNT3I3QMpVi', '', '', 1, 0, 0, 0, 0, 0, 0, 1, 0, '2017-09-28 08:41:14', '2017-09-28 08:41:14'),
(67, 2, 'abc', 'abc@gmail.com', 'asch', 'asch@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '686daa9ccb1eb338f6cfd50f1fa848582000a88a', '$2y$10$h6/35F7UI5jbEognpCBQYuodBBHE8nJjAsWf4XG2dHj.g/An9R48q', '', '', 1, 0, 0, 0, 0, 0, 0, 1, 0, '2017-09-28 09:39:51', '2017-09-28 09:39:51'),
(68, 2, 'jenis', 'jenishfddddddcf@gmail.com', 'vidhya vihar sankul', 'develodddddper.laravel@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '91b6ae09f03163ae8de9a38f731f65fb24e8095d', '$2y$10$WkLHXPN9H.kuaJv1R52i3.LEfb.iioAwWxtv8HDhW5w68KSGHs0W.', 'abcd.png', '0060', 1, 0, 0, 0, 0, 0, 0, 0, 0, '2017-09-29 04:13:57', '2017-09-29 04:13:57');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `collages`
--
ALTER TABLE `collages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itemtypes`
--
ALTER TABLE `itemtypes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `collages`
--
ALTER TABLE `collages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `favorites`
--
ALTER TABLE `favorites`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `itemtypes`
--
ALTER TABLE `itemtypes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
