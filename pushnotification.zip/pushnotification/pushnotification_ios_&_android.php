<?php
//http://webrocom.net/php-send-push-notification-to-ios/



//D: 810dc9f485b9131b603e3ac07407fb495487f26d3764395bf7e5758420dbf493
//P: f7a84e7c369d4264cd03fc5aa91479b8f3f99644a444e2f867c8d1685f0671f8
//echo $_SERVER['DOCUMENT_ROOT'];

$deviceToken = '1c24418f34e35b885b295dadfdce24c59cb0c12dcaec083f37e91f71a52c8fbd';
  
$passphrase = 'admin';

$message = 'Hello drive';
//$message = 'hopondrive';

////////////////////////////////////////////////////////////////////////////////

$ctx = stream_context_create();
$filename = 'Ober_Customer_DEV_CK.pem';
//$filename = 'HoponDriver_CK.pem';
stream_context_set_option($ctx, 'ssl', 'local_cert', $filename);
stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);

// Open a connection to the APNS server
$fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err,$errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

if (!$fp)
exit("Failed to connect: $err $errstr" . PHP_EOL);

echo 'Connected to APNS' . PHP_EOL;

// Create the payload body
$body['aps'] = array(
'alert' => $message,
'sound' => 'default'
);

// Encode the payload as JSON
$payload = json_encode($body);

// Build the binary notification
$msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;

// Send it to the server
$result = fwrite($fp, $msg, strlen($msg));

if (!$result)
    echo 'Message not delivered' . PHP_EOL;
else
    echo 'Message successfully delivered'.PHP_EOL;

// Close the connection to the server
fclose($fp);

?>

/* ------------------   for Android  ------------------------------*/

public function send_android_notification($regId,$message)
    {

      require_once APPPATH.'third_party/notification/firebase.php';
      require_once APPPATH.'third_party/notification/push.php';

      $firebase = new Firebase();
      $push = new Push();

      $title ="SpeedyFax";
      $push_type="individual";
 
      $include_image =""; 
      $payload='';

      $push->setTitle($title);
      $push->setMessage($message);
      $push->setImage($include_image);
      $push->setIsBackground(FALSE);
      $push->setPayload($payload);
      $json = $push->getPush();

      $response = $firebase->send($regId, $json);
         // echo "<pre>"; print_r($response); exit();


    }