<?php

namespace App\Traits;

/**
 * Common response trait
 */
trait ResponseTrait
{

    private static $enckey = 'MYUTPbxyqi2a2A6y';
    /**
     * Response - Success
     * @param type $data
     * @param type $message
     * @param type $code
     * @return type
     */
    public function success($data = null, $message = 'SUCCESS', $code = "200")
    {
        $meta = [
            'status' => (string)$code,
            'message' => trans('message.'.$message),
            'data' => $data
        ];
        // return response()->json($meta, $code);
        $dataEnc = $this->cryptoJsAesEncrypt(self::$enckey, json_encode($meta));
        return response()->json($dataEnc, $code);
    }

    /**
     * Response - Error
     * @param type $message
     * @param type $code
     * @return type
     */
    public function error($message = 'ERROR', $code = "400")
    {
        $meta = [
            'status' => (string)$code,
            'message' => trans('error.'.$message),
            'data' => (object) []
        ];
        return response()->json(['meta' => $meta], $code);
    }

    /**
     * Response - Server side validation error message
     * @param type $validation
     * @return type
     */
    public function validationError(
        $validation,
        $message = 'VALIDATION_ERROR',
        $code = "400"
    ) {
        $fieldMessages = $validation->errors();
        //return response($messages)->setStatusCode(422, 'Unprocessable Entity');
        $meta          = [
            // 'status' => false,
            'message' => 'Server side validation',
            'message_code' => $message,
            'status' => "400"
        ];
        return response()->json(['meta' => $meta, 'errors' => $fieldMessages], $code);
    }

    /*
     * Auth checking for Chrome API
     */
    public function checkAuthClient(){
        $headers = apache_request_headers();
        $client_service = (isset($headers['Client-Service']) ? $headers['Client-Service'] : '');
        $auth_key = (isset($headers['Auth-Key']) ? $headers['Auth-Key'] : '');
        // if($client_service == env('client_service') && $auth_key == env('auth_key') && \Request::header('User-Agent') == 'PostmanRuntime/7.18.0'){
        if($client_service == env('client_service') && $auth_key == env('auth_key')){
            return true;
        } else {
            return false;
            $meta = [
                'status' => 401,
                'message' => 'Unauthorized',
                'data' => (object) []
            ];
            return response()->json(['meta' => $meta], 401);
        }
    }

    /**
     * Decrypt data from a CryptoJS json encoding string
     *
     * @param mixed $passphrase
     * @param mixed $jsonString
     * @return mixed
     */
    public function cryptoJsAesDecrypt($passphrase, $jsonString)
    {
        $jsondata = json_decode($jsonString, true);
        $salt = hex2bin($jsondata["s"]);
        $ct = base64_decode($jsondata["ct"]);
        $iv  = hex2bin($jsondata["iv"]);
        $concatedPassphrase = $passphrase.$salt;
        $md5 = array();
        $md5[0] = md5($concatedPassphrase, true);
        $result = $md5[0];
        for ($i = 1; $i < 3; $i++) {
            $md5[$i] = md5($md5[$i - 1].$concatedPassphrase, true);
            $result .= $md5[$i];
        }
        $key = substr($result, 0, 32);
        $data = openssl_decrypt($ct, 'aes-256-cbc', $key, true, $iv);
        return json_decode($data, true);
    }

    /**
     * Encrypt value to a cryptojs compatiable json encoding string
     *
     * @param mixed $passphrase
     * @param mixed $value
     * @return string
     */
    public function cryptoJsAesEncrypt($passphrase, $value)
    {
        $salt = openssl_random_pseudo_bytes(8);
        $salted = '';
        $dx = '';
        while (strlen($salted) < 48) {
            $dx = md5($dx.$passphrase.$salt, true);
            $salted .= $dx;
        }
        $key = substr($salted, 0, 32);
        $iv  = substr($salted, 32, 16);
        $encrypted_data = openssl_encrypt(json_encode($value), 'aes-256-cbc', $key, true, $iv);
        $data = array("ct" => base64_encode($encrypted_data), "iv" => bin2hex($iv), "s" => bin2hex($salt));
        return json_encode($data);
    }
}
