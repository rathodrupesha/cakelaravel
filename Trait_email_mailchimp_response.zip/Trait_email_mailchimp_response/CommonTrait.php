<?php

namespace App\Traits;

// Event for notification email, alert, sms
use App\Events\SendMail;
use App\Model\EmailTemplate;
use App\Model\SiteUser;
use App\Model\CronRunInfo;

/**
 * Common response trait
 */
trait CommonTrait
{

    /**
     *
     * @param type $template
     * @param type $toIds
     * @param type $tags
     * @return boolean
     */
    // public function sendEmailNotification($template, $toIds = [], $tags = [])
    // {
    //     // get template
    //     $templateData = EmailTemplate::getTemplate(['email_key' => $template]);

    //     if (!empty($templateData) && !empty($toIds)) {
    //         $toIds = array_unique($toIds);

    //         foreach ($toIds as $id) {
    //             $user    = SiteUser::select(['firstname', 'lastname', 'email'])
    //                         ->where(['id' => $id])->first();
    //             $toEmail = $user->email;

    //             $toUserFullname    = $tags['USERNAME']  = $user->firstname;
    //             $fromName          = env('MAIL_FROMNAME','');
    //             $fromEmail         = env('MAIL_USERNAME');
    //             $search            = $replace           = [];

    //             $tags['SITE_LINK'] = env('SITE_LINK');
    //             $tags['SIGNIN_LINK'] = env('SITE_LINK').'/login';
    //             $tags['SIGNUP_LINK'] = env('SITE_LINK').'/signup';
    //             $tags['BACKGROUNDIMAGE'] =url('').'/public/frontend/images/blue-pattern-bg.jpg';
    //             $tags['TRANSPERENT_IMAGE']=url('').'/public/frontend/images/trnsp-bg.png';
    //             $tags['LOGOETEMP']=url('').'/public/frontend/images/logo-eTmp.png';
    //             $tags['FB_LOGO']=url('').'/public/frontend/images/fb-icon.png';
    //             $tags['TWT_LOGO']=url('').'/public/frontend/images/twt-icon.png';
    //             $tags['INST_LOGO']=url('').'/public/frontend/images/ins-icon.png';

    //             $tags['LOGO']      = url().'/public/frontend/images/logo_2.png';//config('mail.logo');
    //             $tags['YEAR']      = date('Y');
    //             $tags['PRODUCT_ID']      = isset($tags['PRODUCT_ID']) ? $tags['PRODUCT_ID'] : "";
    //             $tags['PRODUCT_STATE']      = isset($tags['PRODUCT_STATE']) ? $tags['PRODUCT_STATE'] : "";
    //             $tags['ADS_ID']      = isset($tags['ADS_ID']) ? $tags['ADS_ID'] : "";
    //             $tags['ADS_STATE']      = isset($tags['ADS_STATE']) ? $tags['ADS_STATE'] : "";
    //             $tags['BLOCK']      = isset($tags['BLOCK']) ? $tags['BLOCK'] : "";
    //             $tags['DELETE']      = isset($tags['DELETE']) ? $tags['DELETE'] : "";

    //             foreach ($tags as $k => $v) {
    //                 array_push($search, "##{$k}##");
    //                 array_push($replace, $v);
    //             }

    //             $mailData['toName']       = $toUserFullname;
    //             $mailData['toEmail']      = $toEmail;
    //             $mailData['fromName']     = $fromName;
    //             $mailData['fromEmail']    = $fromEmail;
    //             $mailData['emailSubject'] = nl2br(str_replace($search, $replace, $templateData['email_subject']));
    //             $mailData['emailContent'] = str_replace($search, $replace, $templateData['email_body']);
    //             //$template_notification = nl2br(str_replace($search, $replace, $templateData['notification_content']));
    //             //$template_sms = str_replace($search, $replace, $templateData['sms_content']);
    //             //attachment

    //             \Event::fire(new SendMail($mailData));
    //         }

    //         return true;
    //     }
    //     return false;
    // }
    public function sendEmailNotification($template, $toIds = [], $tags = [])
    {
        // get template
        $templateData = EmailTemplate::getTemplate(['email_key' => $template]);

        if (!empty($templateData) && !empty($toIds)) {
            $toIds = array_unique($toIds);

            foreach ($toIds as $id) {
                $user    = SiteUser::select(['firstname', 'lastname', 'email'])
                            ->where(['id' => $id])->first();
                $toEmail = $user->email;

                $toUserFullname    = $tags['USERNAME']  = $user->firstname;
                $fromName          = env('MAIL_FROMNAME', '');
                $fromEmail         = env('MAIL_USERNAME');
                $search            = $replace           = [];

                // $tags['SITE_LINK'] = env('SITE_LINK');
                // $tags['SIGNIN_LINK'] = env('SITE_LINK').'/login';
                // $tags['SIGNUP_LINK'] = env('SITE_LINK').'/signup';
                // $tags['BACKGROUNDIMAGE'] =url('').'/public/frontend/images/blue-pattern-bg.jpg';
                // $tags['TRANSPERENT_IMAGE']=url('').'/public/frontend/images/trnsp-bg.png';
                // $tags['LOGOETEMP']=url('').'/public/frontend/images/logo-eTmp.png';
                // $tags['FB_LOGO']=url('').'/public/frontend/images/fb-icon.png';
                // $tags['TWT_LOGO']=url('').'/public/frontend/images/twt-icon.png';
                // $tags['INST_LOGO']=url('').'/public/frontend/images/ins-icon.png';


                $tags['BACKGROUNDIMAGE'] ='https://www.checkoutsaver.com/public/frontend/images/blue-pattern-bg.jpg';
                $tags['TRANSPERENT_IMAGE']='https://www.checkoutsaver.com/public/frontend/images/trnsp-bg.png';
                $tags['LOGOETEMP']='https://www.checkoutsaver.com/public/frontend/images/logo-eTmp.png';
                $tags['FB_LOGO']='https://www.checkoutsaver.com/public/frontend/images/fb-icon.png';
                $tags['TWT_LOGO']='https://www.checkoutsaver.com/public/frontend/images/twt-icon.png';
                $tags['INST_LOGO']='https://www.checkoutsaver.com/public/frontend/images/ins-icon.png';


                $tags['LOGO']      = 'https://www.checkoutsaver.com/public/frontend/images/logo_2.png';//config('mail.logo');
                $tags['YEAR']      = date('Y');
                $tags['PRODUCT_ID']      = isset($tags['PRODUCT_ID']) ? $tags['PRODUCT_ID'] : "";
                $tags['PRODUCT_STATE']      = isset($tags['PRODUCT_STATE']) ? $tags['PRODUCT_STATE'] : "";
                $tags['ADS_ID']      = isset($tags['ADS_ID']) ? $tags['ADS_ID'] : "";
                $tags['ADS_STATE']      = isset($tags['ADS_STATE']) ? $tags['ADS_STATE'] : "";
                $tags['BLOCK']      = isset($tags['BLOCK']) ? $tags['BLOCK'] : "";
                $tags['DELETE']      = isset($tags['DELETE']) ? $tags['DELETE'] : "";

                foreach ($tags as $k => $v) {
                    array_push($search, "##{$k}##");
                    array_push($replace, $v);
                }

                $mailData['toName']       = $toUserFullname;
                $mailData['toEmail']      = $toEmail;
                $mailData['fromName']     = $fromName;
                $mailData['fromEmail']    = $fromEmail;
                $mailData['emailSubject'] = nl2br(str_replace($search, $replace, $templateData['email_subject']));
                $mailData['emailContent'] = str_replace($search, $replace, $templateData['email_body']);
                //$template_notification = nl2br(str_replace($search, $replace, $templateData['notification_content']));
                //$template_sms = str_replace($search, $replace, $templateData['sms_content']);
                //attachment

                \Event::fire(new SendMail($mailData));
            }

            return true;
        }
        return false;
    }
    /**
     *
     * @param type $template
     * @param type $toEmailIds
     * @param type $tags
     * @return boolean
     */
    public function sendEmailNotificationDirectToEmailIds($template, $toEmailIds = [], $tags = [])
    {
        // get template
        $templateData = EmailTemplate::getTemplate(['email_key' => $template]);

        if (!empty($templateData) && !empty($toEmailIds)) {
            $toEmailIds = array_unique($toEmailIds);

            foreach ($toEmailIds as $id) {
                $toEmail = $id;

                $toUserFullname    = $tags['USERNAME']  = "";
                $fromName          = env('MAIL_FROMNAME', '');
                $fromEmail         = env('MAIL_USERNAME');
                $search            = $replace           = [];

                // $tags['SITE_LINK'] = env('SITE_LINK');
                // $tags['SIGNIN_LINK'] = env('SITE_LINK').'/login';
                // $tags['SIGNUP_LINK'] = env('SITE_LINK').'/signup';
                // $tags['BACKGROUNDIMAGE'] =url('').'/public/frontend/images/blue-pattern-bg.jpg';
                // $tags['TRANSPERENT_IMAGE']=url('').'/public/frontend/images/trnsp-bg.png';
                // $tags['LOGOETEMP']=url('').'/public/frontend/images/logo-eTmp.png';
                // $tags['FB_LOGO']=url('').'/public/frontend/images/fb-icon.png';
                // $tags['TWT_LOGO']=url('').'/public/frontend/images/twt-icon.png';
                // $tags['INST_LOGO']=url('').'/public/frontend/images/ins-icon.png';


                $tags['BACKGROUNDIMAGE'] ='https://www.checkoutsaver.com/public/frontend/images/blue-pattern-bg.jpg';
                $tags['TRANSPERENT_IMAGE']='https://www.checkoutsaver.com/public/frontend/images/trnsp-bg.png';
                $tags['LOGOETEMP']='https://www.checkoutsaver.com/public/frontend/images/logo-eTmp.png';
                $tags['FB_LOGO']='https://www.checkoutsaver.com/public/frontend/images/fb-icon.png';
                $tags['TWT_LOGO']='https://www.checkoutsaver.com/public/frontend/images/twt-icon.png';
                $tags['INST_LOGO']='https://www.checkoutsaver.com/public/frontend/images/ins-icon.png';


                $tags['LOGO']      = 'https://www.checkoutsaver.com/public/frontend/images/logo_2.png';//config('mail.logo');
                $tags['YEAR']      = date('Y');
                $tags['PRODUCT_ID']      = isset($tags['PRODUCT_ID']) ? $tags['PRODUCT_ID'] : "";
                $tags['PRODUCT_STATE']      = isset($tags['PRODUCT_STATE']) ? $tags['PRODUCT_STATE'] : "";
                $tags['ADS_ID']      = isset($tags['ADS_ID']) ? $tags['ADS_ID'] : "";
                $tags['ADS_STATE']      = isset($tags['ADS_STATE']) ? $tags['ADS_STATE'] : "";
                $tags['BLOCK']      = isset($tags['BLOCK']) ? $tags['BLOCK'] : "";
                $tags['DELETE']      = isset($tags['DELETE']) ? $tags['DELETE'] : "";

                foreach ($tags as $k => $v) {
                    array_push($search, "##{$k}##");
                    array_push($replace, $v);
                }

                $mailData['toName']       = $toUserFullname;
                $mailData['toEmail']      = $toEmail;
                $mailData['fromName']     = $fromName;
                $mailData['fromEmail']    = $fromEmail;
                $mailData['emailSubject'] = nl2br(str_replace($search, $replace, $templateData['email_subject']));
                $mailData['emailContent'] = str_replace($search, $replace, $templateData['email_body']);
                //$template_notification = nl2br(str_replace($search, $replace, $templateData['notification_content']));
                //$template_sms = str_replace($search, $replace, $templateData['sms_content']);
                //attachment

                \Event::fire(new SendMail($mailData));
            }

            return true;
        }
        return false;
    }

    /**
    *AIM: MailChimp Subscribe new user into list
    * @param type $id
    * @return boolean
    */
    public function mailchimpScribeUser($id)
    {
        $userData=SiteUser::where('id', $id)->first();

        $email=$userData->email;
        $firstName=$userData->firstname;
        $lastName=$userData->lastname;
        $address=$userData->address;
        $phoneno=$userData->phoneno;
        $dob=$userData->dob;

        $url='https://<dc>.api.mailchimp.com/3.0/lists/'.env('MAILCHIMP_LIST_ID').'/members';

        if (env('MAIL_CHIMP_WORKING')=='on'  && env('MAIL_CHIMP_ENVIROMENT')=='prod' && strpos(env('MAILCHIMP_APIKEY'), '-')) {
            $keypart = explode('-', env('MAILCHIMP_APIKEY'));
            $url = str_replace('<dc>', $keypart[1], $url);
            $authorization='apikey '.env('MAILCHIMP_APIKEY');
            $headers = array(
                        'Authorization:'.$authorization,
                        'Content-Type: application/json'
                        );

            $fields = array(
                        "email_address"=>$email,
                        "status"=>'subscribed',
                        "merge_fields"=>array('FNAME'=>$firstName,'LNAME'=>$lastName,'phone'=>'','address'=>$address,'birthday'=>$dob)
                     );

            $ch = curl_init();
            // Set the url, number of POST vars, POST data
            curl_setopt($ch, CURLOPT_URL, $url);     // url set here
            curl_setopt($ch, CURLOPT_POST, true);    // post type here
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);  // set header type
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);   // set return transfer true means json false means string

        // Disabling SSL Certificate support temporarly
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));  //set post data or fields in json formate

            // Execute post
            $result = curl_exec($ch);

            // Check errors
            if ($result) {
                $resultArry=json_decode($result);

                if (isset($resultArry->status) && !empty($resultArry->status=='subscribed')) {
                    //user subscribe successfully
                    SiteUser::where('id', $id)->update(['is_mailchimp_subscribe'=>'Y','mailchimp_list_id'=>$resultArry->list_id,'mailchimp_member_id'=>$resultArry->id]);
                } else {
                    //400  or not subscribe
                    SiteUser::where('id', $id)->update(['is_mailchimp_subscribe'=>'N']);
                }
            }

            // Close connection
            curl_close($ch);
        } else {
            return true; // api key not get or not production enviroment
        }
    }//func

    /**
    *AIM: MailChimp UNSubscribe user from list
    * @param type $id
    * @return boolean
    */
    public function mailchimpUnScribeUser($id)
    {
        $userData=SiteUser::where('id', $id)->first();

        $memberId=$userData->mailchimp_member_id;
        $listId=$userData->mailchimp_list_id;
        $email=$userData->email;
        $firstName=$userData->firstname;
        $lastName=$userData->lastname;
        $address=$userData->address;
        $phoneno=$userData->phoneno;
        $dob=$userData->dob;

        $url='https://<dc>.api.mailchimp.com/3.0/lists/'.env('MAILCHIMP_LIST_ID').'/members/'.$memberId;

        if (env('MAIL_CHIMP_WORKING')=='on' && env('MAIL_CHIMP_ENVIROMENT')=='prod' && strpos(env('MAILCHIMP_APIKEY'), '-')) {
            $keypart = explode('-', env('MAILCHIMP_APIKEY'));
            $url = str_replace('<dc>', $keypart[1], $url);
            $authorization='apikey '.env('MAILCHIMP_APIKEY');
            $headers = array(
                        'Authorization:'.$authorization,
                        'Content-Type: application/json'
                        );

            $fields = array(
                        "email_address"=>$email,
                        "status"=>'unsubscribed',
                        "merge_fields"=>array('FNAME'=>$firstName,'LNAME'=>$lastName,'phone'=>'','address'=>$address,'birthday'=>$dob)
                     );

            $ch = curl_init();
            // Set the url, number of POST vars, POST data
            curl_setopt($ch, CURLOPT_URL, $url);     // url set here
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");  // post type here
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);  // set header type
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);   // set return transfer true means json false means string

        // Disabling SSL Certificate support temporarly
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));  //set post data or fields in json formate

            // Execute post
            $result = curl_exec($ch);

            // Check errors
            if ($result) {
                $resultArry=json_decode($result);

                if (isset($resultArry->status) && !empty($resultArry->status=='unsubscribed')) {
                    //user subscribe successfully
                    SiteUser::where('id', $id)->update(['is_mailchimp_subscribe'=>'U']);
                }
            }

            // Close connection
            curl_close($ch);
        } else {
            return true; // api key not get or not production enviroment
        }
    }//func

    /**
    * @AIM: cron run or not info dump into db
    * @Method:cronRunInfoDumpInDb
    * @Input:Array
    * @Output:boolean
    * @Author: rupesh
    */
    public function cronRunInfoDumpInDb($dumpData)
    {
        if (!empty($dumpData)) {
            $isCronExist=CronRunInfo::where('cron_command', $dumpData['cron_command'])->count();

            if ($isCronExist>0) {
                //Update
                unset($dumpData['created_at']);
                CronRunInfo::where('cron_command', $dumpData['cron_command'])->update($dumpData);
            } else {
                //Insert
                CronRunInfo::create($dumpData);
            }
        } else {
            \Log::info("NO CRON DATA DUMP IN DB");
            return true;
        }
    }//func
}
