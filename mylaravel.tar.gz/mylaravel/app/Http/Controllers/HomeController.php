<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
       $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

          return view('layouts.partial.blank');
      echo "home.index";
        //return view('home');
    }
    public function demopage()
    {
         //flash("this is test msg only");
         return view('layouts.partial.blank');
         // return view('layouts.partial.demo1');   
    }
}
