<?php $__env->startSection('content'); ?>
<div class="container">



<!-- ORIGNAL -->

<!--     <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Reset Password')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('password.update')); ?>">
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="token" value="<?php echo e($token); ?>">

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e($email ?? old('email')); ?>" required autofocus>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Reset Password')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div> -->




   <header>
     <h1>Reset Password</h1>          
  </header>


   <section>               
                <div id="container_demo" >
                  
                    <a class="hiddenanchor" id="toregister"></a>
                    <a class="hiddenanchor" id="tologin"></a>
                    <div id="wrapper">
                        <div id="login" class="animate form">
                          <form method="POST" action="<?php echo e(route('password.update')); ?>">
                      
                            <?php echo csrf_field(); ?>
                              <input type="hidden" name="token" value="<?php echo e($token); ?>">

                                <h1>Reset</h1> 
                                <p> 
                                    <label for="username" class="uname" > Your email or username </label>
                                 
                                     <input id="email" type="email" class="uname form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e($email ?? old('email')); ?>" placeholder="myusername or mymail@mail.com" required autofocus>

                                    <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>


                                </p>
                                <p> 
                                    <label for="password" class="youpasswd"> Your password </label>
                                  
   
                                    <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" placeholder="eg. X8df!90EO" name="password" required>

                                    <?php if($errors->has('password')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?> 
                                   
                                </p>


                                <p> 
                                    <label for="password" class="youpasswd"> Confirm password </label>
                                  
                                     <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                                   
                                </p>

                                 <p class="signin"> 
                                   <button type="submit" class="btn btn-success">
                                    <?php echo e(__('Reset Password')); ?>

                                   </button>

                               
                                </p>

                                 <p class="change_link">
                                    <a class="btn btn-link" href="<?php echo e(route('login')); ?>">
                                        <?php echo e(__('Back')); ?>

                                    </a> 
                                <a href="#toregister" class="to_register">Join us</a>
                                </p> 

                                

                               
                            </form>
                        </div>


                    </div>
                </div>  
            </section>








</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>