<?php
use Illuminate\Support\Facades\Auth;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


// Route::get('/demopage', 'HomeController@demopage');

// 1) Auth Routes

   Auth::routes();

// 2) / Routes with back 

Route::get('/', function () {

    if ((Auth::user()) && (Auth::user()->role_id == '1' || Auth::user()->role_id == '2'  || Auth::user()->role_id == '3') ) {
       return redirect('/home');
    } else {

        return redirect('login');
    }
});

// 3) define redirect to login controller means after login redirect that routing  

Route::get('/home', 'HomeController@index')->name('home');


/* 4) ==============================
  =========ADMIN ROUTES ========
  ============================== */



// //after login route define in login contrller redirect;

Route::group(['prefix' => 'admin','middleware' => 'auth'], function () {
    Route::get('/', function(){

        return redirect('login');
    });
    Route::resource('admin/roles', 'Admin\\RolesController');
});



/* 5) ============LOGOUT ==================*/
Route::get('/logout', '\App\Http\Controllers\Auth\LoginController@logout');

