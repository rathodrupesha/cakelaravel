<!-- master.blade.php --> 
<!DOCTYPE html> 
<html lang="en"> 
<head> 
    <meta charset="UTF-8" /> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/> 
    <meta http-equiv="X-UA-Compatible" content="ie=edge"> 
        <title>@yield('title')</title> 
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); 
        function hideURLbar(){ window.scrollTo(0,1); } </script> 
   @include('layouts.partial.stylesheet') 
</head> 
<body class="hold-transition skin-blue sidebar-mini"> 
    <div class="wrapper">  
        @include('layouts.partial.header') 
        @include('layouts.partial.sidebar')            
        @yield('contents') 
        @include('layouts.partial.footer')            
    </div> 
   @include('layouts.partial.script')                     
</body> 
</html>


