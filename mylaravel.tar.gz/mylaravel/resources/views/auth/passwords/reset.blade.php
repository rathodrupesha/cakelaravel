@extends('layouts.app')

@section('content')
<div class="container">



<!-- ORIGNAL -->

<!--     <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Reset Password') }}</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('password.update') }}">
                        @csrf

                        <input type="hidden" name="token" value="{{ $token }}">

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ $email ?? old('email') }}" required autofocus>

                                @if ($errors->has('email'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right">{{ __('Password') }}</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" required>

                                @if ($errors->has('password'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right">{{ __('Confirm Password') }}</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Reset Password') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div> -->




   <header>
     <h1>Reset Password</h1>          
  </header>


   <section>               
                <div id="container_demo" >
                  
                    <a class="hiddenanchor" id="toregister"></a>
                    <a class="hiddenanchor" id="tologin"></a>
                    <div id="wrapper">
                        <div id="login" class="animate form">
                          <form method="POST" action="{{ route('password.update') }}">
                      
                            @csrf
                              <input type="hidden" name="token" value="{{ $token }}">

                                <h1>Reset</h1> 
                                <p> 
                                    <label for="username" class="uname" > Your email or username </label>
                                 
                                     <input id="email" type="email" class="uname form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ $email ?? old('email') }}" placeholder="myusername or mymail@mail.com" required autofocus>

                                    @if ($errors->has('email'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('email') }}</strong>
                                        </span>
                                    @endif


                                </p>
                                <p> 
                                    <label for="password" class="youpasswd"> Your password </label>
                                  
   
                                    <input id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" placeholder="eg. X8df!90EO" name="password" required>

                                    @if ($errors->has('password'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('password') }}</strong>
                                        </span>
                                    @endif 
                                   
                                </p>


                                <p> 
                                    <label for="password" class="youpasswd"> Confirm password </label>
                                  
                                     <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                                   
                                </p>

                                 <p class="signin"> 
                                   <button type="submit" class="btn btn-success">
                                    {{ __('Reset Password') }}
                                   </button>

                               
                                </p>

                                 <p class="change_link">
                                    <a class="btn btn-link" href="{{ route('login') }}">
                                        {{ __('Back') }}
                                    </a> 
                                <a href="#toregister" class="to_register">Join us</a>
                                </p> 

                                

                               
                            </form>
                        </div>


                    </div>
                </div>  
            </section>








</div>
@endsection
