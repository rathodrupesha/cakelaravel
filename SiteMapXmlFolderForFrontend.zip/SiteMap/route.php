/* Site Map start*/

Route::get('sitemap.{_format}', 'Frontend\SitemapController@sitemap')->name('sitemap')->where('_format', '(xml)');
Route::get('sitemap/static-sitemap.xml', 'Frontend\SitemapController@sitemapStatic')->name('sitemapStatic');
Route::get('sitemap/category.xml', 'Frontend\SitemapController@sitemapCategory')->name('sitemapCategory');
Route::get('sitemap/advertiser.xml', 'Frontend\SitemapController@sitemapAdvertiser')->name('sitemapAdvertiser');
Route::get('sitemap/{category}/sitemap.xml', 'Frontend\SitemapController@categoryWiseAdvertisers')->name('sitemapCategoryAdvertisers');
Route::get('sitemap/blog-sitemap.xml', 'Frontend\SitemapController@sitemapBlog')->name('sitemapBlog');

Route::get('sitemap/allcategories.xml', 'Frontend\SitemapController@sitemapAllCategories')->name('sitemapAllCategories');

Route::get('sitemap/blogs.xml', 'Frontend\SitemapController@sitemapAllBlogs')->name('sitemapAllBlog');


/* Site Map end*/