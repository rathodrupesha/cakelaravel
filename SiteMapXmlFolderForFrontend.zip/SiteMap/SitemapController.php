<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Helpers\CommonTrait;
use DB;

class SitemapController extends BaseController
{
    // use CommonTrait;

    public function dateForSitemap($date = '')
    {
        if ($date == '') {
            $date = date('Y-m-d H:i:s');
        }
        return gmdate('Y-m-d\TH:i:s+00:00', strtotime($date));
    }
    /* Get Main pages */
    public function sitemap(Request $request)
    {
        $urls = array();
        $hostname = url('/');
        $gmtlastMod = $this->dateForSitemap(date('Y-m-d H:i:s'));
        // $gmtlastMod = date('Y-m-d H:i:s');
        // $urls[] = array('loc' => route('sitemapStatic'), 'lastmod' => $gmtlastMod);
        // $urls[] = array('loc' => route('sitemapCategory'), 'lastmod' => $gmtlastMod);
        // $urls[] = array('loc' => route('sitemapBlog'), 'lastmod' => $gmtlastMod);
        // $urls[] = array('loc' => route('sitemapVideo'), 'lastmod' => $gmtlastMod);

        $urls[] = array('loc' => route('sitemapStatic'), 'lastmod' => $gmtlastMod);
        $urls[] = array('loc' => route('sitemapCategory'), 'lastmod' => $gmtlastMod);
        $urls[] = array('loc' => route('sitemapAdvertiser'), 'lastmod' => $gmtlastMod);
        $urls[] = array('loc' => route('sitemapAllCategories'), 'lastmod' => $gmtlastMod);
        $urls[] = array('loc' => route('sitemapAllBlog'), 'lastmod' => $gmtlastMod);


        // $totalUser = $this->countTotalUser();
        $totalUser ='';


        if ($totalUser) {
            $perSitemap = env('USER_PER_SITEMAP_SHOW_LIMIT') ? env('USER_PER_SITEMAP_SHOW_LIMIT') : 40000;
            $totalUserSitemap = ceil($totalUser / $perSitemap);
            for ($i=1 ;$i<=$totalUserSitemap; $i++) {
                $urls[] = array('loc' => route('sitemapUser', $i), 'lastmod' => $gmtlastMod);
            }
        } else {
            //$urls[] = array('loc' => route('sitemapUser', 1), 'lastmod' => $gmtlastMod);
        }
        // echo "<pre>";
        // print_r($urls);
        // exit;
        return response()->view('frontend.sitemap.commonsitemap', compact('urls'))->header('Content-Type', 'text/xml');
    }

    /* Get all statis pages */
    public function sitemapStatic(Request $request)
    {
        $urls = array();
        $hostname = url('/');
        // $gmtlastMod = date('Y-m-d H:i:s');
        $gmtlastMod = $this->dateForSitemap(date('Y-m-d H:i:s'));

        $urls[] = array('loc' =>url(), 'changefreq' => 'daily', 'priority' => '1.0','lastmod'=>$gmtlastMod);
        $urls[] = array('loc' =>url().'/how-it-works', 'changefreq' => 'daily', 'priority' => '1.0','lastmod'=>$gmtlastMod);
        $urls[] = array('loc' => url().'/t&c', 'changefreq' => 'daily', 'priority' => '1.0','lastmod'=>$gmtlastMod);
        $urls[] = array('loc' => url().'/about', 'changefreq' => 'daily', 'priority' => '1.0','lastmod'=>$gmtlastMod);
        $urls[] = array('loc' =>url().'/contact', 'changefreq' => 'daily', 'priority' => '1.0','lastmod'=>$gmtlastMod);
        $urls[] = array('loc' => url().'/faq', 'changefreq' => 'daily', 'priority' => '1.0','lastmod'=>$gmtlastMod);
        $urls[] = array('loc' => url().'/payment', 'changefreq' => 'daily', 'priority' => '1.0','lastmod'=>$gmtlastMod);
        $urls[] = array('loc' => url().'/chrome-extension', 'changefreq' => 'daily', 'priority' => '1.0','lastmod'=>$gmtlastMod);
        $urls[] = array('loc' => url().'/blog', 'changefreq' => 'daily', 'priority' => '1.0','lastmod'=>$gmtlastMod);

        $urls[] = array('loc' => url().'/login', 'changefreq' => 'daily', 'priority' => '1.0','lastmod'=>$gmtlastMod);
        $urls[] = array('loc' => url().'/signup', 'changefreq' => 'daily', 'priority' => '1.0','lastmod'=>$gmtlastMod);
        $urls[] = array('loc' => url().'/forgot-password', 'changefreq' => 'daily', 'priority' => '1.0','lastmod'=>$gmtlastMod);


        return response()->view('frontend.sitemap.sitemap', compact('urls'))
                ->header('Content-Type', 'text/xml');
    }

    /* Show all category list*/
    public function sitemapCategory(Request $request)
    {
        $urls = array();
        $hostname = url('/');
        $gmtlastMod = $this->dateForSitemap(date('Y-m-d H:i:s'));
        // $gmtlastMod = date('Y-m-d H:i:s');
        $objCategory = DB::table('vendorcategories')
                     ->select(DB::raw('slug,name'))
                     ->where('status', 1)
                     ->get();

        foreach ($objCategory as $category) {
            $urls[] = array('loc' => route('sitemapCategoryAdvertisers', [$category->slug]), 'changefreq' => 'daily', 'priority' => '0.9','lastmod'=>$gmtlastMod);
        }

        return response()->view('frontend.sitemap.sitemap', compact('urls'))
                ->header('Content-Type', 'text/xml');
    }

    /* Show all video's list*/
    public function sitemapAdvertiser(Request $request)
    {
        $urls = array();
        $hostname = url('/');

        $urls = $this->getAdvtiser();

        return response()->view('frontend.sitemap.sitemap', compact('urls'))
                ->header('Content-Type', 'text/xml');
    }

    /* Show all Advtser's under the specific category list*/
    public function categoryWiseAdvertisers(Request $request, $category)
    {
        $urls = array();
        $hostname = url('/');

        $urls = $this->getAdvtiser($category);

        return response()->view('frontend.sitemap.sitemap', compact('urls'))
                ->header('Content-Type', 'text/xml');
    }

    public function getAdvtiser($categoryId = '')
    {
        $urls = array();
        $gmtlastMod = $this->dateForSitemap(date('Y-m-d H:i:s'));
        // $gmtlastMod = date('Y-m-d H:i:s');

        // $objAdvt = DB::table('videos')
        //              ->select(DB::raw('videos.slug as videoslug'))
        //              ->where('videos.status', 'Active')
        //              ->where('videos.ispublish', 'Yes')
        //              ->where('videos.type', 'JWP');

        $objAdvt = DB::table('vendordetails')
                     ->select(DB::raw('vendordetails.advertisername_slug as advtslug'))
                     ->where('vendordetails.status', 1)
                     ->where('vendordetails.is_frontside_show', 'Y')
                     ->where('vendordetails.is_deleted', 0);

        if (!empty($categoryId) && $categoryId != '') {
            $objAdvt = $objAdvt->leftJoin('vendorcategories', 'vendorcategories.id', '=', 'vendordetails.vendorcategories_id')
                    ->where('vendorcategories.slug', $categoryId)
                    ->get();
        } else {
            $objAdvt = $objAdvt->get();
        }


        if ($objAdvt) {
            foreach ($objAdvt as $advt) {
                $urls[] = array('loc' => route('GetStoryDetails', [$advt->advtslug]), 'changefreq' => 'daily', 'priority' => '0.8','lastmod'=>$gmtlastMod);
                // $urls[] = array('loc' =>'', 'changefreq' => 'daily', 'priority' => '1.0','lastmod'=>$gmtlastMod);
            }
        }
        return $urls;
    }

    /* Show all blog's list*/
    public function sitemapBlog(Request $request)
    {
        $urls = array();
        $hostname = url('/');
        $gmtlastMod = $this->dateForSitemap(date('Y-m-d H:i:s'));
        // $gmtlastMod = date('Y-m-d H:i:s');
        $objBlogs = DB::table('blog')
                     ->select(DB::raw('slug'))
                     ->where('status', 'Active')
                     ->get();

        foreach ($objBlogs as $blog) {
            $urls[] = array('loc' => route('blogDetails', [$blog->slug]), 'changefreq' => 'daily', 'priority' => '1.0','lastmod'=>$gmtlastMod);
        }

        return response()->view('Frontend.sitemap.sitemap', compact('urls'))
                ->header('Content-Type', 'text/xml');
    }

    /* Show all user's list*/
    public function sitemapUser(Request $request, $page)
    {
        $limit = env('USER_PER_SITEMAP_SHOW_LIMIT') ? env('USER_PER_SITEMAP_SHOW_LIMIT') : 40000;

        $offset = 0;
        if ($page > 1) {
            $offset = $limit * ($page - 1) ;
        }
        if (!is_numeric($page)) {
            return redirect()->route("sitemap", 'xml');
        }

        $urls = array();
        $hostname = url('/');
        $gmtlastMod = $this->dateForSitemap(date('Y-m-d H:i:s'));
        $objUsers = DB::table('users')
                     ->select(DB::raw('username'))
                     ->where('status', 'Active')
                     ->where('role', 'USER')
                     ->where('user_type', 'User')
                     ->offset($offset)
                     ->limit($limit)
                     ->get();
        foreach ($objUsers as $user) {
            $urls[] = array('loc' => route('visitor.users.list', [$user->username]), 'changefreq' => 'daily', 'priority' => '1.0','lastmod'=>$gmtlastMod);
        }

        return response()->view('sitemap.sitemap', compact('urls'))
                ->header('Content-Type', 'text/xml');
    }

    public function countTotalUser()
    {
        $totalUser = DB::table('users')
                     ->where('status', 'Active')
                     ->where('role', 'USER')
                     ->where('user_type', 'User')
                     ->count();
        return $totalUser;
    }



    /* Show all blog's list*/
    public function videoDetails($advtslug)
    {
        $urls = array();
        $hostname = url('/');
        $gmtlastMod = $this->dateForSitemap(date('Y-m-d H:i:s'));
        // $gmtlastMod = date('Y-m-d H:i:s');

        $objAdvt = DB::table('vendordetails')
                     ->select(DB::raw('vendordetails.advertisername_slug as advtslug'))
                     ->where('vendordetails.status', 1)
                     ->where('vendordetails.is_frontside_show', 'Y')
                     ->where('vendordetails.is_deleted', 0);

        foreach ($objAdvt as $advt) {
            $urls[] = array('loc' => url()."/cashback/".$advtslug, 'changefreq' => 'daily', 'priority' => '1.0','lastmod'=>$gmtlastMod);
        }

        return response()->view('Frontend.sitemap.sitemap', compact('urls'))
                ->header('Content-Type', 'text/xml');
    }

    /* Show all category list*/
    public function sitemapAllCategories(Request $request)
    {
        $urls = array();
        $hostname = url('/');
        $gmtlastMod = $this->dateForSitemap(date('Y-m-d H:i:s'));
        // $gmtlastMod = date('Y-m-d H:i:s');
        $objCategory = DB::table('vendorcategories')
                     ->select(DB::raw('slug,name'))
                     ->where('status', 1)
                     ->get();

        foreach ($objCategory as $category) {
            $urls[] = array('loc' => url().'/category/'.$category->slug, 'changefreq' => 'daily', 'priority' => '0.9','lastmod'=>$gmtlastMod);
        }

        return response()->view('frontend.sitemap.sitemap', compact('urls'))
                ->header('Content-Type', 'text/xml');
    }

    /* Show all category list*/
    public function sitemapAllBlogs(Request $request)
    {
        $urls = array();
        $hostname = url('/');
        $gmtlastMod = $this->dateForSitemap(date('Y-m-d H:i:s'));
        // $gmtlastMod = date('Y-m-d H:i:s');
        $objCategory = DB::table('vendorcategories')
                     ->select(DB::raw('slug,name'))
                     ->where('status', 1)
                     ->get();
        $blogArray=[
            'welcome-to-checkout-saver',
            'how-to-make-banks-pay-you',
            'A-Browser-Extension-that-Destroys-Shopping-Cart-Prices-in-Three-Ways',
            'sell-your-coupons-for-cash',
            'how-to-make-money-with-credit-cards',
            'sell-gift-cards-for-top-dollar',
            'what-are-one-time-coupons-aka-stop-throwing-away-coupons-and-sell-them',
            'top-money-saving-hacks',
            'use-discount-gift-cards-to-save-money',
            'announcing-auto-gift-cards',
            'a-mistake-ill-never-repeat-how-to-get-ready-for-opportunities',
            'how-to-generate-passive-income-with-your-blog',
            '4-ways-to-save-money-after-the-holidays',
            'gratitude-mindset-and-money',
            'how-you-can-build-an-emergency-fund-on-a-budget',
            'the-difference-between-charge-cards-credit-cards-and-debit-cards',
            'tips-to-save-money-for-college',
            'how-to-check-your-credit-score-for-free'
           ];
        foreach ($blogArray as $blogName) {
            $urls[] = array('loc' => url().'/blog/'.$blogName, 'changefreq' => 'daily', 'priority' => '0.7','lastmod'=>$gmtlastMod);
        }

        return response()->view('frontend.sitemap.sitemap', compact('urls'))
                ->header('Content-Type', 'text/xml');
    }
}
