import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';
import { UsersComponent } from './admin/users/users.component';
import { ManagersComponent } from './admin/managers/managers.component';
import { DashboardComponent } from './admin/dashboard/dashboard.component';



const routes: Routes = [
 
  {
    path: 'dashboard',
    component: DashboardComponent
  },


  {
    path: 'users',
    component: UsersComponent
  },

  {	
    path: 'managers',
    component: ManagersComponent
  },

];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
