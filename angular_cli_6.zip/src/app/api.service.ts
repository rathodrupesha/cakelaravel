import { Injectable } from '@angular/core';
import { HttpClient} from  '@angular/common/http';

import { HttpHeaders } from '@angular/common/http'; 

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  API_URL ='https://jsonplaceholder.typicode.com';  // Global variable  if use like ths.API_URL

  httpHeaders = new HttpHeaders({
     'Content-Type' : 'application/json',
     'Cache-Control': 'no-cache',
     'token':'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyIkX18iOnsic3RyaWN0TW9kZSI6dHJ1ZSwiZ2V0dGVycyI6e30sIndhc1BvcHVsYXRlZCI6ZmFsc2UsImFjdGl2ZVBhdGhzIjp7InBhdGhzIjp7InJlZ2lzdHJhdGlvbkZvcm1OYW1lIjoiaW5pdCIsInN0YWdlIjoiZGVmYXVsdCIsInN0YWdlUmVvcmRlciI6ImRlZmF1bHQiLCJxdWVzdGlvbnMiOiJkZWZhdWx0IiwidXNlck5hbWUiOiJpbml0IiwicGFzc3dvcmQiOiJpbml0IiwiZW1haWwiOiJpbml0IiwiX2lkIjoiaW5pdCJ9LCJzdGF0ZXMiOnsiaWdub3JlIjp7fSwiZGVmYXVsdCI6eyJzdGFnZSI6dHJ1ZSwic3RhZ2VSZW9yZGVyIjp0cnVlLCJxdWVzdGlvbnMiOnRydWV9LCJpbml0Ijp7InJlZ2lzdHJhdGlvbkZvcm1OYW1lIjp0cnVlLCJ1c2VyTmFtZSI6dHJ1ZSwicGFzc3dvcmQiOnRydWUsImVtYWlsIjp0cnVlLCJfaWQiOnRydWV9LCJtb2RpZnkiOnt9LCJyZXF1aXJlIjp7fX0sInN0YXRlTmFtZXMiOlsicmVxdWlyZSIsIm1vZGlmeSIsImluaXQiLCJkZWZhdWx0IiwiaWdub3JlIl19LCJlbWl0dGVyIjp7Il9ldmVudHMiOnsic2F2ZSI6W251bGwsbnVsbCxudWxsLG51bGwsbnVsbF0sImlzTmV3IjpbbnVsbCxudWxsLG51bGwsbnVsbCxudWxsXX0sIl9ldmVudHNDb3VudCI6MiwiX21heExpc3RlbmVycyI6MH19LCJpc05ldyI6ZmFsc2UsIl9kb2MiOnsicmVnaXN0cmF0aW9uRm9ybU5hbWUiOlt7ImZvcm1JRCI6IjViNTVjN2ZjYWYxM2RjOTk0NjY2NmZlMSIsImZvcm1OYW1lIjoicmFzaG0ifSx7ImZvcm1JRCI6IjViNTVjODAzYWYxM2RjOTk0NjY2NmZlMiIsImZvcm1OYW1lIjoidmlzaGFsMTIzIn0seyJmb3JtSUQiOiI1YjViMjFkOGEwYTQ2NWJiMzM1NTJjY2YiLCJmb3JtTmFtZSI6ImphZ2Rpc2g1NSJ9XSwic3RhZ2UiOltdLCJzdGFnZVJlb3JkZXIiOltdLCJxdWVzdGlvbnMiOltdLCJwYXltZW50c19jdXJyZW5jeSI6e30sIkRpc2NvdW50Q29kZSI6e30sInRpY2tldF9UeXBlIjp7fSwidXNlck5hbWUiOiJBZG1pbiIsInBhc3N3b3JkIjoiJDJhJDA4JGg3UDA3ME5mbkxsVG8zR25TL2h4a3U2S0tHMVIuQ0pPcmUudThLRjdrTm9mNUN1bmJ0emxhIiwiZW1haWwiOiJhZG1pbkBhbGxpbnRoZWxvb3AubmV0IiwiX2lkIjoiNWIzY2ExNmVlOTNjNDU1ZTA5YzkzYTRjIn0sIl9wcmVzIjp7IiRfX29yaWdpbmFsX3NhdmUiOltudWxsLG51bGxdLCIkX19vcmlnaW5hbF9yZW1vdmUiOltudWxsXX0sIl9wb3N0cyI6eyIkX19vcmlnaW5hbF9zYXZlIjpbXSwiJF9fb3JpZ2luYWxfcmVtb3ZlIjpbXX0sImlhdCI6MTUzMjk0MjgzNH0.CdZkrnhRQmBealrRepFKeRl7IfU5uKCJBLj9R8V9eIM'
    });

  constructor(private  httpClient:  HttpClient) 
  { 

  }

  getUserDetails()
  {
  	//GET
    return  this.httpClient.get(`${this.API_URL}/posts`);
  }

 
   saveUserDetails()
  {
    return  this.httpClient.post(`${this.API_URL}/posts`,{'userID':2,'name':'test'});
  }

  
  getDataOfNodeApi(){

    let options = {                           // NOT Global variable  so we use let like var
              headers:this.httpHeaders
       };

   let postparam={'key':'value'}; 

    //POST WITH HEADER 
   //return this.httpClient.get('http://180.211.96.229/api/getRegistrationFormList',postparam,options);

   //GET WITH HEADER

   return this.httpClient.get('http://180.211.96.229/api/getRegistrationFormList',options);

  }



}//end of class
