import { Component, OnInit } from '@angular/core';

/* import api service for make their object & call their  function */
import { ApiService } from  '../../api.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

 private  users:  Array<object> = [];  //getting response in data & data's array object given to this.users

 private myresponse:  Array<object> = [];

 abc="List  All";   // use in users.component.html like {{abc}}


  constructor(private  apiService:  ApiService) 
  { 

  }

  ngOnInit() 
  {
      this.getAllUsers();
  }

  public  getAllUsers()
  {
    this.apiService.getUserDetails().subscribe((data:  Array<object>) => {
        this.users  =  data;
        console.log(data);
    });
  }


   public clickMe()
  {
  	
    this.apiService.getDataOfNodeApi().subscribe((data:  Array<object>) => {
        this.myresponse  =  data;
        console.log(data);
    });
  }



}
