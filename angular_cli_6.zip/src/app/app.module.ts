import { BrowserModule } from '@angular/platform-browser';

import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';


import {AppRoutingModule} from  './app-routing.module';

import { MaterialModule } from './material/material.module';
import { BrowserAnimationsModule } 
       from '@angular/platform-browser/animations';

import { HeaderComponent } from './layout/header/header.component';
import { FooterComponent } from './layout/footer/footer.component';
import { SidebarComponent } from './layout/sidebar/sidebar.component';
import { UsersComponent } from './admin/users/users.component';
import { ManagersComponent } from './admin/managers/managers.component';
import { DashboardComponent } from './admin/dashboard/dashboard.component';

/* for Rest api HttpClientModule import*/
import { HttpClientModule } from  '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent, 
    HeaderComponent,
    FooterComponent,
    SidebarComponent,
    UsersComponent,
    ManagersComponent,
    DashboardComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    MaterialModule,
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
