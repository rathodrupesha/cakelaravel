<?php


require_once("config.php");

class master{

public $con;
function __construct()
{
	$this->con = new PDO(DSN,USERNAME,PASSWORD);
  $this->con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);	
}

function get_statedata()
{ 
   $stmt = $this->con->prepare("select * from states");
   $stmt->execute();
   $result=$stmt->fetchAll();
   return $result;
}


function get_centerdata($state_id)
{ 
  	
   $stmt = $this->con->prepare("select  service_centers.id,service_centers.state_id,service_centers.up_image,service_centers.center_name,service_centers.contact_person,service_centers.address,service_centers.number,service_centers.status,service_centers.isDeleted,service_centers.created,service_centers.modified,states.state_name from service_centers join states on service_centers.state_id=states.id where service_centers.state_id='".$state_id."'");
   $stmt->execute();
   $result=$stmt->fetchAll();
   return $result;
}


function add_centerdata($up_image,$center_name,$contact_person_name,$address,$state_name,$phone_no)
{ 
  
  $stmt = $this->con->prepare("INSERT INTO service_centers (state_id,up_image,center_name,contact_person,address,number)
    VALUES (:state_name,:up_image, :center_name, :contact_person_name,:address,:phone_no)");
  $stmt->bindParam(':state_name', $state_name);
  $stmt->bindParam(':up_image', $up_image);
  $stmt->bindParam(':center_name', $center_name);
  $stmt->bindParam(':contact_person_name', $contact_person_name);
  $stmt->bindParam(':address', $address);
  $stmt->bindParam(':phone_no', $phone_no);
  $stmt->execute();
  return true;
}


function add_userdata($first_name,$last_name,$useraddress,$email,$password,$contact_no)
{ 
  
  $stmt = $this->con->prepare("INSERT INTO users (firstname,lastname,user_address,email,password,contactno,created)
    VALUES (:first_name,:last_name, :useraddress, :email,:password,:contact_no,NOW())");
  $stmt->bindParam(':first_name', $first_name);
  $stmt->bindParam(':last_name', $last_name);
  $stmt->bindParam(':useraddress', $useraddress);
  $stmt->bindParam(':email', $email);
  $stmt->bindParam(':password', $password);
  $stmt->bindParam(':contact_no', $contact_no);
  $stmt->execute();
  return true;
}


function login_user($email,$password)
{ 
   $stmt = $this->con->prepare("select id,email,password from users where email='".$email."' and password='".$password."'");
   $stmt->execute();
   $result=$stmt->fetchAll();
  
   if(count($result)>0)
   {
     
     return $result;

   }
   else
   {
    
   	 return false;
   }
}


function check_login($user_id)
{ 
   $stmt = $this->con->prepare("select * from users where id='".$user_id."'");
   $stmt->execute();
   $result=$stmt->fetchAll();
  
   if(count($result)>0)
   {
     
     return true;

   }
   else
   {
    
   	 return false;
   }
}

function delete_service_centerdata($service_center_id)
{ 
   $stmt = $this->con->prepare("delete from service_centers where id='".$service_center_id."'");
   $stmt->execute();
   return true;
   
}


function update_service_centerdata($service_center_id,$up_image,$center_name,$contact_person_name,$address,$phone_no)
{ 
   $stmt = $this->con->prepare("update service_centers SET up_image='".$up_image."',center_name='".$center_name."',contact_person='".$contact_person_name."',address='".$address."',number='".$phone_no."' where id='".$service_center_id."'");
   $stmt->execute();
   return true;
   
}








} // end of class


?>