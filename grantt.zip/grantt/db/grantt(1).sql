-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 22, 2017 at 10:57 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grantt`
--

-- --------------------------------------------------------

--
-- Table structure for table `inquiry`
--

CREATE TABLE `inquiry` (
  `id` int(11) NOT NULL,
  `email` text NOT NULL,
  `name` text NOT NULL,
  `comment` text NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inquiry`
--

INSERT INTO `inquiry` (`id`, `email`, `name`, `comment`, `created_date`) VALUES
(1, 'pshah3089@gmail.com', 'pankti shah', 'Very nice app. \r\n', '2016-10-03 22:52:45');

-- --------------------------------------------------------

--
-- Table structure for table `service_centers`
--

CREATE TABLE `service_centers` (
  `id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `up_image` varchar(255) NOT NULL,
  `center_name` varchar(255) NOT NULL,
  `contact_person` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service_centers`
--

INSERT INTO `service_centers` (`id`, `state_id`, `up_image`, `center_name`, `contact_person`, `address`, `number`, `status`, `isDeleted`, `created`, `modified`) VALUES
(1, 1, '1491462308130_tmp_crop_avata.jpg', 'Workstation 111', 'Ajay11', 'ahmedabad1', '9812345645', 1, 0, '2017-03-28 12:54:14', '0000-00-00 00:00:00'),
(3, 2, '1491460034553_tmp_crop_avata.jpg', 'Workstation 3', 'Jeet', 'jhansi', '9978456134', 1, 0, '2017-03-28 12:55:35', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(11) NOT NULL,
  `state_name` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `isDeleted` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `state_name`, `status`, `isDeleted`, `created`, `modified`) VALUES
(1, 'WP Kuala Lumpur', 1, 0, '2017-03-24 00:00:00', '2017-03-24 00:00:00'),
(2, 'Melaka', 1, 0, '2017-03-24 00:00:00', '2017-03-24 00:00:00'),
(3, 'Johor', 1, 0, '2017-03-24 00:00:00', '2017-03-24 00:00:00'),
(4, 'Pahang', 1, 0, '2017-03-24 00:00:00', '2017-03-24 00:00:00'),
(5, 'Perak', 1, 0, '2017-03-24 00:00:00', '2017-03-24 00:00:00'),
(6, 'Penang', 1, 0, '2017-03-24 00:00:00', '2017-03-24 00:00:00'),
(7, 'Kedah', 1, 0, '2017-03-24 00:00:00', '2017-03-24 00:00:00'),
(8, 'Perlis', 1, 0, '2017-03-24 00:00:00', '2017-03-24 00:00:00'),
(9, 'Terengganu', 1, 0, '2017-03-24 00:00:00', '2017-03-24 00:00:00'),
(10, 'Kelantan', 1, 0, '2017-03-24 00:00:00', '2017-03-24 00:00:00'),
(11, 'Selangor', 1, 0, '2017-03-24 00:00:00', '2017-03-24 00:00:00'),
(12, 'Sarawak', 1, 0, '2017-03-24 00:00:00', '2017-03-24 00:00:00'),
(13, 'Sabah', 1, 0, '2017-03-24 00:00:00', '2017-03-24 00:00:00'),
(14, 'WP Labuan', 1, 0, '2017-03-24 00:00:00', '2017-03-24 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `user_address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contactno` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `isDeleted` int(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `user_address`, `email`, `password`, `contactno`, `status`, `isDeleted`, `created`, `modified`) VALUES
(4, 'admin', 'admin', 'my address', 'test@granttdemo.com', '25d55ad283aa400af464c76d713c07ad', '89XXXXXXXX', 1, 0, '2017-03-27 04:09:03', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `inquiry`
--
ALTER TABLE `inquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_centers`
--
ALTER TABLE `service_centers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `states_id` (`state_id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `inquiry`
--
ALTER TABLE `inquiry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `service_centers`
--
ALTER TABLE `service_centers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `service_centers`
--
ALTER TABLE `service_centers`
  ADD CONSTRAINT `service_centers` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
