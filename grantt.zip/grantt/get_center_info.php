<?php

include("config.php");
include("class.php");

$master_obj=new master();

$state_id=$_POST['state_id'];
$result=$master_obj->get_centerdata($state_id);

if($result)
{
      $nwArr = array();
      foreach ($result as $k=>$row) 
      {
      	  $nwArr[$k]['id']=$row['id'];
          $nwArr[$k]['state_id']=$row['state_id'];
          $nwArr[$k]['state_name']=$row['state_name'];
          $nwArr[$k]['uploaded_image']=$row['up_image'];
          $nwArr[$k]['center']=$row['center_name'];
          $nwArr[$k]['contact_person']=$row['contact_person'];
          $nwArr[$k]['address']=$row['address'];
          $nwArr[$k]['number']=$row['number'];
          $nwArr[$k]['status']=$row['status'];
          $nwArr[$k]['isDeleted']=$row['isDeleted'];
          $nwArr[$k]['created']=$row['created'];
          $nwArr[$k]['modified']=$row['modified'];
          $nwArr[$k]['image_with_path'] = $row['up_image'] != "" ? UPLOAD_PATH."uploads/".$row['up_image'] : UPLOAD_PATH."/main/avatar.png";
      }
          $response['status'] = 1;
          $response['msg']="success";
          $response['data']=$nwArr;
}
 else
 {
   $response['status'] = 0;
   $response['error']="error occur";
  
 }
   echo json_encode($response);

 
?>