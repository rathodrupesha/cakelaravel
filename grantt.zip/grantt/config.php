<?php

define("DSN","mysql:host=localhost;dbname=grantt");
define("USERNAME","root");
define("PASSWORD","");
define("UPLOAD_PATH","http://192.168.0.133/grantt/");

// $conn = new PDO(DSN,USERNAME,PASSWORD);
// $conn = new PDO("mysql:host=localhost;dbname=grantt","root","");
// $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>