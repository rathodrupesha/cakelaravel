<?php


 include("config.php");
 include("class.php");

$master_obj=new master();

$email=$_POST['email'];
$password=md5($_POST['password']);

$result=$master_obj->login_user($email,$password);
 

 if($result==true)
 { 
 	 $nwArr = array();
      foreach ($result as $k=>$row) 
      {
            $uid=$row['id'];    
      	 /* $nwArr[$k]['id']=$row['id'];
          $nwArr[$k]['firstname']=$row['firstname'];
          $nwArr[$k]['lastname']=$row['lastname'];
          $nwArr[$k]['user_address']=$row['user_address'];
          $nwArr[$k]['email']=$row['email'];
          $nwArr[$k]['contactno']=$row['contactno'];
        */  
      }
     $response['status'] = 1;
     $response['msg']="success";
     $response['data']="Login successfully Done";
     $response['user_id']=$uid;

 }
 else
 {

    $response['status'] = 0;
    $response['msg']="error";
    $response['data']="Enter Email or Password is wrong";

 }

echo json_encode($response); 
exit();
?>