<?php


 include("config.php");
 include("class.php");

 $master_obj=new master();
//print_r($_FILES); exit();
  $user_id=$_POST['u_userid'];
  $service_center_id=$_POST['u_servicecenterid'];
 

 $up_image=$_FILES["u_upimage"]["name"];
 $center_name=$_POST['u_centername'];
 $contact_person_name=$_POST['u_contactperson_name'];
 $address=$_POST['u_address'];
 //$state_name=$_POST['state_id'];
 $phone_no=$_POST['u_phoneno'];


 $result=$master_obj->check_login($user_id);
 
 if($result==true)
 { 
     $update_true=$master_obj->update_service_centerdata($service_center_id,$up_image,$center_name,$contact_person_name,$address,$phone_no);
     if($update_true==true)
     {
       $target_dir = "uploads/";
       $target_file = $target_dir . basename($_FILES["u_upimage"]["name"]);
       $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
       
        if (move_uploaded_file($_FILES["u_upimage"]["tmp_name"], $target_file)) 
      {
        $response['file_status'] = "The file ". basename( $_FILES["up_image"]["name"]). " has been uploaded.";
       } 
       $response['status'] = 1;
       $response['msg']="success";
       $response['data']="Data updated Successfully ";
    }
 }
 else
 {

    $response['status'] = 0;
    $response['msg']="error";
    $response['data']="Data not updated ";
    $response['authorised']="You are not authorised person";

 }

echo json_encode($response); 
exit();
?>