<?php

include("config.php");
include("class.php");

$master_obj	=	new master();
$response 	= array();

$response['status'] = 0;

$result = $master_obj->get_statedata();

if($result)
{
	$nwArr = array();
    foreach ($result as $k=>$row)
    {
    	$nwArr[$k]['state_id']=$row['id'];    	
        $nwArr[$k]['state']=$row['state_name'];
    }

    $response['status'] = 1;
    $response['data'] 	= $nwArr;
    $response['msg']="success";
}
 else
 {
   $response['msg']="error occur";
  
 }
   echo json_encode($response);

 
?>