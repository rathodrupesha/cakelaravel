<?php


 include("config.php");
 include("class.php");

 $master_obj=new master();
$up_image=$_FILES["up_image"]["name"];
$center_name=$_POST['center_name'];
$contact_person_name=$_POST['contact_person_name'];
$address=$_POST['address'];
$state_name=$_POST['state_id'];
$phone_no=$_POST['phone_no'];
 

 $result=$master_obj->add_centerdata($up_image,$center_name,$contact_person_name,$address,$state_name,$phone_no);


 if($result==true)
 { 
 	
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["up_image"]["name"]);
    $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
  

   if (move_uploaded_file($_FILES["up_image"]["tmp_name"], $target_file)) 
   {
     $response['file_status'] = "The file ". basename( $_FILES["up_image"]["name"]). " has been uploaded.";
   } 
   else 
   {
     $response['file_status'] = "Sorry, there was an error uploading your file.";
   }

     $response['status'] = 1;
     $response['msg']="success";
     $response['data']="Data Inserted ";

 }
 else
 {

    $response['status'] = 0;
    $response['msg']="error";
    $response['data']="Data not Inserted ";

 }

echo json_encode($response); 
exit();
?>