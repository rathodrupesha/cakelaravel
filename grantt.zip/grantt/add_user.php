<?php


 include("config.php");
 include("class.php");

 $master_obj=new master();

$first_name=$_POST['first_name'];
$last_name=$_POST['last_name'];
$useraddress=$_POST['user_address'];
$email=$_POST['email'];
$password=md5($_POST['password']);
$contact_no=$_POST['contact_no'];

  
  
 $result=$master_obj->add_userdata($first_name,$last_name,$useraddress,$email,$password,$contact_no);


 if($result==true)
 { 
 	
     $response['status'] = 1;
     $response['msg']="success";
     $response['data']="User Created successfully ";

 }
 else
 {

    $response['status'] = 0;
    $response['msg']="error";
    $response['data']="User Not Created";

 }

echo json_encode($response); 
exit();

//http://www.discussdesk.com/restful-api-in-cakephp3-with-mysql.htm
?>