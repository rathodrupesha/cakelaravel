<?php


 include("config.php");
 include("class.php");

 $master_obj=new master();

 $user_id=$_POST['user_id'];
 $service_center_id=$_POST['service_center_id'];
 

 $result=$master_obj->check_login($user_id);
 
 if($result==true)
 { 
     $delete_true=$master_obj->delete_service_centerdata($service_center_id);
     if($delete_true==true)
     {
       $response['status'] = 1;
       $response['msg']="success";
       $response['data']="Data Deleted Successfully ";
     }
 }
 else
 {

    $response['status'] = 0;
    $response['msg']="error";
    $response['data']="Data not Deleted ";
    $response['authorised']="You are not authorised person";

 }

echo json_encode($response); 
exit();
?>