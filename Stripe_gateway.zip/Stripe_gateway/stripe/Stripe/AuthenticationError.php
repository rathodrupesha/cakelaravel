<?php

class Stripe_AuthenticationError extends Stripe_Error
{
}
