-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 23, 2019 at 07:38 AM
-- Server version: 5.6.41
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fmv_sajanshah`
--

-- --------------------------------------------------------

--
-- Table structure for table `challenge_of_the_days`
--

CREATE TABLE `challenge_of_the_days` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `challenge_of_the_days`
--

INSERT INTO `challenge_of_the_days` (`id`, `title`, `created_at`, `updated_at`) VALUES
(1, 'Read 10 Pages today.\r\n', NULL, NULL),
(2, ' Meet 3 random people today, greet them with a smile and start a random conversation.', NULL, NULL),
(3, ' Call your three friends whom you haven’t met since three years.', NULL, NULL),
(4, 'Go on a drive for 15 minutes today with your own self.', NULL, NULL),
(5, ' Use social media for 5 times today and only for 10 minutes each.', NULL, NULL),
(6, ' Give 10 seconds hug to three of your loved ones today.', NULL, NULL),
(7, 'Drink 8 glass of water today.', NULL, NULL),
(8, 'Broadcast/send your favorite motivation quote to all your friends and near and dear one’s today.', NULL, NULL),
(9, 'Watch in the mirror, see your reflection and laugh for two minutes without any reason on yourself today.', NULL, NULL),
(10, 'Dress today like it’s your birthday today, and feel the energy.', NULL, NULL),
(11, 'Offer a glass of water today to three random people.', NULL, NULL),
(12, ' Make a list of 5 strengths, put it into paper and read it three times today.(Try to do it every day)', NULL, NULL),
(13, 'Write 3 goals which you want to achieve in 2018 today. (Make it a habit to read it every morning.)', NULL, NULL),
(14, 'Take the stairs today.', NULL, NULL),
(15, 'Give complement to random 5 persons today.', NULL, NULL),
(16, 'Don’t complain just for today – Acceptance day it is! (Make it habit)', NULL, NULL),
(17, 'Take a break from your addiction today. (Make it habit)', NULL, NULL),
(18, 'Wake up 20 minutes earlier than normal today', NULL, NULL),
(19, ' Learn 3 new words today and use it at least once in your routine language today.', NULL, NULL),
(20, ' Spend 15 minutes of time today with your Family/loved ones.(Even Video Call is appreciated) ', NULL, NULL),
(21, 'Say “NO” to junk food today. Only Health Conscious Day!', NULL, NULL),
(22, 'Speak only truth or stay quiet today. ', NULL, NULL),
(23, ' Listen/read 2 stories of successful people today.', NULL, NULL),
(24, ' Pray for 5 minutes for three unconditional people today.', NULL, NULL),
(25, 'Water any random 2 plant/tree today.', NULL, NULL),
(26, 'No order day it is! Do your every work by your own way today at your home.', NULL, NULL),
(27, 'Have your lunch and dinner without your phone or TV today.', NULL, NULL),
(28, 'Donate one extra cloth to any random/needy person today.', NULL, NULL),
(29, 'List your two weaknesses today and write 2 steps to overcome from it today.', NULL, NULL),
(30, 'Visit any 2 random temple of different religion today and learn anyone beautiful learning from your visit today.', NULL, NULL),
(31, 'Write a 5 lines appreciation/gratitude letter for your loved ones/partner/family members today and give/send them before sleeping.', NULL, NULL),
(32, 'Watch a new sports for 20 minutes today which was not of your interest till today. It may be football, tennis, badminton etc. Learn one thing from that new sport today from your observation.', NULL, NULL),
(33, ' Meet 2 people who are above the age of 60 today and ask them to give you one biggest learning of their journey called life.', NULL, NULL),
(34, 'Play with any young kid today who is below 5 years and allow him to win. Observe the smile, spark, enthusiasm and Tell yourself “Let’s Live Like this – Unconditional and full of life”', NULL, NULL),
(35, 'Donate ten rupees today to the hard working needy person near you. (Watchman, liftman, servant, postman or any other hardworking needy person)', NULL, NULL),
(36, 'Play a prank today (No emotional prank just for fun prank)', NULL, NULL),
(37, '38. Take a selfie today with your loved ones/family member and post it on social media today with 3 lines of description about how lucky you are to have them. (Do Tag Them)', NULL, NULL),
(38, 'make a list of 2 new skills you have to learn in coming 6 months with the 5 action strategy on how you are going to achieve.(E.g: Language fluency, overcoming anger, managing time etc. )', NULL, NULL),
(39, 'Watch out your favorite cartoon today from youtube and just enjoy it. (Age doesn’t matter, you have to watch it)', NULL, NULL),
(40, ' Read ten minutes today about the struggling zone of your favourite actor/sportsman/business tycoon. ', NULL, NULL),
(41, ' Use one medium today in your entire day – “Public transport” (If not today, then keep it in priority of the week)', NULL, NULL),
(42, '43. Join one new social media application today (Just for fun – Snapchat, Couch surfing, Quora, pinterest)', NULL, NULL),
(43, ' Sing out loud one of your favorite song today with full feelings at any 3 random location today. ', NULL, NULL),
(44, 'Dance out like crazy for 2 minutes today with no concern or no conscious attitude.', NULL, NULL),
(45, 'Be what you are today. Be blunt with whatever you feel, speak it out without worry and feel the confidence.', NULL, NULL),
(46, 'Write about your 5 best accomplishments which you have achieved in last 5 years. (first salary, first job, gifting a treat, did something for humanity, anything which made you feel special)', NULL, NULL),
(47, 'Visit a hospital today and just observe for ten minutes how people suffer and make any one ritual for your health which you will follow atleast four days in a week', NULL, NULL),
(48, 'Cheat your meal day - Treat yourself with your favorite dish today. Enjoy Alone.', NULL, NULL),
(49, 'Give 10 minutes extra today in everything you do from your office hours to your friends time to your family time to your home work. This will generate habit of going extra mile attitude in yo', NULL, NULL),
(50, 'Give 10 minutes extra today in everything you do from your office hours to your friends time to your family time to your home work. This will generate habit of going extra mile attitude in yo', NULL, NULL),
(51, 'Watch in the mirror once you start your day and ask your “What I will do if today is the last day of my life” and before sleeping watch again the same mirror and ask yourself “Have I given my', NULL, NULL),
(52, 'Organize your desk, computer, study material, wardrobe and every other specific places where you are sitting and investing your time. Removing the clutter with give you a fresh flow of positi', NULL, NULL),
(53, 'Civic sense day it is! Don’t throw garbage/trash or any other unimportant things anywhere. If you find someone doing it, guide atleast 2 people today for civic sense.', NULL, NULL),
(54, 'Perception day it is! Take any one random situation from your day and try to see it from minimum 5 different angles. By doing this everyday you will become non judgemental.', NULL, NULL),
(55, 'introspection day it is! Write one learning which you have learnt today before you sleep in one separate book. (You can even make Personal learning book and review it 15 days)', NULL, NULL),
(56, 'Choose today finally for three months. YES! I am asking you to choose your priority. Decide top 3 priority of your life and don’t change it for three months. (Options: Career, Family, Health,', NULL, NULL),
(57, 'Confess 1 thing today to your loved ones/family members. Have courage to confess, accept and get yourself ready with 2 solution on overcoming it if required.', NULL, NULL),
(58, 'Ask for forgiveness to 2 people with whom your relations are not up to the mark because of difference of opinions. Don’t fall in fault game, fall in saving the relation game.', NULL, NULL),
(59, 'Talk with two random people of opposite gender today. Start a random conversation and talk for minimum 10 minutes.', NULL, NULL),
(60, 'Play a NEW game on your mobile or computer for minimum 25 minutes without taking a break. Observe in end your fighting spirit.', NULL, NULL),
(61, ' Wink at random 3 people without any reason. (No explanation today – Just Try the random fun portion of life)', NULL, NULL),
(62, ' Be a good listener today. Don’t Argue, Don’t justify. Just accept it with a great smile. Challenge is not to change your expression even if you are not in favor of the words which are spoken', NULL, NULL),
(63, 'Give a Hi-Fi/ firm hand shake to five people today and tell them one beautiful thing about themselves.', NULL, NULL),
(64, ' Play any random sports today for 25 minutes with your friends/colleage/any random people. Play to win not for fun.', NULL, NULL),
(65, 'Ask for a feedback from two people from your personal life and two people from professional life. Don’t Defend on feedback, Just focus on improvement.', NULL, NULL),
(66, 'Start making a list today on 100 things to do before you die. Try to reach 30 by tonight.', NULL, NULL),
(67, 'Watch a late night movie with your family/friends. Have fun and live the life.(Horror/Adventure/Action)', NULL, NULL),
(68, ' Read a news story on a subject you know nothing about  and figure out what the hell’s going on in the world outside your regular bubble.', NULL, NULL),
(69, 'Be kind to a total stranger for no reason at all, with no expectation of gratitude. It could be as simple as holding the door open for longer than etiquette dictates necessary, or keeping the elevator doors from closing on someone as they rush into the lo', NULL, NULL),
(70, 'Downsize your wardrobe by purging it of all the itmes you haven’t actually worn in the last one year. Donoate those extra clothes to charity, give them away to friends or consign it.', NULL, NULL),
(71, ' Utilize your lunch and dinner time properly. Eat slowly, Chew properly and have no disturbance while eating.', NULL, NULL),
(72, 'Meditate for five minutes, even if you have no idea what meditating entails, exactly. Just close your eyes, sit still, and try to let go. ', NULL, NULL),
(73, ' Do something alone that you’d normally ask a friend to do with you. Go to the movies, eat at table for one, or try a new exercise class all by yourself.', NULL, NULL),
(74, ' Take the long way home and use the extra time to think.', NULL, NULL),
(75, 'List down 5 toxic people of your life and Make it a target to Avoid those people for minimum 15 days from your life. ', NULL, NULL),
(76, ' Spend three minutes a day repeating a positive affirmation you’ve set yourself. E.g.: You can use his affirmation - “Day by Day in every way I am getting better and better” continuously for three minutes without a break', NULL, NULL),
(77, ' Do karma yoga (selfless service) for at least 15 mins a day.', NULL, NULL),
(78, 'Plan your tomorrow.', NULL, NULL),
(79, ' NEGOTIATE once a day. At a Starbucks? Ask for 10% off, for instance.', NULL, NULL),
(80, 'HUG one stranger a day. Not as easy as you think, despite the many benefits', NULL, NULL),
(81, '3. Make 2 new friends today randomly. Share your number and stay in touch with him.', NULL, NULL),
(82, ' Write a letter to your future self like how you see yourself after 2 years... write 10-15 lines, keep it safely and securely in your cupboard - (imagine how fun it will be to read the letter after 2 years)', NULL, NULL),
(83, 'Take 10 deep breaths in and out in the morning and before bed. Try to make this as a routine habit. It reduces the excess thoughts problem and makes your much more calm and peace.', NULL, NULL),
(84, 'Go to the mirror and smile at yourself the moment you get out of bed.', NULL, NULL),
(85, ' Find an encouraging quote and read it aloud every morning for the next 7 days.', NULL, NULL),
(86, 'Watch a comedian perform standup or film that makes you laugh so hard that your stomach hurts.', NULL, NULL),
(87, 'Lay down in silence for 5 minutes. Tune out anything stressing you out and meditate on the good things in your life', NULL, NULL),
(88, 'Have one difficult conversation today face to face instead of email/text/phone.', NULL, NULL),
(89, ' Start fake laughing and see how little time goes by before you’re actually cracking up. Works every time.', NULL, NULL),
(90, 'Call your mom or dad and ask them lots of questions. Force yourself to stay on the phone longer than usual chatting about the stuff that’s important to them. ', NULL, NULL),
(91, 'Set your alarm for fifteen minutes earlier than usual and use the extra time to slow down the following morning. ', NULL, NULL),
(92, ' Downsize your wardrobe by purging it of all the items you haven’t actually worn in the last two years. Donate those extra clothes to charity, give them away to friends, or consign them. ', NULL, NULL),
(93, ' Reach out to an old friend directly with thoughtful questions about what they’re up to instead of combing through their social feeds to get the catch-up fix you crave. ', NULL, NULL),
(94, 'Set aside some time to cross every lingering item off your To Do list so you can start the next day fresh. ', NULL, NULL),
(95, ' Start a gratitude diary and every evening before going to sleep jot down three things you are thankful for. ', NULL, NULL),
(96, 'Practice good posture\r\nEvery day, whenever you remember, sit up straight. Stand up taller.', NULL, NULL),
(97, 'Practice good posture\r\nEvery day, whenever you remember, sit up straight. Stand up taller.', NULL, NULL),
(98, ' Listen to music for the mood you want to be in, instead of the mood you’re already in.', NULL, NULL),
(99, 'Say thank you –  a lot – to the bus driver, the barista, the grocery store cashiers etc. Everyone works hard and would love to hear that you appreciate it.', NULL, NULL),
(100, ' Suggest one inspiring book to someone.', NULL, NULL),
(101, 'Stop to talk to a homeless person.', NULL, NULL),
(102, 'Take photo of thing that make you smile today.', NULL, NULL),
(103, ' First finish important work of the day and focus on one task at a time. Complete each task in perfect manner.', NULL, NULL),
(104, 'Compete against people better than you in any area like sports, gaming, and work productivity. Do healthy competition.', NULL, NULL),
(105, ' Ask, don’t tell. Kill people with kindness and generosity and they will gladly assist you in any work.', NULL, NULL),
(106, ' Play brain storming games like chess, puzzle, Sudoku, rubick’s cube.', NULL, NULL),
(107, ' Write 2 things which you want to stop doing.', NULL, NULL),
(108, 'speak only in assertive manner.', NULL, NULL),
(109, ' Take 15 minutes walk after your meal', NULL, NULL),
(110, ' Don’t compare yourself with anyone today. Be you!', NULL, NULL),
(111, 'Minimize the use of water, electricity, fuel, paper or anything which is in limited source.', NULL, NULL),
(112, 'Watch classic movie from the year you were born.', NULL, NULL),
(113, 'Visualize your perfect day and write 5 actions to achieve that.', NULL, NULL),
(114, 'Speak whenever is necessary until maintain silence. Be quite for today.', NULL, NULL),
(115, 'Read to the kids and elder one.', NULL, NULL),
(116, ' Monitor your whole day and find out where you are spending your time unnecessarily. ', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `challenge_status`
--

CREATE TABLE `challenge_status` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `challenge_id` int(11) NOT NULL,
  `status` int(11) NOT NULL COMMENT '1=success,0=failed',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `challenge_status`
--

INSERT INTO `challenge_status` (`id`, `user_id`, `challenge_id`, `status`, `created_at`, `updated_at`) VALUES
(103, 21, 17, 1, '2018-07-10 09:53:52', '2018-07-10 09:53:52'),
(104, 21, 17, 1, '2018-07-10 09:53:54', '2018-07-10 09:53:54'),
(105, 21, 17, 1, '2018-07-10 09:53:54', '2018-07-10 09:53:54'),
(106, 21, 17, 1, '2018-07-10 09:53:54', '2018-07-10 09:53:54'),
(107, 21, 17, 1, '2018-07-10 09:53:54', '2018-07-10 09:53:54'),
(108, 21, 17, 1, '2018-07-10 09:53:55', '2018-07-10 09:53:55'),
(109, 21, 17, 1, '2018-07-10 09:53:55', '2018-07-10 09:53:55'),
(110, 21, 17, 1, '2018-07-10 09:53:55', '2018-07-10 09:53:55'),
(111, 21, 17, 1, '2018-07-10 09:53:55', '2018-07-10 09:53:55'),
(112, 21, 17, 1, '2018-07-10 09:53:55', '2018-07-10 09:53:55'),
(113, 21, 17, 1, '2018-07-10 09:53:55', '2018-07-10 09:53:55'),
(114, 21, 17, 0, '2018-07-10 09:53:56', '2018-07-10 09:53:56'),
(115, 21, 17, 0, '2018-07-10 09:53:56', '2018-07-10 09:53:56'),
(116, 21, 17, 1, '2018-07-10 09:53:57', '2018-07-10 09:53:57'),
(117, 21, 17, 1, '2018-07-10 09:53:57', '2018-07-10 09:53:57'),
(118, 21, 17, 0, '2018-07-10 09:53:57', '2018-07-10 09:53:57'),
(119, 21, 17, 0, '2018-07-10 09:53:57', '2018-07-10 09:53:57'),
(120, 21, 17, 1, '2018-07-10 09:53:57', '2018-07-10 09:53:57'),
(121, 21, 17, 0, '2018-07-10 09:53:57', '2018-07-10 09:53:57'),
(122, 21, 17, 0, '2018-07-10 09:53:57', '2018-07-10 09:53:57'),
(123, 21, 17, 0, '2018-07-10 09:53:58', '2018-07-10 09:53:58'),
(124, 21, 17, 0, '2018-07-10 09:53:58', '2018-07-10 09:53:58'),
(125, 21, 17, 0, '2018-07-10 09:53:58', '2018-07-10 09:53:58'),
(126, 21, 17, 0, '2018-07-10 09:53:58', '2018-07-10 09:53:58'),
(127, 21, 17, 0, '2018-07-10 09:53:59', '2018-07-10 09:53:59'),
(128, 21, 17, 0, '2018-07-10 09:53:59', '2018-07-10 09:53:59'),
(129, 21, 17, 0, '2018-07-10 09:53:59', '2018-07-10 09:53:59'),
(130, 21, 17, 0, '2018-07-10 09:54:00', '2018-07-10 09:54:00'),
(131, 21, 17, 0, '2018-07-10 09:54:00', '2018-07-10 09:54:00'),
(132, 21, 17, 0, '2018-07-10 09:54:00', '2018-07-10 09:54:00'),
(133, 21, 17, 0, '2018-07-10 09:54:01', '2018-07-10 09:54:01'),
(134, 21, 17, 0, '2018-07-10 09:54:21', '2018-07-10 09:54:21'),
(137, 24, 9, 1, '2018-07-10 10:12:53', '2018-07-10 10:12:53'),
(138, 19, 6, 1, '2018-07-10 11:22:05', '2018-07-10 11:22:05'),
(143, 18, 8, 1, '2018-07-11 21:11:41', '2018-07-11 21:11:41'),
(144, 19, 8, 1, '2018-07-12 08:49:47', '2018-07-12 08:49:47'),
(145, 18, 9, 1, '2018-07-12 20:54:55', '2018-07-12 20:54:55'),
(146, 18, 10, 1, '2018-07-13 06:44:51', '2018-07-13 06:44:51'),
(148, 18, 14, 1, '2018-07-17 20:10:17', '2018-07-17 20:10:17'),
(149, 18, 15, 1, '2018-07-18 17:15:02', '2018-07-18 17:15:02'),
(151, 25, 1, 1, '2018-09-17 16:16:34', '2018-09-17 16:16:34'),
(152, 26, 1, 1, '2018-09-18 11:39:56', '2018-09-18 11:39:56'),
(153, 26, 2, 1, '2018-09-20 08:55:50', '2018-09-20 08:55:50'),
(154, 26, 31, 1, '2018-10-19 21:12:13', '2018-10-19 21:12:13'),
(155, 26, 56, 1, '2018-11-13 15:00:06', '2018-11-13 15:00:06'),
(156, 26, 72, 1, '2018-11-29 15:22:17', '2018-11-29 15:22:17'),
(157, 29, 10, 1, '2019-01-04 11:33:31', '2019-01-04 11:33:31'),
(158, 30, 1, 1, '2019-01-04 18:26:24', '2019-01-04 18:26:24'),
(159, 25, 114, 1, '2019-01-09 10:27:24', '2019-01-09 10:27:24'),
(160, 25, 115, 1, '2019-01-10 17:05:27', '2019-01-10 17:05:27');

-- --------------------------------------------------------

--
-- Table structure for table `cms`
--

CREATE TABLE `cms` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cms`
--

INSERT INTO `cms` (`id`, `title`, `content`, `created_at`, `updated_at`) VALUES
(4, 'About Us', '<p><img alt=\"\" src=\"http://sajanshah.fmv.cc/public/images/general/about_us.png\" style=\"height:auto; width:100%\" /></p>\r\n\r\n<p>- Contact us: connect@sajanshah.com</p>\r\n\r\n<p>- HelpLine: +91-8511363376</p>\r\n\r\n<p>- Download Profile of Mr. Sajan Shah:</p>\r\n\r\n<p><a href=\"http://www.sajanshah.com/brochure.aspx\">http://www.sajanshah.com/brochure.aspx</a></p>\r\n\r\n<p>Brief About Mr. Sajan Shah</p>\r\n\r\n<p>Sajan Shah, is a young, energetic motivational speaker and transforming lives is his mission. His passion is to help people reach self-realization and create extraordinary changes in their lives so that they can unleash their hidden and dormant potential. Whether it&#39;s a 90-minute talk, a one day workshop or a one-week seminar, Sajan&#39;s electrifying speeches arrest the attention of his listeners with his strong messages and unique style.</p>\r\n\r\n<p>He has worked with over 3 million people in 9 years. He is the author of &quot;You v/s You&quot; Book. His Work has been appreciated and blessed by Vice President of India - Venkaiah Naidu, H.H Dalai Lama, H.H Acharya Dr. Lokesh muni, Chief Minister of Gujarat - Vijay Rupani, Chief Minister of Maharastra - Devendra Fadnavis, World Champion Boxer - Vijender Singh, World Tennis Champion - Roger Federer and many more leading leaders across the globe.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>Well known as :</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;- &nbsp;Memory Man of India</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;- Youngest Motivational Speaker of India</p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;- Youth Peace Ambassador of India</p>', '2018-06-12 13:00:12', '2018-07-03 15:10:56');

-- --------------------------------------------------------

--
-- Table structure for table `connectwithuses`
--

CREATE TABLE `connectwithuses` (
  `id` int(10) UNSIGNED NOT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagrame` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tweeter` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `snapchat` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `linkldn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `connectwithuses`
--

INSERT INTO `connectwithuses` (`id`, `facebook`, `instagrame`, `youtube`, `tweeter`, `snapchat`, `linkldn`, `created_at`, `updated_at`) VALUES
(1, 'https://www.facebook.com/SajanShahPage/', 'https://www.instagram.com/sajan_shahh/', 'https://www.youtube.com/channel/UC-zcxbOmTsRzSlydELA8Bag', 'https://twitter.com/sajanofficial', 'https://snapchat.com/sajanofficial', 'https://www.linkedin.com/in/sajan-shah-7840244a', '2018-06-13 21:38:00', '2018-06-14 05:05:32');

-- --------------------------------------------------------

--
-- Table structure for table `gifts`
--

CREATE TABLE `gifts` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `week` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `points` int(11) NOT NULL,
  `giftdata` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gifts`
--

INSERT INTO `gifts` (`id`, `target`, `week`, `points`, `giftdata`, `created_at`, `updated_at`) VALUES
(1, 'Taregt 1', '1st week consistency', 100, 'Get 10 Life inspiring Posters which will inspire you everytime you see it.', '2018-06-26 04:00:00', '2018-06-26 04:00:00'),
(2, 'Taregt 2', '2nd and 3rd week consistency ', 300, 'We will donate 20 books on behalf of you and will share pictures of those needy people recieving their gifts with your name because of your dedication.', '2018-06-26 04:00:00', '2018-06-26 04:00:00'),
(3, 'Taregt 3', '4th and 5th week consistency', 500, 'Get one exclusive Life Inspiring Talk of Sajan Shah specially designed only and only for you with ten life changing instant stratgies', '2018-06-25 07:00:00', '2018-06-26 04:00:00'),
(4, 'Taregt 4', '6th and 7th week consistency', 700, 'We will Feed 5 Hungry people on behalf of youwill share pictures of those needy people recieving their gifts with your name because of your dedication.', '2018-06-25 04:00:00', '2018-06-26 04:00:00'),
(5, 'Taregt 5', '8th and 9th week consistency', 900, 'Get five motivational books and specially deisgned Meditation of Sajan Shah on your this special achievements day.', '2018-06-25 07:00:00', '2018-06-26 04:00:00'),
(6, 'Taregt 6', '10th and 11th week consistency', 1100, 'FREE Entry Coupon for any one day PAID Program of Sajan Shah (Worth Rupees 15,000)', '2018-06-25 04:00:00', '2018-06-26 04:00:00'),
(7, 'Taregt 7', '11th and 12th week consistency', 1300, '10 minutes of telephoic conversation or 15 Minutes of personal meeting with Sajan Shah.', '2018-06-25 07:00:00', '2018-06-26 04:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(13, '2014_10_12_000000_create_users_table', 1),
(14, '2014_10_12_100000_create_password_resets_table', 1),
(15, '2018_05_29_101942_add_role_id_to_users_table', 1),
(16, '2018_06_13_085515_create_cms_table', 1),
(17, '2018_06_13_090203_create_quotofthedays_table', 1),
(18, '2018_06_13_090409_create_challenge_of_the_days_table', 1),
(19, '2018_06_13_091726_create_target_of_the_days_table', 1),
(20, '2018_06_13_091830_create_connectwithuses_table', 1),
(21, '2018_06_25_064101_add_user_id_to_taget_table', 1),
(22, '2018_06_25_094518_create_table_target_status', 1),
(23, '2018_06_26_061326_add_points_to_users_table', 1),
(24, '2018_06_26_064332_create_gifts_table', 2),
(25, '2018_06_27_051444_add_new_created_at_to_users_table', 3),
(27, '2018_06_27_073402_create_userclaims_table', 4),
(28, '2018_06_28_053709_add_device_id_to_users_table', 5);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `quotofthedays`
--

CREATE TABLE `quotofthedays` (
  `id` int(10) UNSIGNED NOT NULL,
  `quote` text COLLATE utf8mb4_unicode_ci,
  `author` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `quotofthedays`
--

INSERT INTO `quotofthedays` (`id`, `quote`, `author`, `created_at`, `updated_at`) VALUES
(1, 'The Difference between where you are today and where you will be five years from now will be found in the quality of books you have read.', '', '2018-06-14 02:36:08', '2018-06-14 07:11:04'),
(2, 'Don’t wish for less Problems; wish for more skills.', '', '2018-06-13 22:39:17', '2018-06-13 22:30:35'),
(3, 'You don’t get paid for the hour; you get paid for the value you bring to the hour.', '', '2018-06-14 02:37:00', '2018-06-13 22:30:11'),
(4, 'It is not the mountain we conquer, but ourselves.', '', '2018-06-14 06:00:17', '2018-06-14 07:20:48'),
(5, 'Are you scared or are you not ready? There is a difference.', NULL, NULL, NULL),
(6, ' Problems are not stop signs, they are guidelines.', NULL, NULL, NULL),
(7, 'If you chase a rabbit you will hunt it, if you chase 2 rabbits you will lose them both.  ', NULL, NULL, NULL),
(8, ' The distance between insanity and genius is measured only by success.', ' Bruce Feirstein', NULL, NULL),
(9, ' The Successful warrior is the average man, with laser-like focus.', 'Bruce Lee.', NULL, NULL),
(10, ' Quietly endure, silently suffer and patiently wait. ', 'Martin Luther King Jr.', NULL, NULL),
(11, ' It is better to wear out than rust out. ', 'Swami vivekanand', NULL, NULL),
(12, ' Trying and doing are two different things. When you try, you hope. When you do, you succeed.', NULL, NULL, NULL),
(13, ' Worrying is like paying a debt you don’t owe', ' Mark Twain', NULL, NULL),
(14, 'Chop your own wood, and it will warm you twice.', ' Henry Ford', NULL, NULL),
(15, 'Plans are nothing; planning is everything.', 'Dwight D.Eisenhower', NULL, NULL),
(16, 'The Fear we don’t face become our limitation.', NULL, NULL, NULL),
(17, 'Life’s challenges are not supposed to paralyze you; they’re supposed to help you discover who you are.', ' Bernice Johnson Reagon', NULL, NULL),
(18, 'Whenever you find whole world against you turn around and lead the world.', NULL, NULL, NULL),
(19, ' Attitudes are contagious. Make your worth catching.\r\n', NULL, NULL, NULL),
(20, 'As long as you are comfortable you are not growing.', NULL, NULL, NULL),
(21, ' Having a support network will keep you focused, motivated and inspired.\r\n', NULL, NULL, NULL),
(22, ' You have to be able to tolerate what you don’t necessarily like, so you can be free', 'Larry Flynt', NULL, NULL),
(23, ' The only thing you can get in a hurry is trouble.\r\n', 'Navjot singh Sidhu', NULL, NULL),
(24, ' Balance is another key ingredient of highly developed achiever.', NULL, NULL, NULL),
(25, ' If you do not have all that you want in life, today is the day to start the reconditioning process.\r\n ', NULL, NULL, NULL),
(26, 'Without clearly defined goals for the near future and long-term, is like a brain surgeon operating with blind fold on.', NULL, NULL, NULL),
(27, 'Through repetition of thought, the goal will become a burning desire.\r\n.', NULL, NULL, NULL),
(28, ' Confidence without humility is arrogance.', NULL, NULL, NULL),
(29, 'Make it your daily obsession to make the most of your potential.\r\n ', NULL, NULL, NULL),
(30, 'When someone tells you it can’t be done, it’s more of a reflection of their', NULL, NULL, NULL),
(31, ' Limitations, not yours.\r\n', NULL, NULL, NULL),
(32, 'If you want to fly with eagles than stop swimming with ducks.', NULL, NULL, NULL),
(33, 'Winning takes talent, to repeat takes character!\r\n ', NULL, NULL, NULL),
(34, 'Trust your gut feelings; you have it for a reason.', NULL, NULL, NULL),
(35, ' When universe is not having boundaries, why you are having it?\r\n ', NULL, NULL, NULL),
(36, 'If you want something, Risk everything.', NULL, NULL, NULL),
(37, 'Negativity always wins the short game, but positivity always wins the long game.\r\n', NULL, NULL, NULL),
(38, 'When you doubt your power. You give power to your doubt.', NULL, NULL, NULL),
(39, 'the dream is free. The hustle is sold separately.\r\n ', NULL, NULL, NULL),
(40, ' Human hate the change that’s the opportunity.', NULL, NULL, NULL),
(41, 'Staying the same means moving backwards.\r\n ', NULL, NULL, NULL),
(42, 'An ant on the move does more than a dozing ox.', NULL, NULL, NULL),
(43, ' The days you are most uncomfortable are the days you learn the most about yourself.\r\n ', NULL, NULL, NULL),
(44, 'Wise men are not always silent, but they know when to be.', NULL, NULL, NULL),
(45, ' Reflection cannot be seen in boiling water. Similarly solution cannot be seen with a disturbed mind.\r\n ', NULL, NULL, NULL),
(46, 'You don’t need any supernatural power to serve people.', NULL, NULL, NULL),
(47, ' Everyone has fears conquering it is what matters.\r\n ', NULL, NULL, NULL),
(48, 'Action should speak louder than intentions. It’s not who we are underneath, but what we do that defines us.', NULL, NULL, NULL),
(49, ' A hero can be anyone. even a man doing something as simple and reassuring as putting a coat around a young boy’s shoulders to let him know that the world hadn’t ended.  \r\n ', NULL, NULL, NULL),
(50, 'Enemies are a necessity. You keep fighting, you keep learning. Eventually, you become better.', NULL, NULL, NULL),
(51, 'One wants to accomplish great things in life one has to practice maturity.\r\n', NULL, NULL, NULL),
(52, 'It is easier to deal with honest rejection than insincere appreciation.', NULL, NULL, NULL),
(53, ' Don’t be defensive. Accept constructive criticism immediately and emphatically.\r\n', NULL, NULL, NULL),
(54, ' To get to your destination, you would have to make one of two choices: you could either press the accelerator harder and risk damage, or release the brakes to make the car go faster.', NULL, NULL, NULL),
(55, ' A positive attitude is a person’s passport to a better tomorrow.\r\n ', NULL, NULL, NULL),
(56, 'The person with the negative attitude sees limitation.', NULL, NULL, NULL),
(57, 'you/we didn\'t like to climb much, we/yoy just liked to imagine summit.\r\n \r\n', NULL, NULL, NULL),
(58, 'you should never miss an opportunity to act upon your faith or beliefs.', NULL, NULL, NULL),
(59, 'Tragedies occur in everyone\'s life. We are meant to learn from them.\r\n‎', NULL, NULL, NULL),
(60, 'God\'s plan is beyond our grasp and often beyond the reach of our imagination.', NULL, NULL, NULL),
(61, 'you don\'t need to have all the right answers, just the right questions.\r\n', NULL, NULL, NULL),
(62, '‎if you want to have an impact in this world. You must put your belief and your faith into action.', NULL, NULL, NULL),
(63, 'know that as long as you are on this earth, there is a purpose and plan for you.\r\n', NULL, NULL, NULL),
(64, 'A flower doesn\'t think of competing with the flower next to it. It just blooms.', NULL, NULL, NULL),
(65, 'Thinking about tomorrow is not the problem. Trying to live tomorrow is the problem.\r\n ', NULL, NULL, NULL),
(66, 'Don’t tell the world what you can do “Show” it!', NULL, NULL, NULL),
(67, 'You can lose your money and make more, but you can never replace your time, invest your time wisely.\r\n', NULL, NULL, NULL),
(68, ' A good plan violently executed today is better than a perfect plan next week.', NULL, NULL, NULL),
(69, 'Life shrinks and expands in proportion to one’s courage.  \r\n', 'Anais Nin', NULL, NULL),
(70, ' There are no traffic jams along the extra mile.', 'Roger Staubach.', NULL, NULL),
(71, 'There is probably no greater reward than doing what you were created to do while serving a purpose greater than yourself.\r\n', NULL, NULL, NULL),
(72, ' Let go of your worries about your disability, and put your faith and trust back in god’s ability.', NULL, NULL, NULL),
(73, 'Never be satisfied with what you have achieved. Keep adapting and improving.\r\n', NULL, NULL, NULL),
(74, 'Leadership is about realizing that the impossible is generally the untried.', NULL, NULL, NULL),
(75, 'Be aware that you are rare.\r\n ', NULL, NULL, NULL),
(76, 'Practices like you’ve never won. Perform like you’ve never lost.', NULL, NULL, NULL),
(77, 'The undisciplined are slaves to moods and appetites.\r\n', NULL, NULL, NULL),
(78, ' A diamond is a chunk of coal that did well under pressure.', NULL, NULL, NULL),
(79, ' Sometimes when you’re in a dark place. You think you’ve been buried but actually you’ve been planted.\r\n', NULL, NULL, NULL),
(80, ' Don’t compare your life to others. There’s no comparison between the sun and the moon they shine when it’s their time.', NULL, NULL, NULL),
(81, ' The skill is a commodity the mindset is everything.\r\n', NULL, NULL, NULL),
(82, ' If you are good enough nobody is stopping you.', NULL, NULL, NULL),
(83, 'If you spend one second judging someone else’s luck you’ve already lost the whole game.\r\n', NULL, NULL, NULL),
(84, 'You should really care about your impact than your numbers.', NULL, NULL, NULL),
(85, 'The good life is inspired by love and guided by knowledge.\r\n', NULL, NULL, NULL),
(86, ' An investment in yourself pays the best interest.', NULL, NULL, NULL),
(87, ' What matters is what you do, not what you know.\r\n', NULL, NULL, NULL),
(88, ' An acquire knowledge one must study; but to acquire wisdom one must observe.', NULL, NULL, NULL),
(89, 'the right attitude very rarely leads to the wrong action.\r\n', NULL, NULL, NULL),
(90, ' Do it now. Sometimes later becomes never.', NULL, NULL, NULL),
(91, ' Allow your passion to become your purpose, and it will one day become your profession.\r\n', NULL, NULL, NULL),
(92, ' Successful people change the world with their decisions and unsuccessful people change their decision fearing the world.', NULL, NULL, NULL),
(93, ' Don’t be a part of crowd be a reason for it.\r\n', NULL, NULL, NULL),
(94, ' If world gives you a pain use it as weapon to change the world. ', NULL, NULL, NULL),
(95, 'Don’t be busy in watching other people’s story; be busy in making your own story.\r\n', NULL, NULL, NULL),
(96, ' If you can’t handle stress you won’t manage success.', NULL, NULL, NULL),
(97, ' Ability is poor man’s wealth.\r\n ', ' M. Wren.', NULL, NULL),
(98, 'Natural abilities are like natural plants that need pruning by study. ', 'Francis Bacon', NULL, NULL),
(99, ' Native ability without education is like tree without fruit. \r\n ', 'Aristippus', NULL, NULL),
(100, 'The human body has one ability not possessed by any machine – the ability to repair itself. ', 'George crane.', NULL, NULL),
(101, 'The actions of men are the best interpreters of their thoughts.\r\n', NULL, NULL, NULL),
(102, ' Let not the fruits of action be the motive of your actions. Otherwise you might be disappointed and leave the path of right action.', 'Rig veda', NULL, NULL),
(103, 'Be concerned with actions only, never with its result.\r\n ', 'Yajur veda.', NULL, NULL),
(104, 'We give advice by bucket, but take it by the grain. ', 'W. R. Alger.', NULL, NULL),
(105, ' Anger blows out the lamp of the mind. \r\n', 'Ingersoll.', NULL, NULL),
(106, ' To be angry is to revenge the faults of others on ourselves.', 'Pope', NULL, NULL),
(107, 'The essence of belief is the establishment of a habit. – Charles S. Pearce.\r\n ', NULL, NULL, NULL),
(108, 'There are two ways to slide easily through life; to believe everything or to doubt everything; both ways save us from thinking.', 'Alfred Korzybski.', NULL, NULL),
(109, ' Character is what you are in the dark.  ', 'Dwight L. Moody.\r\n', NULL, NULL),
(110, 'Character is a by-product; it is produced in the great manufacture of daily duty.', 'Woodrow Wilson.', NULL, NULL),
(111, ' Conversation enriches the understanding, but solitude is the school of genius. \r\n', 'Gibbon.', NULL, NULL),
(112, ' Without courage you cannot practice any other virtue.', ' Indira Gandhi.', NULL, NULL),
(113, 'xperience enables you to recognize a mistake when you make it again. \r\n', ' Franklin P. Jones.', NULL, NULL),
(114, ' Failure is often god’s own tool for craving some of the finest outlines in the character of his children. ', ' T. Hodgkin.', NULL, NULL),
(115, ' Fame is perfume of heroic deeds.- Socrates.\r\n ', NULL, NULL, NULL),
(116, 'One of the strongest characteristics of genius is the power of lighting its own fire.', 'John Waston Foster.', NULL, NULL),
(117, 'Doing easily what others find difficult is talent; doing what is impossible for talent is genius.', 'Amiel.', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `id` int(11) NOT NULL,
  `phone_type` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `force_update` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=no ,1=yes ',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`id`, `phone_type`, `version`, `force_update`, `created_at`, `updated_at`) VALUES
(1, 'android', '1.0', '0', '2019-01-09 05:55:27', '2018-07-11 09:51:15'),
(2, 'ios', '1.0', '0', '2018-07-11 06:11:51', '2018-07-11 09:56:10');

-- --------------------------------------------------------

--
-- Table structure for table `target_of_the_days`
--

CREATE TABLE `target_of_the_days` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('1','2','3') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '1=personal,2=professional,3=family',
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '1=success,0=fail  x',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `target_of_the_days`
--

INSERT INTO `target_of_the_days` (`id`, `user_id`, `title`, `type`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'Do Meditation/Go for a Walk/ Do Excersie', '1', '', '2018-06-26 04:00:00', '2018-06-26 04:00:00'),
(2, 1, 'Watch and learn from two random motivational or inspirational videos', '1', '', '2018-06-26 04:00:00', '2018-06-26 04:00:00'),
(3, 1, 'Read 10 pages of self help or motivational books', '1', '', '2018-06-26 04:00:00', '2018-06-26 04:00:00'),
(4, 1, 'Drink minimum 8 glass of water today', '1', '', '2018-06-26 04:00:00', '2018-06-26 04:00:00'),
(5, 1, 'Pray for 10 minutes today unconidtionally', '1', '', '2018-06-26 04:00:00', '2018-06-26 04:00:00'),
(6, 1, 'Learn one small or big special learning or thing today', '1', '', '2018-06-26 04:00:00', '2018-06-26 04:00:00'),
(7, 1, 'Complete your work one hour early', '2', '', '2018-06-26 04:00:00', NULL),
(8, 1, 'Be ten minutes prior or leave ten minutes late from your work place (Going extra mile)', '2', '', '2018-06-26 04:00:00', '2018-06-26 04:00:00'),
(9, 1, 'Don\'t see clock while working today', '2', '', '2018-06-26 04:00:00', '2018-06-26 04:00:00'),
(10, 1, 'Make a To Do List today once you start your day', '2', '', '2018-06-26 04:00:00', '2018-06-26 04:00:00'),
(11, 1, 'Ask yourself - \"Have I given my best today when my work was concerened?\"', '2', '', '2018-06-26 08:00:00', '2018-06-26 04:00:00'),
(12, 1, 'Try not to waste more than ten minutes in an hour while working (Its all about Work ethics)', '2', '', '2018-06-26 04:12:00', '2018-06-26 04:00:00'),
(13, 1, 'Take one meal with your family', '3', '', '2018-06-26 04:00:00', '2018-06-26 04:00:00'),
(14, 1, 'Sit with your family and dicuss random topic for 30 minutes today', '3', '', '2018-06-26 04:00:00', '2018-06-26 04:00:00'),
(15, 1, 'Talk with politness, gentleness and humbless with your family members', '3', '', '2018-06-26 04:07:00', '2018-06-26 04:00:00'),
(16, 1, 'Go on drive with your loved ones/parents/children today', '3', '', '2018-06-26 04:00:07', '2018-06-26 04:00:00'),
(17, 1, ' Write something really very beautiful and unique for your loved ones/parents/children today', '3', '', '2018-06-26 04:00:00', '2018-06-26 04:00:00'),
(18, 1, 'Before sleeping dicuss about the positive expreiences occurred with you today.', '3', '', '2018-06-26 04:00:00', '2018-06-26 04:00:00'),
(31, 20, 'sandipycyugivuviggugvuuvuvuvyvvuvuuvug', '3', '0', '2018-07-05 14:14:53', '2018-07-05 14:14:53'),
(36, 20, 'test no8', '1', '0', '2018-07-05 14:54:39', '2018-07-05 14:54:39'),
(30, 19, 'this is title123', '3', '0', '2018-07-05 13:57:24', '2018-07-06 11:07:41'),
(29, 20, 'hjunfgdfg', '3', '0', '2018-07-05 13:57:06', '2018-07-05 13:57:06'),
(28, 20, 'kkkk', '3', '0', '2018-07-05 13:55:22', '2018-07-05 13:55:22'),
(32, 20, 'kkkkk', '2', '0', '2018-07-05 14:15:14', '2018-07-05 14:15:14'),
(33, 20, 'kk', '1', '0', '2018-07-05 14:27:54', '2018-07-05 14:27:54'),
(34, 20, 'kkhjgg', '1', '0', '2018-07-04 14:28:06', '2018-07-05 14:28:06'),
(35, 21, 'test o', '1', '0', '2018-07-05 14:42:48', '2018-07-05 14:42:48'),
(37, 22, 'kk', '3', '0', '2018-07-05 15:03:39', '2018-07-05 15:03:39'),
(38, 21, 'gfhy', '1', '0', '2018-07-05 17:21:38', '2018-07-05 17:21:38'),
(39, 21, 'gfhygt', '1', '0', '2018-07-05 17:21:44', '2018-07-05 17:21:44'),
(40, 21, 'test', '3', '0', '2018-07-05 17:23:32', '2018-07-05 17:23:32'),
(41, 21, 'testhjj', '3', '0', '2018-07-05 17:23:38', '2018-07-05 17:23:38'),
(42, 21, 'test', '1', '0', '2018-07-05 17:27:25', '2018-07-05 17:27:25'),
(43, 21, 'ihghh', '1', '0', '2018-07-05 17:27:36', '2018-07-05 17:27:36'),
(44, 22, 'kk', '2', '0', '2018-07-05 17:39:16', '2018-07-05 17:39:16'),
(45, 21, 'test7', '2', '0', '2018-07-05 17:39:19', '2018-07-05 17:39:19'),
(46, 22, 'kkk', '2', '0', '2018-07-05 17:39:23', '2018-07-05 17:39:23'),
(47, 22, 'kkkk', '2', '0', '2018-07-05 17:39:26', '2018-07-05 17:39:26'),
(48, 21, 'test7 hvv', '2', '0', '2018-07-05 17:39:28', '2018-07-05 17:39:28'),
(49, 22, 'kkkkk', '2', '0', '2018-07-05 17:39:33', '2018-07-05 17:39:33'),
(50, 22, 'k', '2', '0', '2018-07-05 17:39:44', '2018-07-05 17:39:44'),
(51, 22, 'kk', '3', '0', '2018-07-05 17:43:56', '2018-07-05 17:43:56'),
(52, 22, 'kkkk', '2', '0', '2018-07-05 17:46:24', '2018-07-05 17:46:24'),
(53, 22, 'kkhkk', '1', '0', '2018-07-05 17:51:22', '2018-07-06 17:35:24'),
(54, 22, 'kkgjvff', '2', '0', '2018-07-06 09:38:56', '2018-07-06 09:38:56'),
(55, 22, 'adfg', '1', '0', '2018-07-06 09:39:07', '2018-07-06 09:39:07'),
(56, 22, 'ywvs', '1', '0', '2018-07-06 09:39:12', '2018-07-06 09:39:12'),
(57, 17, 'my custome 123456', '1', '0', '2018-07-06 11:22:07', '2018-07-06 11:22:07'),
(58, 17, 'my custome 123456', '1', '0', '2018-07-06 11:23:01', '2018-07-06 11:23:01'),
(59, 22, 'k', '3', '0', '2018-07-06 16:28:34', '2018-07-06 16:28:34'),
(60, 22, 'kkkkk', '3', '0', '2018-07-06 17:41:04', '2018-07-06 17:41:04'),
(61, 24, 'kk', '1', '0', '2018-07-10 15:13:53', '2018-07-10 15:13:53'),
(62, 19, 'kk', '1', '0', '2018-07-10 17:39:37', '2018-07-10 17:39:37'),
(63, 19, 'hshjhsjsj', '2', '0', '2018-07-10 17:39:42', '2018-07-10 17:40:01'),
(64, 19, 'kk', '3', '0', '2018-07-10 17:39:47', '2018-07-10 17:43:10'),
(65, 19, 'jjsbsjksjh', '2', '0', '2018-07-10 17:40:22', '2018-07-10 17:40:29'),
(66, 19, 'bsjsndj', '3', '0', '2018-07-10 17:43:16', '2018-07-10 17:43:16'),
(67, 19, 'jshsx', '3', '0', '2018-07-10 17:43:21', '2018-07-10 17:43:21'),
(68, 18, 'target7', '1', '0', '2018-07-11 21:12:26', '2018-07-11 21:12:26'),
(69, 24, 'vhgdvb', '1', '0', '2018-07-13 10:02:19', '2018-07-13 10:02:19'),
(70, 19, 'jk', '1', '0', '2018-07-27 12:50:58', '2018-07-27 12:50:58'),
(71, 25, 'talk', '3', '0', '2018-09-18 08:15:48', '2018-09-18 08:16:10'),
(72, 28, 'ok', '1', '0', '2018-12-05 15:38:48', '2018-12-05 15:38:48');

-- --------------------------------------------------------

--
-- Table structure for table `target_status`
--

CREATE TABLE `target_status` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `target_id` int(10) UNSIGNED NOT NULL,
  `status` enum('0','1') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '1 - success, 0 - failed',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `target_status`
--

INSERT INTO `target_status` (`id`, `user_id`, `target_id`, `status`, `created_at`, `updated_at`) VALUES
(106, 18, 2, '1', '2018-07-13 06:44:48', '2018-07-13 06:44:48'),
(105, 18, 18, '1', '2018-07-12 20:56:55', '2018-07-12 20:56:55'),
(104, 18, 9, '1', '2018-07-12 20:56:55', '2018-07-12 20:56:55'),
(103, 18, 2, '1', '2018-07-12 20:56:55', '2018-07-12 20:56:55'),
(102, 19, 17, '1', '2018-07-12 08:50:47', '2018-07-12 08:50:47'),
(101, 19, 10, '1', '2018-07-12 08:50:47', '2018-07-12 08:50:47'),
(100, 19, 2, '1', '2018-07-12 08:50:47', '2018-07-12 08:50:47'),
(99, 19, 16, '0', '2018-07-12 08:49:24', '2018-07-12 08:49:24'),
(98, 19, 9, '0', '2018-07-12 08:49:24', '2018-07-12 08:49:24'),
(97, 19, 1, '0', '2018-07-12 08:49:24', '2018-07-12 08:49:24'),
(96, 18, 15, '1', '2018-07-11 21:27:29', '2018-07-11 21:27:29'),
(95, 18, 7, '1', '2018-07-11 21:27:29', '2018-07-11 21:27:29'),
(94, 18, 4, '1', '2018-07-11 21:27:29', '2018-07-11 21:27:29'),
(93, 18, 13, '0', '2018-07-11 21:17:38', '2018-07-11 21:17:38'),
(92, 18, 7, '0', '2018-07-11 21:17:38', '2018-07-11 21:17:38'),
(91, 18, 68, '0', '2018-07-11 21:17:38', '2018-07-11 21:17:38'),
(123, 25, 71, '1', '2018-09-18 08:16:12', '2018-09-18 08:16:12'),
(122, 25, 10, '1', '2018-09-18 08:16:12', '2018-09-18 08:16:12'),
(121, 25, 6, '1', '2018-09-18 08:16:12', '2018-09-18 08:16:12'),
(117, 18, 16, '1', '2018-07-18 17:15:13', '2018-07-18 17:15:13'),
(116, 18, 7, '1', '2018-07-18 17:15:13', '2018-07-18 17:15:13'),
(115, 18, 2, '1', '2018-07-18 17:15:13', '2018-07-18 17:15:13'),
(84, 21, 18, '1', '2018-07-09 17:35:47', '2018-07-09 17:35:47'),
(83, 21, 11, '1', '2018-07-09 17:35:47', '2018-07-09 17:35:47'),
(82, 21, 2, '1', '2018-07-13 17:35:47', '2018-07-09 17:35:47'),
(56, 2, 8, '1', '2018-07-13 14:43:01', '2018-07-09 14:43:01'),
(57, 2, 15, '1', '2018-07-09 14:43:01', '2018-07-09 14:43:01'),
(58, 2, 5, '1', '2018-07-09 14:43:01', '2018-07-09 14:43:01'),
(59, 2, 8, '1', '2018-07-09 14:43:01', '2018-07-09 14:43:01'),
(60, 2, 15, '1', '2018-07-09 14:43:01', '2018-07-09 14:43:01'),
(61, 2, 5, '0', '2018-07-09 14:43:01', '2018-07-09 14:43:01'),
(62, 2, 8, '0', '2018-07-09 14:43:01', '2018-07-09 14:43:01'),
(63, 2, 15, '0', '2018-07-09 14:43:01', '2018-07-09 14:43:01'),
(64, 2, 5, '0', '2018-07-09 14:43:01', '2018-07-09 14:43:01'),
(65, 2, 8, '0', '2018-07-09 14:43:01', '2018-07-09 14:43:01'),
(66, 2, 15, '0', '2018-07-09 14:43:01', '2018-07-09 14:43:01'),
(67, 2, 5, '1', '2018-07-09 14:43:01', '2018-07-09 14:43:01'),
(68, 2, 8, '1', '2018-07-09 14:43:01', '2018-07-09 14:43:01'),
(69, 2, 15, '1', '2018-07-09 14:43:01', '2018-07-09 14:43:01'),
(70, 2, 5, '0', '2018-07-09 14:43:01', '2018-07-09 14:43:01'),
(71, 2, 8, '0', '2018-07-09 14:43:01', '2018-07-09 14:43:01'),
(72, 2, 15, '0', '2018-07-09 14:43:01', '2018-07-09 14:43:01'),
(73, 2, 5, '1', '2018-07-09 14:43:01', '2018-07-09 14:43:01'),
(74, 2, 8, '1', '2018-07-09 14:43:01', '2018-07-09 14:43:01'),
(75, 2, 15, '1', '2018-07-09 14:43:01', '2018-07-09 14:43:01'),
(76, 2, 5, '0', '2018-07-09 14:43:01', '2018-07-09 14:43:01'),
(77, 2, 8, '0', '2018-07-09 14:43:01', '2018-07-09 14:43:01'),
(78, 2, 15, '0', '2018-07-09 14:43:01', '2018-07-09 14:43:01'),
(79, 2, 5, '0', '2018-07-09 14:43:02', '2018-07-09 14:43:02'),
(80, 2, 8, '0', '2018-07-09 14:43:02', '2018-07-09 14:43:02'),
(81, 2, 15, '0', '2018-07-09 14:43:02', '2018-07-09 14:43:02'),
(107, 18, 7, '1', '2018-07-13 06:44:48', '2018-07-13 06:44:48'),
(108, 18, 13, '1', '2018-07-13 06:44:48', '2018-07-13 06:44:48'),
(114, 18, 13, '1', '2018-07-17 20:14:09', '2018-07-17 20:14:09'),
(113, 18, 10, '1', '2018-07-17 20:14:09', '2018-07-17 20:14:09'),
(112, 18, 4, '1', '2018-07-17 20:14:09', '2018-07-17 20:14:09'),
(124, 26, 2, '0', '2018-09-20 08:56:23', '2018-09-20 08:56:23'),
(125, 26, 8, '0', '2018-09-20 08:56:23', '2018-09-20 08:56:23'),
(126, 26, 17, '0', '2018-09-20 08:56:23', '2018-09-20 08:56:23'),
(127, 26, 1, '0', '2018-11-29 15:22:48', '2018-11-29 15:22:48'),
(128, 26, 8, '0', '2018-11-29 15:22:48', '2018-11-29 15:22:48'),
(129, 26, 15, '0', '2018-11-29 15:22:48', '2018-11-29 15:22:48'),
(130, 29, 1, '1', '2019-01-04 11:33:19', '2019-01-04 11:33:19'),
(131, 29, 7, '1', '2019-01-04 11:33:19', '2019-01-04 11:33:19'),
(132, 29, 13, '1', '2019-01-04 11:33:19', '2019-01-04 11:33:19'),
(133, 30, 2, '1', '2019-01-04 18:25:55', '2019-01-04 18:25:55'),
(134, 30, 9, '1', '2019-01-04 18:25:55', '2019-01-04 18:25:55'),
(135, 30, 13, '1', '2019-01-04 18:25:55', '2019-01-04 18:25:55'),
(136, 30, 2, '1', '2019-01-05 16:41:43', '2019-01-05 16:41:43'),
(137, 30, 9, '1', '2019-01-05 16:41:43', '2019-01-05 16:41:43'),
(138, 30, 18, '1', '2019-01-05 16:41:43', '2019-01-05 16:41:43'),
(139, 25, 1, '1', '2019-01-09 10:27:06', '2019-01-09 10:27:06'),
(140, 25, 7, '1', '2019-01-09 10:27:06', '2019-01-09 10:27:06'),
(141, 25, 13, '1', '2019-01-09 10:27:06', '2019-01-09 10:27:06'),
(142, 31, 1, '1', '2019-01-09 16:44:55', '2019-01-09 16:44:55'),
(143, 31, 7, '1', '2019-01-09 16:44:55', '2019-01-09 16:44:55'),
(144, 31, 13, '1', '2019-01-09 16:44:55', '2019-01-09 16:44:55');

-- --------------------------------------------------------

--
-- Table structure for table `userclaims`
--

CREATE TABLE `userclaims` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `claim_points` int(11) NOT NULL,
  `gift_id` int(11) DEFAULT NULL,
  `claim_status` enum('1','0') COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '1=claimed,0=not claimed',
  `is_deleted` int(11) NOT NULL DEFAULT '0' COMMENT '1=deleted,0=no deleted',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `userclaims`
--

INSERT INTO `userclaims` (`id`, `user_id`, `claim_points`, `gift_id`, `claim_status`, `is_deleted`, `created_at`, `updated_at`) VALUES
(18, 24, 100, 1, '1', 0, '2018-07-10 10:04:02', '2018-07-10 10:04:02'),
(17, 22, 100, 1, '1', 0, '2018-07-09 13:14:39', '2018-07-09 13:14:39'),
(13, 21, 100, 1, '1', 0, '2018-07-06 11:15:21', '2018-07-06 11:15:21'),
(19, 24, 300, 2, '1', 0, '2018-07-10 16:07:43', '2018-07-10 16:07:43'),
(20, 18, 100, 1, '1', 0, '2018-07-13 06:44:56', '2018-07-13 06:44:56');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL DEFAULT '2',
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `points` int(11) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `new_created_at` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ' ',
  `device_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'as token for pushNotification'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role_id`, `name`, `email`, `password`, `points`, `remember_token`, `created_at`, `updated_at`, `new_created_at`, `device_id`) VALUES
(1, 1, 'Admin', 'admin@sajanshah.com', '$2y$10$HVSRhGWZQSkinWRKjsbIdOMdEB3lkQrnjDBtTw8uzBP9xtvK9UFN2', 470, 'kRchFwI4oRqsURQF40vDTxrifexwsQ2PrXYVoNvNm5Cb3xeA9uJW15vE9gCT', '2018-06-26 04:00:00', '2018-06-27 16:44:45', '', ''),
(26, 2, NULL, 'sajan.shah03@gmail.com', NULL, 50, NULL, '2018-09-18 11:39:39', '2018-12-04 19:18:19', ' ', 'cQ0R_FGCfhE:APA91bGlDOy6IHUe3EzYF0YBTLhv8papUJKNO4FsPpc2hg3kBgY7lkQ7A72Qf0m9DQFWwTCboOS8FAeYL7AWJaAc6UT29sJQYVp0HXXAtSE8V40ghqnjrGBHEUmv0Bx1RQ1gVmtyo_EU'),
(16, 2, NULL, 'hasan@xhtmljunkies.com', NULL, 0, NULL, '2018-06-28 12:50:49', '2018-06-28 12:50:49', ' ', 'ecpJjfvA64w:APA91bEW7nY3f2ERptIGAoateXArTsAjhOSiXBkemlk84Dd19V7AXYMoPwc9Z2pfAJ01QqeniDyEER-wz577KcoqpbsqrmKVyhS081oNH919_4zyqiTgfmil00J_mmTIbkXjH8ympqnzvKxQCNV_GJAQx-SKBd2lBw'),
(22, 2, NULL, 'krishnakant@xhtmljunkies.com', NULL, -40, NULL, '2018-07-05 14:56:02', '2018-07-09 15:10:53', ' ', 'cmMTvdmpsgM:APA91bHhKz2WhXKE62Bz-_h8l_qX_OVTsgx2EJ3pUqOf9hsCZuyXy36OVjRUzbJJKDstVQ8OrvrILjjYA6lO8I5V_NaKADIE9LMARWDmQKaVU4GMtEGUuQIqmAm6NN2fs8n7KEMLSvXm3Vs2XJ70xtorM5wH5MS3og'),
(18, 2, NULL, 'patelniketa8889@gmail.com', NULL, 40, NULL, '2018-07-03 21:42:40', '2018-07-22 21:22:47', ' ', 'ffci6JCPmCM:APA91bEG_pOZqh1HbL2KviDKFFvwMtATAZeYJ6_OMVuGfCQ48sxjIGXij6CY62ObnqlA0Uqq2_M0qEbC1HTgIsheNgdTq_Bel1knlViSuUdW4luN-c1obsfCgiyfl7kNGe6-EkbdHGp3WHqqgVUDVi_RPgDxPPbBmA'),
(19, 2, NULL, 'krishnknt64@gmail.com', NULL, 50, NULL, '2018-07-05 01:51:44', '2018-07-27 12:50:36', ' ', 'f8s7l9BlDeo:APA91bHblgPDQhJIkSDaewekFGjBX8iC9FWLAuhp5W6fW9rFs9hbq7cdUOKagKQAExQl1Uxlb37Lylr98hh3N0izHj1W-sSE1BpkvlsJenfmVjM7MX0GbcxF3BadJvgWeS6OjaFXIsdxBIKJPs8z5EzpU4yS3fiC5Q'),
(24, 2, NULL, 'elsner.testing@gmail.com', NULL, 70, NULL, '2018-07-01 09:56:24', '2018-07-17 08:55:28', '', 'cKOx3L6yZNI:APA91bFBuUGzH0281zGuCHlY8UNvTqkVKyCgZb-6kwRHXWID5PAuIhqI6-cnBwB-MJ27dWn_ZQVZrzuNgxcQLbYc5UOIJ4hj_1vqTlZto3GBVLl3uNV9WmU0-ZT2fM5wf4TCoUFewoLEnlNMtom6AXZzZ-CY-DmBUQ'),
(23, 2, NULL, 'test91@elsner.in', NULL, 0, NULL, '2018-07-06 10:54:45', '2018-07-06 10:54:45', ' ', 'aaaaaaaaa'),
(25, 2, NULL, 'niral@elsner.in', NULL, 50, NULL, '2018-09-17 16:09:51', '2019-01-10 17:05:27', ' ', 'dPJ-4X9Seno:APA91bHS1kBLpgd8J9v6w9zXTQ20mXqL0bFWTAG3YMC7jNTNTemqLP6sEjKaUs9gwkfV4oXR0Lu6sqewMyNf_GmWvW9rlMhGwnHuGZQfd24usQyIFpgQsWG4GbITccK9dTtRFFEoOjeF'),
(27, 2, NULL, 'kknaik123@gmail.com', NULL, 0, NULL, '2018-12-04 19:29:33', '2019-01-01 18:02:07', ' ', 'fgVVVqCtYNo:APA91bF45SWdtuC7RoXWeRE8UDymKTVdZyw7NhWK4pfJz1ePmsFAfXZPV6h0FBnQjFEjpd57twP0nApEPsLnfX4EceBtFvHJQcuaJa21l7dvChKtwWLQWvYw_AhDSeCCdDpbB8tBAE96'),
(28, 2, NULL, 'sanjayramani.sdjic@gmail.com', NULL, 0, NULL, '2018-12-05 10:39:25', '2018-12-08 13:12:39', ' ', 'fVJ5jdcXjbc:APA91bGsVMf8s4Hne_r7vLS8IH3LIREfzb6DPfI3YBnqMFA6-sgdk6nVWWvKWOo3Jc3HT_NAz2Ex9nZDoN_s5jbwufGjzW4Tq7ssQsaB35uuMeup3a2wDlN7B3BXoLpd1WyGZAj6Zxjw'),
(29, 2, NULL, 'sanjayvramani@gmail.com', NULL, 20, NULL, '2018-12-25 11:47:37', '2019-01-12 16:36:52', ' ', 'fiFXMUGCAHk:APA91bFcTp7Tx0prtAeunNb2EYTbhL2iPhrAFa9A8vr153B2AtEdW0xymr4rjFbBTndzIuSrRArHsor4186mfzdPgq7fYY6RqdwufblrLx9ejur6mXepuuCvRtloTon6mKqj7pQcFzye'),
(30, 2, NULL, 'gohilm132@gmail.com', NULL, 30, NULL, '2019-01-04 18:24:02', '2019-01-05 17:46:19', ' ', 'dBgpxo0QvRQ:APA91bGJ4DFCWaMqbyN8soaDtNmarMCdImz6VtMqSv2vGL-Pjc8Tx36j5P2L2Sq-mZuzYhR77t8x7I2hNz17seTUNwLE6ZmR7DDQt9iIrtvZIFwjgiZBi0y60jXjWxE-8hS69UCIrehD'),
(31, 2, NULL, 'harshal@xhtmljunkies.com', NULL, 10, NULL, '2019-01-09 16:43:36', '2019-01-09 16:44:55', ' ', 'c1P02zeKryw:APA91bGMkgofRMuU1xzSmuErqQvC5Y9awrq5K83cjFyPdLvr4t0hGNYPbzGInM1KRN3X__n3P8yBH_Aceage5vuIB18QtDAIpYhSzep3DH-f1JP5IylYvPBn7LXIwll-8MD6nm9y2PhX');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `challenge_of_the_days`
--
ALTER TABLE `challenge_of_the_days`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `challenge_status`
--
ALTER TABLE `challenge_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cms`
--
ALTER TABLE `cms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `connectwithuses`
--
ALTER TABLE `connectwithuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gifts`
--
ALTER TABLE `gifts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `quotofthedays`
--
ALTER TABLE `quotofthedays`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `target_of_the_days`
--
ALTER TABLE `target_of_the_days`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `target_status`
--
ALTER TABLE `target_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userclaims`
--
ALTER TABLE `userclaims`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `challenge_of_the_days`
--
ALTER TABLE `challenge_of_the_days`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT for table `challenge_status`
--
ALTER TABLE `challenge_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=161;

--
-- AUTO_INCREMENT for table `cms`
--
ALTER TABLE `cms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `connectwithuses`
--
ALTER TABLE `connectwithuses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `gifts`
--
ALTER TABLE `gifts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `quotofthedays`
--
ALTER TABLE `quotofthedays`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;

--
-- AUTO_INCREMENT for table `setting`
--
ALTER TABLE `setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `target_of_the_days`
--
ALTER TABLE `target_of_the_days`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `target_status`
--
ALTER TABLE `target_status`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=145;

--
-- AUTO_INCREMENT for table `userclaims`
--
ALTER TABLE `userclaims`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
