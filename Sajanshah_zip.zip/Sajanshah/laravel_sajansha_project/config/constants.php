<?php

return [
    'youtube' => [
        'api_key' => 'AIzaSyC9sBxnG-4RpAe3bxp2s22vSfiTR7rFPpU',
        'channel_id' => 'UC-zcxbOmTsRzSlydELA8Bag'
        
    ]
];
