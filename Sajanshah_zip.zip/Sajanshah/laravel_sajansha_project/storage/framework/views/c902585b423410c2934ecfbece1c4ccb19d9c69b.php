<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card ">
            <div class="card-header card-header-success card-header-icon">
                <!-- <div class="card-icon">
                    <i class="material-icons"></i>
                </div> -->
                <h4 class="card-title">List</h4>
                <hr style="width: 100%;height: 5px;background-color:#e91e63;color:#FF0066;border: 0 none;">
            </div>
            <div class="card-body ">
               <div class="row inner-menu pull-right">
                    <a href="<?php echo e(url('/admin/targetoftheday')); ?>" title="Back" ><button class="btn btn-warning btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                </div> 
                </br>
                </br></br>
                <div class="row">
                  <div class="col-md-12">     

                       <table class="table table-striped" id="myTable">
                        <thead>
                          <tr>
                            <th>#</th>
                            <th>Date</th>
                            <!-- <th>Content</th> -->
                            <th width="25%">Status</th>
                          </tr>
                        </thead>
                        <tbody>
             
                            <?php $__currentLoopData = $statusview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             
                             <tr>
                                  <td style="width:10% !important"><?php echo e(++$key); ?></td>
                                  <td><?php echo e($item['created_at']); ?></td>
                                     <td>
                                      <?php
                                        if($item['status']==1){
                                          echo "Success";
                                        } else{
                                          echo "Failed";
                                        }
                                      ?>
                                    </td>
                              </tr>
                           
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                       </table>

                  </div>
               </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



















<?php echo $__env->make('layouts.theme', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>