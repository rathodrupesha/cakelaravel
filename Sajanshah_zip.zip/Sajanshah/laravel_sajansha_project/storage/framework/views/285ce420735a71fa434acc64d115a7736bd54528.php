<link rel="apple-touch-icon" href="<?php echo e(asset('public/images/apple-icon.png')); ?>">
<link rel="icon" href="<?php echo e(asset('public/images/favicon.png')); ?>">
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
<link rel="stylesheet" href="<?php echo e(asset('public/css/material-dashboard.min.css')); ?>">
<link href="<?php echo e(asset('public/css/demo.css')); ?>" rel="stylesheet"/>


 <!-- datatable css
<link href="<?php echo e(asset('public/css/datatable/dataTables.bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"
      media="all"/>
 -->
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css">

 <!-- j query date picekr css-->
 <link href="<?php echo e(asset('public/css/datepicker/jquery-ui.css')); ?>" rel="stylesheet" type="text/css"
      media="all"/>
<!-- boostrape daterange picekr css-->
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css" />

<!--custome css -->
<link href="<?php echo e(asset('public/css/custome/custome.css')); ?>" rel="stylesheet" type="text/css"
      media="all"/>

<link href="<?php echo e(asset('public/css/jquery.cardtabs.css')); ?>" type="text/css"
      media="all"/> 
