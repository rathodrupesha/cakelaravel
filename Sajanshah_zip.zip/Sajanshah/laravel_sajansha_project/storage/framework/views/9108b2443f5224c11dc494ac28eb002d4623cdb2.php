<?php $__env->startSection('content'); ?>


<div class="row">
    <div class="col-md-12">
        <div class="card ">
            <div class="card-header card-header-success card-header-icon">
                <!-- <div class="card-icon">
                    <i class="material-icons"></i>
                </div> -->
                <h4 class="card-title">List</h4>
                <hr style="width: 100%;height: 5px;background-color:#e91e63;color:#FF0066;border: 0 none;">
            </div>
            <div class="card-body ">
                
                <div class="row">
                  <div class="col-md-12">     
                     <div class="row inner-menu pull-right">
                        <a href="<?php echo e(url('/admin/targetoftheday/create')); ?>" class="btn btn-success btn-sm pull-right" title="Add New target">
                          <i class="fa fa-plus" aria-hidden="true"></i> Add New
                        </a>
                    </div>
                     <div class="card-body "> 
                       <ul class="nav nav-pills nav-pills-warning" role="tablist"> 
                       <li class="nav-item"> 
                       <a class="nav-link active show" data-toggle="tab" href="#link1" role="tablist"> Personal </a> 
                       </li> 
                       <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#link2" role="tablist"> Professional </a> 
                       </li> 
                       <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#link3" role="tablist"> Family </a> </li>
                       <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#link4" role="tablist"> Custom </a> </li>
                        </ul> 

                      <div class="tab-content tab-space"> 
                          <div class="tab-pane active show" id="link1"> 

                              
                              <table class="table table-striped myTable" >
                              <thead>
                                <tr>
                                  <th >#</th>
                                  <th>Title</th>
                                  <th width="25%">Actions</th>
                                   <th>Status</th>
                                </tr>
                              </thead>
                              <tbody>
             
                                    <?php $__currentLoopData = $targets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <?php if($item['type'] != '1'): ?>
                                      <?php continue; ?>
                                     <?php endif; ?>
                                     <?php if($item['user_id'] != Auth::id()): ?>
                                      <?php continue; ?>
                                     <?php endif; ?>
                                     <tr>
                                          <td style="width:10% !important"><?php echo e($item['id']); ?></td>
                                            <td><?php echo e(strip_tags($item['title'])); ?></td>
                                            <td style="width:20% !important;">

                                                <a href="<?php echo e(url('/admin/targetoftheday/' . $item['id'] . '/edit')); ?>" title="  Edit role">
                                                    <button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
                                                </a>

                                                <form method="POST" action="<?php echo e(url('/admin/targetoftheday' . '/' . $item['id'])); ?>"
                                                      accept-charset="UTF-8" style="display:inline">
                                                    <?php echo e(method_field('DELETE')); ?>

                                                    <?php echo e(csrf_field()); ?>

                                                    <button type="submit" class="btn btn-danger btn-sm" title="Delete role"
                                                            onclick="return confirm(&quot;Confirm; delete?;&quot;)"><i
                                                                class="fa fa-trash-o" aria-hidden="true"></i></button>
                                                </form>
                                            </td>

                                             <td style="width:20% !important;">
                                            
                                              <a href="<?php echo e(url('/admin/statusviewgeneral/'.$item['id'].'/1')); ?>" title="success">
                                               <span class="btn btn-success btn-sm"><?php echo e(($item['target_success_count'])); ?>

                                               </span>
                                               </a>
                                              <a href="<?php echo e(url('/admin/statusviewgeneral/'.$item['id'].'/0')); ?>" title="failed"> 
                                             <span class="btn btn-danger btn-sm"><?php echo e(($item['target_fail_count'])); ?></span>
                                             </a>

                                           </td>
                  
                                      </tr>
                                   
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                               </table>
                          </div> 
                          <!-- -------------------------Professional---------------------------- -->

                          <div class="tab-pane" id="link2"> 
                        
                              <table class="table table-striped myTable" >
                              <thead>
                                <tr>
                                  <th >#</th>
                                  <th>Title</th>
                                  <th width="25%">Actions</th>
                                </tr>
                              </thead>
                              <tbody>
             
                                    <?php $__currentLoopData = $targets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <?php if($item['type'] != '2' ): ?>
                                      <?php continue; ?>
                                     <?php endif; ?>
                                     <?php if($item['user_id'] != Auth::id()): ?>
                                      <?php continue; ?>
                                     <?php endif; ?>
                                     <tr>
                                          <td style="width:10% !important"><?php echo e($item['id']); ?></td>
                                            <td><?php echo e(strip_tags($item['title'])); ?></td>
                                            <td style="width:20% !important;">

                                                <a href="<?php echo e(url('/admin/targetoftheday/' . $item['id'] . '/edit')); ?>" title="  Edit role">
                                                    <button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o"
                                                                                              aria-hidden="true"></i></button>
                                                </a>

                                                <form method="POST" action="<?php echo e(url('/admin/targetoftheday' . '/' . $item['id'])); ?>"
                                                      accept-charset="UTF-8" style="display:inline">
                                                    <?php echo e(method_field('DELETE')); ?>

                                                    <?php echo e(csrf_field()); ?>

                                                    <button type="submit" class="btn btn-danger btn-sm" title="Delete role"
                                                            onclick="return confirm(&quot;Confirm; delete?;&quot;)"><i
                                                                class="fa fa-trash-o" aria-hidden="true"></i></button>
                                                </form>
                                            </td>
                  
                                      </tr>
                                   
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                               </table>
 
                          </div> 

                          <!-- -------------------------Family ---------------------------- -->

                          <div class="tab-pane" id="link3"> 
                              

                             <table class="table table-striped myTable" >
                              <thead>
                                <tr>
                                  <th >#</th>
                                  <th>Title</th>
                                  <th width="25%">Actions</th>
                                </tr>
                              </thead>
                              <tbody>
             
                                    <?php $__currentLoopData = $targets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <?php if($item['type'] != '3'): ?>
                                      <?php continue; ?>
                                     <?php endif; ?>
                                     <?php if($item['user_id'] != Auth::id()): ?>
                                      <?php continue; ?>
                                     <?php endif; ?>
                                     <tr>
                                          <td style="width:10% !important"><?php echo e($item['id']); ?></td>
                                            <td><?php echo e(strip_tags($item['title'])); ?></td>
                                            <td style="width:20% !important;">

                                                <a href="<?php echo e(url('/admin/targetoftheday/' . $item['id'] . '/edit')); ?>" title="  Edit role">
                                                    <button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o"
                                                                                              aria-hidden="true"></i></button>
                                                </a>

                                                <form method="POST" action="<?php echo e(url('/admin/targetoftheday' . '/' . $item['id'])); ?>"
                                                      accept-charset="UTF-8" style="display:inline">
                                                    <?php echo e(method_field('DELETE')); ?>

                                                    <?php echo e(csrf_field()); ?>

                                                    <button type="submit" class="btn btn-danger btn-sm" title="Delete role"
                                                            onclick="return confirm(&quot;Confirm; delete?;&quot;)"><i
                                                                class="fa fa-trash-o" aria-hidden="true"></i></button>
                                                </form>
                                            </td>
                  
                                      </tr>
                                   
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                               </table>

                          </div> 

                           
                          <!-- -------------------------Custom ---------------------------- -->

                          <div class="tab-pane" id="link4"> 
                              

                             <table class="table table-striped myTable" >
                              <thead>
                                <tr>
                                  <th >#</th>
                                  <th>User Name</th>
                                  <th>User Email</th>
                                  <th>Target</th>
                                  <th>Type</th>
                                  <th width="25%">Created At</th>
                                  <th width="25%">status</th>
                                </tr>
                              </thead>
                              <tbody>
             
                                    <?php $__currentLoopData = $targets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <?php if($item['user_id'] == Auth::id()): ?>
                                      <?php continue; ?>
                                     <?php endif; ?>
                                     <tr>
                                          <td style="width:10% !important"><?php echo e($item['id']); ?></td>
                                          <td><?php echo e(strip_tags($item['user']['name'])); ?></td>
                                          <td><?php echo e(strip_tags($item['user']['email'])); ?></td>
                                          <td><?php echo e(strip_tags($item['title'])); ?></td>
                                          <td>
                                             <?php
                                             if($item['type']==1){
                                              echo "Personal";
                                             }else if($item['type']==2) {
                                              echo "Professional";
                                             }else if($item['type']==3) {
                                              echo "Family";
                                             }
                                             ?>

                                          </td>
                                      
                                           <td>
                                             <?php echo e($item['created_at']); ?>

                                           </td>

                                           <td>
                                            
                                              <a href="<?php echo e(url('/admin/statusview/' . $item['user']['id'] . '/'.$item['id'].'/1')); ?>" title="success">
                                               <span class="btn btn-success btn-sm"><?php echo e(($item['target_success_count'])); ?>

                                               </span>
                                               </a>
                                              <a href="<?php echo e(url('/admin/statusview/' . $item['user']['id'] . '/'.$item['id'].'/0')); ?>" title="failed"> 
                                             <span class="btn btn-danger btn-sm"><?php echo e(($item['target_fail_count'])); ?></span>
                                             </a>

                                           </td>
                  
                                      </tr>
                                   
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                               </table>

                          </div> 

                        </div> <!-- tab-content tab-space -->

                      </div><!-- card body -->

                   
                  </div>
               </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>



















<?php echo $__env->make('layouts.theme', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>