

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card ">
            <div class="card-header card-header-success card-header-icon">
                <!-- <div class="card-icon">
                    <i class="material-icons"></i>
                </div> -->
                <h4 class="card-title">List & Edit</h4>
                <hr style="width: 100%;height: 5px;background-color:#e91e63;color:#FF0066;border: 0 none;">
            </div>
            <div class="card-body ">
              
                <div class="row">
                  <div class="col-md-12">     

                     <form method="POST" action="<?php echo e(url('/admin/connectwithus', [$connectwithus['id']])); ?>" accept-charset="UTF-8" class="form-horizontal" enctype="multipart/form-data" id="validate_form">
                            <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="PUT">
                         <div class="row">
                           <div class="col-md-2">
                            <label  class=" control-label">facebook</label>
                           </div>
                           <div class="col-md-10">
                            <input class="form-control required" type="text" name="facebook" value="<?php echo $connectwithus['facebook'];?>">
                           </div>
                         </div>
                         </br>
                         <div class="row">
                           <div class="col-md-2">
                            <label  class=" control-label">Instagram</label>
                           </div>
                           <div class="col-md-10">
                            <input class="form-control required" type="text" name="instagrame" value="<?php echo $connectwithus['instagrame'];?>">
                           </div>
                         </div>

                         </br>
                         <div class="row">
                           <div class="col-md-2">
                            <label  class=" control-label">Youtube</label>
                           </div>
                           <div class="col-md-10">
                            <input class="form-control required" type="text" name="youtube" value="<?php echo $connectwithus['youtube'];?>">
                           </div>
                         </div>

                         </br>
                         <div class="row">
                           <div class="col-md-2">
                            <label  class=" control-label">Tweeter</label>
                           </div>
                           <div class="col-md-10">
                            <input class="form-control required" type="text" name="tweeter" value="<?php echo $connectwithus['tweeter'];?>">
                           </div>
                         </div>

                         </br>
                         <div class="row">
                           <div class="col-md-2">
                            <label  class=" control-label">Snapchat</label>
                           </div>
                           <div class="col-md-10">
                            <input class="form-control required" type="text" name="snapchat" value="<?php echo $connectwithus['snapchat'];?>">
                           </div>
                         </div>

                         </br>
                         <div class="row">
                           <div class="col-md-2">
                            <label  class=" control-label">Linkldn</label>
                           </div>
                           <div class="col-md-10">
                            <input class="form-control required" type="text" name="linkldn" value="<?php echo $connectwithus['linkldn'];?>">
                           </div>
                         </div>

                         <div class="form-group" style="margin-left: 388px;">
                            <div class="col-md-4">
                                <input class="btn btn-primary" type="submit" value="Update" >
                            </div>
                        </div>
                      

                  </div>
               </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



















<?php echo $__env->make('layouts.theme', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>