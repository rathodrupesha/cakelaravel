
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card ">
            <div class="card-header card-header-success card-header-icon">
              <!--   <div class="card-icon">
                    <i class="material-icons"></i>
                </div> -->
                <h4 class="card-title">Edit</h4>
                <hr style="width: 100%;height: 5px;background-color:#e91e63;color:#FF0066;border: 0 none;">
            </div>
            <div class="card-body ">
                <div class="row inner-menu pull-right">
                    <a href="<?php echo e(url('/admin/challengeoftheday')); ?>" title="Back" ><button class="btn btn-warning btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                </div>
                </br>
                <div class="row">
                  <div class="col-md-12">
                        <form method="POST" action="<?php echo e(url('/admin/challengeoftheday', [$challengeoftheday['id']])); ?>" accept-charset="UTF-8" class="form-horizontal" enctype="multipart/form-data" id="validate_form">
                            <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="PUT">
                        <div class="form-group">
                              <div class="row">
                               <div class="col-md-2">
                                 <label for="content" class=" control-label"><?php echo e('Title :'); ?></label>
                               </div>
                               <div class="col-md-10">
                                 <input class="form-control required" name="title" type="text" id="title" value="<?php echo $challengeoftheday['title'];?>">
                                 <?php echo $errors->first('title', '<p class="help-block" style="color: red;">:message</p>'); ?>

                               </div>
                             </div>

                        </div>
                       
                        <div class="form-group" style="margin-left: 388px;">
                            <div class="col-md-4">
                                <input class="btn btn-primary" type="submit" value="Update" id="validate_submit">
                            </div>
                        </div>
                            

                        </form>
                  </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.theme', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>