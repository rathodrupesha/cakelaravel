<?php $__env->startSection('content'); ?>

<div class="col-md-4 col-sm-6 ml-auto mr-auto">
    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
        <div class="card card-login ">
            <div class="card-header card-header-rose text-center">
                <h4 class="card-title">Log in</h4>
            </div>
            <div class="card-body ">
                <span class="bmd-form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text">
                            <i class="material-icons">email</i>
                        </span>
                      </div>
                       <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus placeholder="Email">
                        <?php if($errors->has('email')): ?>
                            <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                  </span>
                <span class="bmd-form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text">
                          <i class="material-icons">lock_outline</i>
                        </span>
                      </div>
                       <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required placeholder="Password">
                        <?php if($errors->has('password')): ?>
                            <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </span>
               <span class="bmd-form-group">
                    <div class="input-group">
                      
                      <div class="form-check">
                        <label class="form-check-label" style="margin-left: 20px;">
                            <input type="checkbox" class="form-check-input" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> 
                            <span class="form-check-sign">
                                <span class="check"></span>
                            </span>
                            <?php echo e(__('Remember Me')); ?>.
                        </label>
                    </div>
                    </div>
                </span>
            </div>
            <div class="card-footer justify-content-center">
                <button type="submit" class="btn btn-rose btn-link btn-lg">
                    <?php echo e(__('Login')); ?>

                </button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>