

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card ">
            <div class="card-header card-header-success card-header-icon">
                <!-- <div class="card-icon">
                    <i class="material-icons"></i>
                </div> -->
                <h4 class="card-title">List</h4>
                <hr style="width: 100%;height: 5px;background-color:#e91e63;color:#FF0066;border: 0 none;">
            </div>
            <div class="card-body ">
               <div class="row inner-menu pull-right">
                  <a href="<?php echo e(url('/admin/quotoftheday/create')); ?>" class="btn btn-success btn-sm pull-right" title="Add New Cm">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add New
                  </a>
                </div>
                </br></br>
                <div class="row">
                  <div class="col-md-12">     

                       <table class="table table-striped" id="myTable">
                        <thead>
                          <tr>
                            <th >#</th>
                            <th>Quote</th>
                            <th>Author</th>
                            <th width="25%">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
             
                            <?php $__currentLoopData = $quotoftheday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             
                             <tr>
                                  <td style="width:10% !important"><?php echo e($item['id']); ?></td>
                                    <td><?php echo e(strip_tags($item['quote'])); ?></td>
                                    <td><?php echo e(strip_tags($item['author'])); ?></td>
                                    <td>

                                        <a href="<?php echo e(url('/admin/quotoftheday/' . $item['id'] . '/edit')); ?>" title="  Edit role">
                                            <button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o"
                                                                                      aria-hidden="true"></i></button>
                                        </a>

                                        <form method="POST" action="<?php echo e(url('/admin/quotoftheday' . '/' . $item['id'])); ?>"
                                              accept-charset="UTF-8" style="display:inline">
                                            <?php echo e(method_field('DELETE')); ?>

                                            <?php echo e(csrf_field()); ?>

                                            <button type="submit" class="btn btn-danger btn-sm" title="Delete role"
                                                    onclick="return confirm(&quot;Confirm; delete?;&quot;)"><i
                                                        class="fa fa-trash-o" aria-hidden="true"></i></button>
                                        </form>
                                    </td>
          
                              </tr>
                           
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                       </table>

                  </div>
               </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



















<?php echo $__env->make('layouts.theme', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>