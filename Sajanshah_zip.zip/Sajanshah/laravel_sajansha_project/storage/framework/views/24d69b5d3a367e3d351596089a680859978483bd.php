

<?php $__env->startSection('content'); ?>


<div class="row">
    <div class="col-md-12">
        <div class="card ">
            <div class="card-header card-header-success card-header-icon">
                <!-- <div class="card-icon">
                    <i class="material-icons"></i>
                </div> -->
                <h4 class="card-title">List</h4>
                <hr style="width: 100%;height: 5px;background-color:#e91e63;color:#FF0066;border: 0 none;">
            </div>
            <div class="card-body ">
               <div class="row inner-menu pull-right">
                  <a href="<?php echo e(url('/admin/targetoftheday/create')); ?>" class="btn btn-success btn-sm pull-right" title="Add New target">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add New
                  </a>
                </div>
                </br></br>
                <div class="row">
                  <div class="col-md-12">     

                     <div class="card-body "> 
                     <ul class="nav nav-pills nav-pills-warning" role="tablist"> 
                     <li class="nav-item"> <a class="nav-link active show" data-toggle="tab" href="#link1" role="tablist"> Profile </a> </li> <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#link2" role="tablist"> Settings </a> </li> <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#link3" role="tablist"> Options </a> </li> </ul> <div class="tab-content tab-space"> <div class="tab-pane active show" id="link1"> Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits. <br> <br> Dramatically visualize customer directed convergence without revolutionary ROI. Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C users after installed base benefits. <br> <br> This is very nice. </div> <div class="tab-pane" id="link2"> Efficiently unleash cross-media information without cross-media value. Quickly maximize timely deliverables for real-time schemas. <br> <br>Dramatically maintain clicks-and-mortar solutions without functional solutions. </div> <div class="tab-pane" id="link3"> Completely synergize resource taxing relationships via premier niche markets. Professionally cultivate one-to-one customer service with robust ideas. <br> <br>Dynamically innovate resource-leveling customer service for state of the art customer service. </div> </div> </div>

                   
                  </div>
               </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>



















<?php echo $__env->make('layouts.theme', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>