<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::get('/dailyquote', 'QuotofthedayController@get_daily_quote');

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});




Route::resource('cms', 'Api\\CmsController');
Route::resource('connectwithus', 'Api\\ConnectwithusController');
Route::resource('quotoftheday', 'Api\\QuotofthedayController');
Route::resource('challengeoftheday', 'Api\\ChallengeOfTheDayController');
Route::resource('youtube', 'Api\\YoutubeController');
Route::resource('login', 'Api\LoginController');
Route::resource('passport', 'Api\\PassportController');


Route::post('dailyquote', 'Api\QuotofthedayController@get_daily_quote');
Route::post('dailychallenge', 'Api\ChallengeOfTheDayController@get_daily_challenge');
Route::post('my', 'Api\TargetOfTheDayController@my');

Route::post('get-targets', 'Api\TargetOfTheDayController@index');
Route::post('save-targets', 'Api\TargetOfTheDayController@store');
Route::post('save-targets-status', 'Api\TargetOfTheDayController@save_target_status');
Route::post('update-target-status', 'Api\TargetOfTheDayController@update');

Route::post('save-challenge-status', 'Api\ChallengeOfTheDayController@savechallengestatus');
Route::post('check-challenge-status', 'Api\ChallengeOfTheDayController@checkchallengestatus');

Route::post('check-target-status', 'Api\TargetOfTheDayController@checkTargetStatus');

Route::post('weeklyupdate', 'Api\LoginController@check_week_update_points'); //cron

Route::post('open-target-of-week', 'Api\LoginController@open_target_of_week');

Route::post('save-claim', 'Api\UserclaimsController@store');
Route::post('check-claim', 'Api\UserclaimsController@check_claim');

Route::post('quoteNotification', 'Api\LoginController@quoteNotification');

Route::get('/gift-for-claim', 'Api\UserclaimsController@get_all_gift');

Route::post('update-custom-target', 'Api\TargetOfTheDayController@update_custom_target');

Route::post('get-points', 'Api\LoginController@get_points_by_userid');

Route::post('app-update', 'Api\LoginController@app_update');