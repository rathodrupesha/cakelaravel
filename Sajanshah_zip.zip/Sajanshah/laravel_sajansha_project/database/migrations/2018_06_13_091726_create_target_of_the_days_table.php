<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTargetOfTheDaysTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        
        Schema::create('target_of_the_days', function (Blueprint $table) {
             $table->increments('id');
             $table->string('title')->nullable();
             $table->enum('type', ['1', '2','3'])->comment('1=personal,2=professional,3=family');
             $table->timestamps();
            });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('target_of_the_days');
    }
}
