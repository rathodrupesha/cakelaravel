
<div class="sidebar" data-color="rose" data-background-color="black"
     data-image="{{asset('public/images/sidebar-1.jpg')}}">
    <div class="logo">
        <a href="https://www.creative-tim.com" class="simple-text logo-mini">
             SJ
        </a>
        <a href="https://www.creative-tim.com" class="simple-text logo-normal">
            {{ config('app.name', 'Laravel') }}
        </a>
    </div>
    <div class="sidebar-wrapper">
        <div class="user">
            <div class="photo">
                <img src="../assets/img/faces/avatar.jpg"/>
            </div>
            <div class="user-info">
                <a data-toggle="collapse" href="#collapseExample" class="username">
                                <span>
                                   {{ Auth::user()->name }}
                                  <b class="caret"></b>
                                </span>
                </a>
                <div class="collapse" id="collapseExample">
                    <ul class="nav">
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                                <span class="sidebar-mini"><i class="fa fa-user" aria-hidden="true"></i></span>
                                <span class="sidebar-normal"> My Profile </span>
                            </a>
                        </li>
                  
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                <span class="sidebar-mini"><i class="fa fa-sign-out" aria-hidden="true"></i></span>
                                <span class="sidebar-normal"> Logout </span>
                            </a>

                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                @csrf
                            </form>
                        </li>
                         
                    </ul>
                </div>
            </div>
        </div>
        <ul class="nav">
            <li class="nav-item <?php if(Request::segment(1)=="home"){ echo "active";}  ?> ">
                <a class="nav-link" href="./dashboard.html">
                    <i class="material-icons">dashboard</i>
                    <p> Dashboard </p>
                </a>
            </li>
            <li class="nav-item <?php if(Request::segment(2)=="cms"){ echo "active";}  ?> ">
                <a class="nav-link" href="{{url('admin/cms')}}">
                    <i class="material-icons"><i class="fa fa-align-center"></i></i>
                    <p> CMS </p>
                </a>
            </li>
            <li class="nav-item <?php if(Request::segment(2)=="quotoftheday"){ echo "active";}  ?> ">
                <a class="nav-link" href="{{url('admin/quotoftheday')}}">
                    <i class="material-icons"><i class="fa fa-quote-left fa-2x fa-pull-left"></i></i>
                    <p>Quote Of The Day </p>
                </a>
            </li>
              <li class="nav-item <?php if(Request::segment(2)=="connectwithus"){ echo "active";}  ?> ">
                <a class="nav-link" href="{{url('admin/connectwithus/1/edit')}}">
                    <i class="material-icons"><i class="fa fa-globe" aria-hidden="true"></i></i>
                    <p>Connect With Us </p>
                </a>
            </li>
             </li>
              <li class="nav-item <?php if(Request::segment(2)=="challengeoftheday"){ echo "active";}  ?> ">
                <a class="nav-link" href="{{url('admin/challengeoftheday')}}">
                    <i class="material-icons"><i class="fa fa-hand-o-up" aria-hidden="true"></i></i>
                    <p>Challenge Of The Day </p>
                </a>
            </li>
            <li class="nav-item <?php if(Request::segment(2)=="targetoftheday"){ echo "active";}  ?> ">
                <a class="nav-link" href="{{url('admin/targetoftheday')}}">
                    <i class="material-icons"><i class="fa fa-paper-plane" aria-hidden="true"></i></i>
                    <p>Target Of The Day </p>
                </a>
            </li>
            <li class="nav-item <?php if(Request::segment(2)=="userclaims"){ echo "active";}  ?> ">
                <a class="nav-link" href="{{url('admin/userclaims1')}}">
                    <i class="material-icons"><i class="fa fa-gavel" aria-hidden="true"></i></i>
                    <p>claim History</p>
                </a>
            </li>
        </ul>
    </div>
</div>
