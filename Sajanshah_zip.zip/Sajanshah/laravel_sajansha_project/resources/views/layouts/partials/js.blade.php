<script src="{{asset('public/js/jquery.min.js')}}"></script>
<script src="{{asset('public/js/popper.min.js')}}"></script>
<script src="{{asset('public/js/bootstrap-material-design.min.js')}}"></script>
<script src="{{asset('public/js/perfect-scrollbar.jquery.min.js')}}"></script>
<script type="text/javascript"
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB2Yno10-YTnLjjn_Vtk0V8cdcY5lC4plU"></script>
<script src="{{asset('public/js/moment.min.js')}}"></script>
<script src="{{asset('public/js/bootstrap-datetimepicker.min.js')}}"></script>
<script src="{{asset('public/js/nouislider.min.js')}}"></script>
<script src="{{asset('public/js/bootstrap-selectpicker.js')}}"></script>
<script src="{{asset('public/js/bootstrap-tagsinput.js')}}"></script>
<script src="{{asset('public/js/jasny-bootstrap.min.js')}}"></script>
<script src="{{asset('public/js/modernizr.js')}}"></script>
<script src="{{asset('public/js/material-dashboard.js')}}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
<script src="{{asset('public/js/arrive.min.js')}}" type="text/javascript"></script>
<script src="{{asset('public/js/jquery.validate.min.js')}}"></script>
<script src="{{asset('public/js/chartist.min.js')}}"></script>
<script src="{{asset('public/js/jquery.bootstrap-wizard.js')}}"></script>
<script src="{{asset('public/js/bootstrap-notify.js')}}"></script>
<script src="{{asset('public/js/jquery-jvectormap.js')}}"></script>
<script src="{{asset('public/js/nouislider.min.js')}}"></script>
<script src="{{asset('public/js/jquery.select-bootstrap.js')}}"></script>
<script src="{{asset('public/js/jquery.datatables.js')}}"></script>
<script src="{{asset('public/js/sweetalert2.js')}}"></script>
<script src="{{asset('public/js/jasny-bootstrap.min.js')}}"></script>
<script src="{{asset('public/js/fullcalendar.min.js')}}"></script>
<script src="{{asset('public/js/demo.js')}}"></script>
<script type="text/javascript">
    $(document).ready(function () {
        demo.initMaterialWizard();
        demo.initDashboardPageCharts();
        demo.initCharts();
    });
</script>
<script type="text/javascript">
    $(document).ready(function () {
        demo.initVectorMap();
    });
</script>
<script src="{{asset('public/js/jquery.sharrre.js')}}">
</script>
<script>
    $(document).ready(function () {
        $('#twitter').sharrre({
            share: {
                twitter: true
            },
            enableHover: false,
            enableTracking: false,
            enableCounter: false,
            buttons: {twitter: {via: 'CreativeTim'}},
            click: function (api, options) {
                api.simulateClick();
                api.openPopup('twitter');
            },
            template: '<i class="fa fa-twitter"></i> Twitter',
            url: 'https://demos.creative-tim.com/material-kit-pro/presentation.html'
        });

        $('#facebook').sharrre({
            share: {
                facebook: true
            },
            enableHover: false,
            enableTracking: false,
            enableCounter: false,
            click: function (api, options) {
                api.simulateClick();
                api.openPopup('facebook');
            },
            template: '<i class="fa fa-facebook-square"></i> Facebook',
            url: 'https://demos.creative-tim.com/material-kit-pro/presentation.html'
        });

        $('#google').sharrre({
            share: {
                googlePlus: true
            },
            enableCounter: false,
            enableHover: false,
            enableTracking: true,
            click: function (api, options) {
                api.simulateClick();
                api.openPopup('googlePlus');
            },
            template: '<i class="fa fa-google-plus"></i> Google',
            url: 'https://demos.creative-tim.com/material-kit-pro/presentation.html'
        });
    });


    var _gaq = _gaq || [];
    _gaq.push(['_setAccount', 'UA-46172202-1']);
    _gaq.push(['_trackPageview']);

    (function () {
        var ga = document.createElement('script');
        ga.type = 'text/javascript';
        ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'https://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(ga, s);
    })();

    // Facebook Pixel Code Don't Delete
    !function (f, b, e, v, n, t, s) {
        if (f.fbq) return;
        n = f.fbq = function () {
            n.callMethod ?
                n.callMethod.apply(n, arguments) : n.queue.push(arguments)
        };
        if (!f._fbq) f._fbq = n;
        n.push = n;
        n.loaded = !0;
        n.version = '2.0';
        n.queue = [];
        t = b.createElement(e);
        t.async = !0;
        t.src = v;
        s = b.getElementsByTagName(e)[0];
        s.parentNode.insertBefore(t, s)
    }(window,
        document, 'script', '//connect.facebook.net/en_US/fbevents.js');

    try {
        fbq('init', '111649226022273');
        fbq('track', "PageView");

    } catch (err) {
        console.log('Facebook Track Error:', err);
    }
</script>
<noscript>
    <img height="1" width="1" style="display:none"
               src="https://www.facebook.com/tr?id=111649226022273&ev=PageView&noscript=1"
    />
</noscript>

<!-- CKeditor -->
<script src="https://cdn.ckeditor.com/4.7.2/standard/ckeditor.js"></script> 
<script>
   
    CKEDITOR.replace('page_description');
</script>


<!-- j query validation -->
<script type="text/javascript" src="{{ asset('public/js/jquery.validate.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('public/js/additional-methods.min.js') }}"></script>

<script type="text/javascript" src="{{ asset('public/js/custom/form-validation.js') }}"></script>


<!-- datatable -->
<script type="text/javascript" src="{{ asset('public/js/datatable/jquery.dataTables.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('public/js/datatable/dataTables.bootstrap.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('public/js/custom/datatable.js') }}"></script>


<!-- j query datepicker -->
<script type="text/javascript" src="{{ asset('public/js/datepicker/jquery-ui.js') }}"></script>

<script type="text/javascript">
$(document).ready(function() {
    $('.dateinput').datepicker({ format: "yyyy/mm/dd" });
   
}); 
</script>

<!-- j query dateRangepicker-->
<script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
<script type="text/javascript">

$('input[name="custome_daterange"]').daterangepicker({

locale: {
format:'DD/MM/YYYY'
},
//startDate: '2013-01-01',
//endDate: '2013-12-31'

});
</script>

<!-- j query tab
<script type="text/javascript" src="{{ asset('public/js/jquery.cardtabs.js') }}"></script> -->

<!-- csv export-->

<script type="text/javascript" src="{{ asset('public/js/table2csv.js') }}"></script>
<script>
$(".csv_export_button").click(function(){
	$(".csv_export_table").table2csv({
          filename: 'Sales-Report.csv',
          separator: ',',
	      newline: '\n',
	      quoteFields: true,
	      excludeColumns: '',
	      excludeRows: ''

       });
	
})
</script>
