<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <title>
        SajanShah
    </title>
    @include('layouts.partials.css')
</head>
<body>
<div class="wrapper">
    @include('layouts.partials.sidebar')
    <div class="main-panel">
        @include('layouts.partials.header')
        <div class="content">
            <div class="container-fluid">
                @include('flash::message')
                @yield('content')
            </div>
        </div>
        @include('layouts.partials.footer')
    </div>
</div>
@include('layouts.partials.plugins')
</body>
@include('layouts.partials.js')
</html>
