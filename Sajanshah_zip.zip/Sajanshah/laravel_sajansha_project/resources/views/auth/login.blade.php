@extends('layouts.app')

@section('content')

<div class="col-md-4 col-sm-6 ml-auto mr-auto">
    <form method="POST" action="{{ route('login') }}">
                        @csrf
        <div class="card card-login ">
            <div class="card-header card-header-rose text-center">
                <h4 class="card-title">Log in</h4>
            </div>
            <div class="card-body ">
                <span class="bmd-form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text">
                            <i class="material-icons">email</i>
                        </span>
                      </div>
                       <input id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}" required autofocus placeholder="Email">
                        @if ($errors->has('email'))
                            <span class="invalid-feedback">
                                <strong>{{ $errors->first('email') }}</strong>
                            </span>
                        @endif
                    </div>
                  </span>
                <span class="bmd-form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text">
                          <i class="material-icons">lock_outline</i>
                        </span>
                      </div>
                       <input id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" required placeholder="Password">
                        @if ($errors->has('password'))
                            <span class="invalid-feedback">
                                <strong>{{ $errors->first('password') }}</strong>
                            </span>
                        @endif
                    </div>
                </span>
               <span class="bmd-form-group">
                    <div class="input-group">
                      
                      <div class="form-check">
                        <label class="form-check-label" style="margin-left: 20px;">
                            <input type="checkbox" class="form-check-input" name="remember" {{ old('remember') ? 'checked' : '' }}> 
                            <span class="form-check-sign">
                                <span class="check"></span>
                            </span>
                            {{ __('Remember Me') }}.
                        </label>
                    </div>
                    </div>
                </span>
            </div>
            <div class="card-footer justify-content-center">
                <button type="submit" class="btn btn-rose btn-link btn-lg">
                    {{ __('Login') }}
                </button>
            </div>
        </div>
    </form>
</div>
@endsection
