<div class="form-group {{ $errors->has('user_id') ? 'has-error' : ''}}">
    <label for="user_id" class="col-md-4 control-label">{{ 'User Id' }}</label>
    <div class="col-md-6">
        <input class="form-control" name="user_id" type="number" id="user_id" value="{{ $userclaim->user_id or ''}}" >
        {!! $errors->first('user_id', '<p class="help-block">:message</p>') !!}
    </div>
</div><div class="form-group {{ $errors->has('gift_id') ? 'has-error' : ''}}">
    <label for="gift_id" class="col-md-4 control-label">{{ 'Gift Id' }}</label>
    <div class="col-md-6">
        <input class="form-control" name="gift_id" type="number" id="gift_id" value="{{ $userclaim->gift_id or ''}}" >
        {!! $errors->first('gift_id', '<p class="help-block">:message</p>') !!}
    </div>
</div>

<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <input class="btn btn-primary" type="submit" value="{{ $submitButtonText or 'Create' }}">
    </div>
</div>
