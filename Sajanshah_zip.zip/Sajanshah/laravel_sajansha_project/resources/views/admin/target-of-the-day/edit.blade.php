@extends('layouts.theme')
@section('content')
<div class="row">
<?php 
 if($targetoftheday['type']==1)
 {
   $type="Persoanl";

  }else if($targetoftheday['type']==2){
    $type="Professional";
  }else if($targetoftheday['type']==3){
    $type="Family";
  }

?>
    <div class="col-md-12">
        <div class="card ">
            <div class="card-header card-header-success card-header-icon">
              <!--   <div class="card-icon">
                    <i class="material-icons"></i>
                </div> -->
                <h4 class="card-title">Edit Target of the day</h4>
                <hr style="width: 100%;height: 5px;background-color:#e91e63;color:#FF0066;border: 0 none;">
            </div>
            <div class="card-body ">
                <div class="row inner-menu pull-right">
                    <a href="{{ url('/admin/targetoftheday') }}" title="Back" ><button class="btn btn-warning btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                </div>
                </br>
                <div class="row">
                  <div class="col-md-12">
                        <form method="POST" action="{{url('/admin/targetoftheday', [$targetoftheday['id']])}}" accept-charset="UTF-8" class="form-horizontal" enctype="multipart/form-data" id="validate_form">
                            {{ csrf_field() }}
                        <input type="hidden" name="_method" value="PUT">
                        <div class="form-group">
                            <!-- <label for="title" class="col-md-4 control-label">{{ 'Title' }}</label> -->
                             <div class="row">
                               <div class="col-md-2">
                                <label for="content" class=" control-label">{{ 'Type :' }}</label>
                                </div>
                               <div class="col-md-10">
                                 {{$type}}
                               </div>
                             </div>
                            
                        </div>
                        <div class="form-group ">
                         <div class="row">
                               <div class="col-md-2">
                                <label for="content" class=" control-label">{{ 'Title :' }}</label>
                                </div>
                               <div class="col-md-10">
                                    
                                     <input type="text" name="title" value=" <?php echo $targetoftheday['title'];?>" class="form-control required" id="title">
                                     
                                    {!! $errors->first('title', '<p class="help-block" style="color: red;">:message</p>') !!}
                                </div>
                          </div>
                        </div>

                        <div class="form-group" style="margin-left: 388px;">
                            <div class="col-md-4">
                                <input class="btn btn-primary" type="submit" value="Update" id="validate_submit">
                            </div>
                        </div>
                            

                        </form>
                  </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection


