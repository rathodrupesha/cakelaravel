@extends('layouts.theme')
@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card ">
            <div class="card-header card-header-success card-header-icon">
                <!-- <div class="card-icon">
                    <i class="material-icons"></i>
                    Create
                </div> -->
                <h4 class="card-title">Create Target Of Day</h4>
                <hr style="width: 100%;height: 5px;background-color:#e91e63;color:#FF0066;border: 0 none;">
            </div>
            <div class="card-body ">
                <div class="row inner-menu pull-right">
                    <a href="{{ url('/admin/targetoftheday') }}" title="Back" ><button class="btn btn-warning btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                </div> 
                </br>
                <div class="row">
                  <div class="col-md-12">
                        <form method="POST" action="{{ url('/admin/targetoftheday') }}" accept-charset="UTF-8" class="form-horizontal" enctype="multipart/form-data" id="validate_form">
                            {{ csrf_field() }}
                        
                        <div class="form-group">
                            <label for="title" class="col-md-4 control-label">{{ 'Type' }}</label>
                            <div class="col-md-12">
                                <select class="form-control required" name="type">
                                    <option value="1">Personal</option>
                                    <option value="2">Proffessional</option>
                                    <option value="3">Family</option>
                                </select>
                                {!! $errors->first('type', '<p class="help-block" style="color: red;">:message</p>') !!}
                            </div>
                        </div>

                        <div class="form-group ">
                            <label for="content" class="col-md-4 control-label">{{ 'Title' }}</label>
                            <div class="col-md-12">
                                <input class="form-control required" name="title" type="text" id="title" >
                                {!! $errors->first('title', '<p class="help-block" style="color: red;">:message</p>') !!}
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-offset-4 col-md-4">
                                <input class="btn btn-primary" type="submit" value="submit" id="validate_submit">
                            </div>
                        </div>
                            

                        </form>

                </div>
                </div> 
            </div>
        </div>
    </div>
</div>
@endsection


