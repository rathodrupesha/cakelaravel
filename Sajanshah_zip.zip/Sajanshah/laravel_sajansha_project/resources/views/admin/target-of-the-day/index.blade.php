
@extends('layouts.theme')
@section('content')


<div class="row">
    <div class="col-md-12">
        <div class="card ">
            <div class="card-header card-header-success card-header-icon">
                <!-- <div class="card-icon">
                    <i class="material-icons"></i>
                </div> -->
                <h4 class="card-title">List</h4>
                <hr style="width: 100%;height: 5px;background-color:#e91e63;color:#FF0066;border: 0 none;">
            </div>
            <div class="card-body ">
                
                <div class="row">
                  <div class="col-md-12">     
                     <div class="row inner-menu pull-right">
                        <a href="{{ url('/admin/targetoftheday/create') }}" class="btn btn-success btn-sm pull-right" title="Add New target">
                          <i class="fa fa-plus" aria-hidden="true"></i> Add New
                        </a>
                    </div>
                     <div class="card-body "> 
                       <ul class="nav nav-pills nav-pills-warning" role="tablist"> 
                       <li class="nav-item"> 
                       <a class="nav-link active show" data-toggle="tab" href="#link1" role="tablist"> Personal </a> 
                       </li> 
                       <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#link2" role="tablist"> Professional </a> 
                       </li> 
                       <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#link3" role="tablist"> Family </a> </li>
                       <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#link4" role="tablist"> Custom </a> </li>
                        </ul> 

                      <div class="tab-content tab-space"> 
                          <div class="tab-pane active show" id="link1"> 

                              
                              <table class="table table-striped myTable" >
                              <thead>
                                <tr>
                                  <th >#</th>
                                  <th>Title</th>
                                  <th width="25%">Actions</th>
                                   <th>Status</th>
                                </tr>
                              </thead>
                              <tbody>
             
                                    @foreach($targets as $item)
                                     @if($item['type'] != '1')
                                      @php continue; @endphp
                                     @endif
                                     @if($item['user_id'] != Auth::id())
                                      @php continue; @endphp
                                     @endif
                                     <tr>
                                          <td style="width:10% !important">{{ $item['id'] }}</td>
                                            <td>{{ strip_tags($item['title']) }}</td>
                                            <td style="width:20% !important;">

                                                <a href="{{ url('/admin/targetoftheday/' . $item['id'] . '/edit') }}" title="  Edit role">
                                                    <button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
                                                </a>

                                                <form method="POST" action="{{ url('/admin/targetoftheday' . '/' . $item['id']) }}"
                                                      accept-charset="UTF-8" style="display:inline">
                                                    {{ method_field('DELETE') }}
                                                    {{ csrf_field() }}
                                                    <button type="submit" class="btn btn-danger btn-sm" title="Delete role"
                                                            onclick="return confirm(&quot;Confirm; delete?;&quot;)"><i
                                                                class="fa fa-trash-o" aria-hidden="true"></i></button>
                                                </form>
                                            </td>

                                             <td style="width:20% !important;">
                                            
                                              <a href="{{ url('/admin/statusviewgeneral/'.$item['id'].'/1') }}" title="success">
                                               <span class="btn btn-success btn-sm">{{($item['target_success_count'])}}
                                               </span>
                                               </a>
                                              <a href="{{ url('/admin/statusviewgeneral/'.$item['id'].'/0') }}" title="failed"> 
                                             <span class="btn btn-danger btn-sm">{{($item['target_fail_count'])}}</span>
                                             </a>

                                           </td>
                  
                                      </tr>
                                   
                                    @endforeach
                                </tbody>
                               </table>
                          </div> 
                          <!-- -------------------------Professional---------------------------- -->

                          <div class="tab-pane" id="link2"> 
                        
                              <table class="table table-striped myTable" >
                              <thead>
                                <tr>
                                  <th >#</th>
                                  <th>Title</th>
                                  <th width="25%">Actions</th>
                                </tr>
                              </thead>
                              <tbody>
             
                                    @foreach($targets as $item)
                                     @if($item['type'] != '2' )
                                      @php continue; @endphp
                                     @endif
                                     @if($item['user_id'] != Auth::id())
                                      @php continue; @endphp
                                     @endif
                                     <tr>
                                          <td style="width:10% !important">{{ $item['id'] }}</td>
                                            <td>{{ strip_tags($item['title']) }}</td>
                                            <td style="width:20% !important;">

                                                <a href="{{ url('/admin/targetoftheday/' . $item['id'] . '/edit') }}" title="  Edit role">
                                                    <button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o"
                                                                                              aria-hidden="true"></i></button>
                                                </a>

                                                <form method="POST" action="{{ url('/admin/targetoftheday' . '/' . $item['id']) }}"
                                                      accept-charset="UTF-8" style="display:inline">
                                                    {{ method_field('DELETE') }}
                                                    {{ csrf_field() }}
                                                    <button type="submit" class="btn btn-danger btn-sm" title="Delete role"
                                                            onclick="return confirm(&quot;Confirm; delete?;&quot;)"><i
                                                                class="fa fa-trash-o" aria-hidden="true"></i></button>
                                                </form>
                                            </td>
                  
                                      </tr>
                                   
                                    @endforeach
                                </tbody>
                               </table>
 
                          </div> 

                          <!-- -------------------------Family ---------------------------- -->

                          <div class="tab-pane" id="link3"> 
                              

                             <table class="table table-striped myTable" >
                              <thead>
                                <tr>
                                  <th >#</th>
                                  <th>Title</th>
                                  <th width="25%">Actions</th>
                                </tr>
                              </thead>
                              <tbody>
             
                                    @foreach($targets as $item)
                                     @if($item['type'] != '3')
                                      @php continue; @endphp
                                     @endif
                                     @if($item['user_id'] != Auth::id())
                                      @php continue; @endphp
                                     @endif
                                     <tr>
                                          <td style="width:10% !important">{{ $item['id'] }}</td>
                                            <td>{{ strip_tags($item['title']) }}</td>
                                            <td style="width:20% !important;">

                                                <a href="{{ url('/admin/targetoftheday/' . $item['id'] . '/edit') }}" title="  Edit role">
                                                    <button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o"
                                                                                              aria-hidden="true"></i></button>
                                                </a>

                                                <form method="POST" action="{{ url('/admin/targetoftheday' . '/' . $item['id']) }}"
                                                      accept-charset="UTF-8" style="display:inline">
                                                    {{ method_field('DELETE') }}
                                                    {{ csrf_field() }}
                                                    <button type="submit" class="btn btn-danger btn-sm" title="Delete role"
                                                            onclick="return confirm(&quot;Confirm; delete?;&quot;)"><i
                                                                class="fa fa-trash-o" aria-hidden="true"></i></button>
                                                </form>
                                            </td>
                  
                                      </tr>
                                   
                                    @endforeach
                                </tbody>
                               </table>

                          </div> 

                           
                          <!-- -------------------------Custom ---------------------------- -->

                          <div class="tab-pane" id="link4"> 
                              

                             <table class="table table-striped myTable" >
                              <thead>
                                <tr>
                                  <th >#</th>
                                  <th>User Name</th>
                                  <th>User Email</th>
                                  <th>Target</th>
                                  <th>Type</th>
                                  <th width="25%">Created At</th>
                                  <th width="25%">status</th>
                                </tr>
                              </thead>
                              <tbody>
             
                                    @foreach($targets as $item)
                                     @if($item['user_id'] == Auth::id())
                                      @php continue; @endphp
                                     @endif
                                     <tr>
                                          <td style="width:10% !important">{{ $item['id'] }}</td>
                                          <td>{{ strip_tags($item['user']['name']) }}</td>
                                          <td>{{ strip_tags($item['user']['email']) }}</td>
                                          <td>{{ strip_tags($item['title']) }}</td>
                                          <td>
                                             <?php
                                             if($item['type']==1){
                                              echo "Personal";
                                             }else if($item['type']==2) {
                                              echo "Professional";
                                             }else if($item['type']==3) {
                                              echo "Family";
                                             }
                                             ?>

                                          </td>
                                      
                                           <td>
                                             {{ $item['created_at'] }}
                                           </td>

                                           <td>
                                            
                                              <a href="{{ url('/admin/statusview/' . $item['user']['id'] . '/'.$item['id'].'/1') }}" title="success">
                                               <span class="btn btn-success btn-sm">{{($item['target_success_count'])}}
                                               </span>
                                               </a>
                                              <a href="{{ url('/admin/statusview/' . $item['user']['id'] . '/'.$item['id'].'/0') }}" title="failed"> 
                                             <span class="btn btn-danger btn-sm">{{($item['target_fail_count'])}}</span>
                                             </a>

                                           </td>
                  
                                      </tr>
                                   
                                    @endforeach
                                </tbody>
                               </table>

                          </div> 

                        </div> <!-- tab-content tab-space -->

                      </div><!-- card body -->

                   
                  </div>
               </div>
            </div>
        </div>
    </div>
</div>


@endsection


















