@extends('layouts.theme')
@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card ">
            <div class="card-header card-header-success card-header-icon">
                <!-- <div class="card-icon">
                    <i class="material-icons"></i>
                </div> -->
                <h4 class="card-title">List</h4>
                <hr style="width: 100%;height: 5px;background-color:#e91e63;color:#FF0066;border: 0 none;">
            </div>
            <div class="card-body ">
               <div class="row inner-menu pull-right">
                  <a href="{{ url('/admin/challengeoftheday/create') }}" class="btn btn-success btn-sm pull-right" title="Add New Cm">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add New
                  </a>
                </div>
                </br></br>
                <div class="row">
                  <div class="col-md-12">     

                       <table class="table table-striped" id="myTable">
                        <thead>
                          <tr>
                            <th>#</th>
                            <th>Title</th>
                            <th>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
             
                            @foreach($challengeoftheday as $item)
                             
                             <tr>
                                    <td style="width:10% !important">{{$item['id'] }}</td>
                                    <td style="width:60% !important">{{ $item['title'] }}</td>
                                   
                                    <td style="width:30% !important">

                                        <a href="{{ url('/admin/challengeoftheday/' . $item['id'] . '/edit') }}" title="  Edit role">
                                            <button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o"
                                                                                      aria-hidden="true"></i></button>
                                        </a>

                                        <form method="POST" action="{{ url('/admin/challengeoftheday' . '/' . $item['id']) }}"
                                              accept-charset="UTF-8" style="display:inline">
                                            {{ method_field('DELETE') }}
                                            {{ csrf_field() }}
                                            <button type="submit" class="btn btn-danger btn-sm" title="Delete role"
                                                    onclick="return confirm(&quot;Confirm; delete?;&quot;)"><i
                                                        class="fa fa-trash-o" aria-hidden="true"></i></button>
                                        </form>
                                    </td>
                                
                              </tr>
                           
                            @endforeach
                        </tbody>
                       </table>

                  </div>
               </div>
            </div>
        </div>
    </div>
</div>
@endsection


















