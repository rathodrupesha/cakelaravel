$(document).ready(function () {
    $('#myTable').DataTable();
    $('.myTable').DataTable();
																																																															
});
    

