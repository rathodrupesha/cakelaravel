$(document).ready(function () {

    $("#validate_submit").click(function () {
        $("#validate_form").validate();
    });


});//doc
