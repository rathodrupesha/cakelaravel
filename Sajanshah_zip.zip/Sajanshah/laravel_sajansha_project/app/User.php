<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password','device_id'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function targets()
    {
        return $this->hasMany(TargetOfTheDay::class,'user_id','id');
    }

    public function targetStatus()
    {
        return $this->hasMany(TargetStatus::class,'user_id','id');
    }

    public function challengestatus()
    {
        return $this->hasMany(challenge_status::class,'user_id','id');
    }

    public function userclaim()
    {
        return $this->hasMany(Userclaim::class,'user_id','id');
    }
}
