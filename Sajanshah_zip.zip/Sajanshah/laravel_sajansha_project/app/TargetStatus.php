<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TargetStatus extends Model
{
    protected $table = "target_status";

    protected $guarded = [];

    public function user()
    {
    	return $this->belongsTo(User::class, 'user_id', 'id');
    }

    public function targets()
    {
        return $this->belongsTo(TargetOfTheDay::class,'user_id','id');
    }
}
