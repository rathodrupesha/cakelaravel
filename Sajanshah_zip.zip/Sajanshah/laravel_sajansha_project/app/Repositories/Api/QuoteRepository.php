<?php
namespace App\Repositories\Api;
use App\Quotoftheday;
use App\User;

class QuoteRepository{

 var $model;
 var $user_model;
 function __construct(Quotoftheday $Quotoftheday,User $user){

     $this->model=$Quotoftheday;
     $this->user_model=$user;
 }

 public function getAll()
 {
     
     return $this->model->get()->toArray();
 }

public function delete($id){

$this->model->destroy($id);

}

public function insertquote($requestData){

$this->model->create($requestData);

}

public function editview($id){


 $dataById=$this->model->find($id)->toArray();

 return $dataById;

}

public function updatequote($requestData,$id){


 $dataById=$this->model->find($id)->toArray();
 $QuoteUpdate = $this->model->findOrFail($id);
 $QuoteUpdate->update($requestData);
 

}

public function checkemail($email)
 {
     $is_exist=$this->user_model->where('email', $email)->get()->toArray();
     
      if(count($is_exist)>0){
      	return $is_exist[0]['created_at'];
      }else{
      	return "noemail";
      }
     //return $this->model->where('email', $email)->get()->toArray();
 }



}//EOF

?>