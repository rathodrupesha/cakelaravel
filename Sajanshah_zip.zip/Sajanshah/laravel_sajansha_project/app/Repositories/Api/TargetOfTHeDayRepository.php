<?php
namespace App\Repositories\Api;
use App\TargetOfTheDay;
use App\User;
use Carbon\Carbon;
use App\TargetStatus;

class TargetOfTHeDayRepository {

 	protected $model;
 	protected $user;

 	function __construct(TargetOfTheDay $TargetOfTheDay,User $user,TargetStatus $target_status)
 	{
	    $this->model=$TargetOfTheDay;
	    $this->user=$user;
	    $this->target_status = $target_status;
 	}

	public function getAllTargets($request)
	{
	    // return $this->model->whereDoesntHave('targetStatus',function($q)use($request){
		   //  	$q->whereUserId($request->user_id);
		   //  })->orWhere(function($e)use($request){
		   //  	$e->where(function($w) use ($request){
			  //   	$w->where('created_at', '>=', Carbon::today())->whereUserId($request->user_id);
			  //   })->orWhere('user_id',1);
		   //  })->withCount(['targetStatus'=>function($q) use($request) {
		   //  	$q->where('created_at', '>=', Carbon::today())->whereUserId($request->user_id);
		   //  }])->with('targetStatus')->get();

		return $this->model->where(function($e)use($request){
		    	$e->where(function($w) use ($request){
			    	$w->whereUserId($request->user_id);
			    })->orWhere('user_id',1);
		    })->withCount(['targetStatus'=>function($q) use($request) {
		    	$q->where('created_at', '>=', Carbon::today())->whereUserId($request->user_id);
		    }])->with('targetStatus')->get();
	}

	public function store($request_data)
	{
	 $target_ids=json_decode($request_data['target_id']);
	
     //$target_ids=explode(",",$request_data['target_id']); 
     $data=array();
     for ($i=0; $i <count($target_ids) ; $i++) { 
     	$multiItem=array('user_id'=>$request_data['user_id'], 'target_id'=>$target_ids[$i],'status'=>$request_data['status'],'created_at'=>date("Y-m-d H:i:s"),'updated_at'=>date("Y-m-d H:i:s"));
     	array_push($data,$multiItem);
     }
		
      $this->target_status->insert($data); 
		
	}

	public function store_target($request_data)
	{
		
		 $TargetOfTheDay = new TargetOfTheDay;
		 $TargetOfTheDay->user_id=$request_data['user_id'];
		 $TargetOfTheDay->title=$request_data['title'];
		 $TargetOfTheDay->type=$request_data['type'];
		 $TargetOfTheDay->save();
		 return $TargetOfTheDay->id;
    // $this->$this->model->create($request_data); 
		
	}

	public function update($request)
	{
		$target = $this->target_status->whereTargetId($request->target_id)->whereUserId($request->user_id)->where('created_at', '>=', Carbon::today())->first();
		if($target)
		{
			$target->status = $request->status;
			$target->update();
		}
		else
		{
			$data = $request->all();
			$this->target_status->create($data);
		}
		
	}

   public function update_custom_target($id,$title){

   	    $passport= $this->model::find($id);
        if($passport)
        {
	        $passport->title=$title;
	       
	        $passport->save();
	        $updatedData= $this->model::find($id)->toArray();
	        return $updatedData;
        }else{
        	return array();
        }
   }



	public function check_target_status($user_id,$target_id){
 
     $target_ids=explode(",",$target_id);
     return $this->target_status->where('user_id',$user_id)->whereIn('target_id',$target_ids)->get()->toArray();

  
    }

 public function getAllTargetsByType($type){
 
    return $this->model->where('type','=',$type)
                       ->where('user_id','=',1)
                       ->get()->toArray();

  }

  public function getAllCustomByUserId($user_id){

  	return $this->model->where('user_id','=',$user_id)
  	                   ->where('created_at', '>=', Carbon::today())
                       ->get()->toArray();
  }


  public function getPointsByUserId($user_id){
   $is_exist=$this->user->where('id', $user_id)->get()->toArray();
     
      if(count($is_exist)>0){
        return $is_exist[0]['points'];
      }else{
        return "unauthosired";
      }

}



  public function checkAllTargetOfUser($user_id){

  	return $this->target_status->where('user_id','=',$user_id)
  	                   ->where('created_at', '>=', Carbon::today())
                       ->get()->toArray();
  }

}

?>
