<?php
namespace App\Repositories\Api;
use App\Connectwithus;

class ConnectusRepository{

  var $model;
 function __construct(Connectwithus $Connectwithus){

     $this->model=$Connectwithus;
 }

 public function getAll()
 {
     
     return $this->model->get()->toArray();
 }

public function delete($id){

$this->model->destroy($id);

}

public function insertcms($requestData){

$this->model->create($requestData);

}

public function editview($id){


 $dataById=$this->model->find($id)->toArray();

 return $dataById;

}

public function updateconnectus($requestData,$id){


 $dataById=$this->model->find($id)->toArray();
 $cm = $this->model->findOrFail($id);
 $cm->update($requestData);
 

}


}//EOF

?>
