<?php
namespace App\Repositories\Api;
use App\User;

class LoginRepository{

 var $model;
 var $user_model;
 function __construct(User $user){

    
     $this->user_model=$user;
 }

public function check_valid_email($email){
  	
   $is_valid=$this->user_model->where('email',$email)->get()->toArray();
   
    if(count($is_valid)>0){
    	return $is_valid;
    }else{
    	return false;
    }
}

public function createuser($requestData){

	$last_insert_id=$this->user_model->create($requestData)->id;
	if($last_insert_id>0){
	  $last_insert_row=$this->user_model->where('id',$last_insert_id)->get()->toArray();
	  return $last_insert_row; 
	}else{
		return flase;
	}
}

public function getUserById($user_id){
    
    $getData=$this->user_model->where('id','=',$user_id)->get()->toArray();
   
    if(count($getData)>0){
      return $getData;
    }else{
      return false;
    }
}


public function get_Registration_Date(){
    
    $getData=$this->user_model->where('role_id','!=',1)->get()->toArray();
   
    if(count($getData)>0){
      return $getData;
    }else{
      return false;
    }
}


public function weekly_updatePoints_of_User($user_id,$weekly_update_points){

  $this->user_model->where('id','=',$user_id)->update(array('points' =>$weekly_update_points));

}

public function update_new_created_at_and_points($user_id,$today,$points){

  $this->user_model->where('id','=',$user_id)->update(array('points' =>$points,'new_created_at'=>$today));

}

public function checkemail($email)
 {
     $is_exist=$this->user_model->where('email', $email)->get()->toArray();
     
      if(count($is_exist)>0){
        return $is_exist[0]['created_at'];
      }else{
        return "noemail";
      }
     //return $this->model->where('email', $email)->get()->toArray();
 }


public function isvalidUser($user_id){
 $is_exist=$this->user_model->where('id', $user_id)->get()->toArray();
     
      if(count($is_exist)>0){
        return $is_exist[0]['points'];
      }else{
        return "unauthosired";
      }

}


public function update_device_id($email,$device_id){

  $this->user_model->where('email','=',$email)->update(array('device_id' =>$device_id));

}


}//EOF

?>
