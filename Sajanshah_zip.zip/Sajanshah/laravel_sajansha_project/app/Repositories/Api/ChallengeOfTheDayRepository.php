<?php
namespace App\Repositories\Api;
use App\ChallengeOfTheDay;
use App\User;
use App\challenge_status;

class ChallengeOfTheDayRepository{

  var $model;
  var $challenge_status_model;
 function __construct(ChallengeOfTheDay $ChallengeOfTheDay,User $user,challenge_status $challenge_status){

     $this->model=$ChallengeOfTheDay;
     $this->user_model=$user;
     $this->challenge_status_model=$challenge_status;
 }

 public function getAll()
 {
     
     return $this->model->get()->toArray();
 }

public function delete($id){

$this->model->destroy($id);

}
 
public function insertchallenge($requestData){

$this->model->create($requestData);

}

public function editview($id){


 $dataById=$this->model->find($id)->toArray();

 return $dataById;

}

public function updatechallenge($requestData,$id){


 $dataById=$this->model->find($id)->toArray();
 $cm = $this->model->findOrFail($id);
 $cm->update($requestData);
 

}


public function checkemail($email)
{
     $is_exist=$this->user_model->where('email', $email)->get()->toArray();
     
      if(count($is_exist)>0){
      	return $is_exist[0]['created_at'];
      }else{
      	return "noemail";
      }
     //return $this->model->where('email', $email)->get()->toArray();
 }


 
public function insert_challange_status($requestData){

  $this->challenge_status_model->create($requestData);

}


public function update_point_counter($user_id){
       
  $user= $this->user_model->find($user_id);
  $user->points=$user->points+10;
  $user->save();
  return $user->points;

}


public function check_challange_status($user_id,$challenge_id){

 return $this->challenge_status_model->where('user_id',$user_id)->where('challenge_id',$challenge_id)->get()->toArray();

  
}


}//EOF

?>
