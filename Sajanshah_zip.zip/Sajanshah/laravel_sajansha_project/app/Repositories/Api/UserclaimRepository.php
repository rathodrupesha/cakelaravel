<?php
namespace App\Repositories\Api;

use App\Userclaim;
use App\Gift;
use App\User;

class UserclaimRepository{

  var $model;
 function __construct(Userclaim $Userclaim,Gift $gift,User $User){

     $this->model=$Userclaim;
     $this->gift_model=$gift;
     $this->user_model=$User;
 }

/* insert claim */
public function insertclaim($requestData){

    $this->model->create($requestData);

    $userData= $this->user_model::find($requestData['user_id']);
    $userData->points=$userData->points-$requestData['claim_points'];
    $userData->save();
   
    return $userData->points;
}

 public function checkclaim($user_id,$gift_id,$is_deleted,$claim_status){

 	 $is_calim=$this->model->where('user_id',$user_id)
 	                    ->where('gift_id',$gift_id)
 	                    ->where('is_deleted',$is_deleted)
 	                    ->where('claim_status',$claim_status)
 	                    ->get()->toArray();

 	  if(count($is_calim)>0){
 	  	return "claimed";

 	  }else{
 	  	return "noclaimed";
 	  }                  
 }

public function flush_claim_of_lastweek($user_id){

  $this->model->where('user_id', '=',$user_id)->update(['is_deleted' =>1]);

}



public function getAllgift()
 {
     
     //return $this->gift_model->with('userclaim')->get()->toArray();
     return $this->gift_model->get()->toArray();
 }


public function get_Claimsdata_ByUserId($user_id)
 {
     
     return $this->model->where('user_id',$user_id)
                         ->where('is_deleted',0)
                         ->where('claim_status',1)
                        ->get(['gift_id','claim_status'])->toArray();
 }





 public function getAll()
 {
     
     return $this->model->get()->toArray();
 }

public function delete($id){

$this->model->destroy($id);

}



public function editview($id){


 $dataById=$this->model->find($id)->toArray();

 return $dataById;

}

public function updatecms($requestData,$id){


 $dataById=$this->model->find($id)->toArray();
 $cm = $this->model->findOrFail($id);
 $cm->update($requestData);
 

}


}//EOF

?>
