<?php
namespace App\Repositories\Admin;
use App\ChallengeOfTheDay;

class ChallengeOfTheDayRepository{

  var $model;
 function __construct(ChallengeOfTheDay $ChallengeOfTheDay){

     $this->model=$ChallengeOfTheDay;
 }

 public function getAll()
 {
     
     return $this->model->get()->toArray();
 }

public function delete($id){

$this->model->destroy($id);

}

public function insertchallenge($requestData){

$this->model->create($requestData);

}

public function editview($id){


 $dataById=$this->model->find($id)->toArray();

 return $dataById;

}

public function updatechallenge($requestData,$id){


 $dataById=$this->model->find($id)->toArray();
 $cm = $this->model->findOrFail($id);
 $cm->update($requestData);
 

}


}//EOF

?>
