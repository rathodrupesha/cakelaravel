<?php
namespace App\Repositories\Admin;
use App\Quotoftheday;

class QuoteRepository{

 var $model;
 function __construct(Quotoftheday $Quotoftheday){

     $this->model=$Quotoftheday;
 }

 public function getAll()
 {
     
     return $this->model->get()->toArray();
 }

public function delete($id){

$this->model->destroy($id);

}

public function insertquote($requestData){

$this->model->create($requestData);

}

public function editview($id){


 $dataById=$this->model->find($id)->toArray();

 return $dataById;

}

public function updatequote($requestData,$id){


 $dataById=$this->model->find($id)->toArray();
 $QuoteUpdate = $this->model->findOrFail($id);
 $QuoteUpdate->update($requestData);
 

}


}//EOF

?>