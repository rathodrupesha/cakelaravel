<?php
namespace App\Repositories\Admin;

use App\Userclaim;

class UserclaimRepository{

  var $model;
 function __construct(Userclaim $Userclaim){

     $this->model=$Userclaim;
 }

 public function getAll()
 {
    
     return $this->model->with(['user','gift'])->get()->toArray();
 }

public function delete($id){

$this->model->destroy($id);

}

public function insertclaim($requestData){

$this->model->create($requestData);

}

public function editview($id){


 $dataById=$this->model->find($id)->toArray();

 return $dataById;

}

public function updatecms($requestData,$id){


 $dataById=$this->model->find($id)->toArray();
 $cm = $this->model->findOrFail($id);
 $cm->update($requestData);
 

}


}//EOF

?>
