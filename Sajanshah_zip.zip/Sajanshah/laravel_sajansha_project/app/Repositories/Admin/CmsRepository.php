<?php
namespace App\Repositories\Admin;
use App\Cm;

class CmsRepository{

  var $model;
 function __construct(Cm $Cms){

     $this->model=$Cms;
 }

 public function getAll()
 {
     
     return $this->model->get()->toArray();
 }

public function delete($id){

$this->model->destroy($id);

}

public function insertcms($requestData){

$this->model->create($requestData);

}

public function editview($id){


 $dataById=$this->model->find($id)->toArray();

 return $dataById;

}

public function updatecms($requestData,$id){


 $dataById=$this->model->find($id)->toArray();
 $cm = $this->model->findOrFail($id);
 $cm->update($requestData);
 

}


}//EOF

?>
