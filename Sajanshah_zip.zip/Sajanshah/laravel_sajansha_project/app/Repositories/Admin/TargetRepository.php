<?php
namespace App\Repositories\Admin;
use App\TargetOfTheDay;
use App\TargetStatus;

class TargetRepository{

 var $model;
 var $target_status_model;
 function __construct(TargetOfTheDay $TargetOfTheDay,TargetStatus $TargetStatus){

     $this->model=$TargetOfTheDay;
     $this->target_status_model=$TargetStatus;
 }

 public function getAllPesrsonal()
 {
    /*$auth_user=\Auth::user()->id;
    return $this->model->where('type',1)
                       ->where('user_id',$auth_user)
                      ->get()->toArray();*/
    $auth_user=\Auth::user()->id;
    return $this->model->with(['user'])->withCount(['targetStatus as target_success_count'=>function($q){
      $q->whereStatus('1');
    }, 'targetStatus as target_fail_count'=>function($q){
      $q->whereStatus('0');
    }])->get()->toArray();
 }

 public function getAllProffesional()
 {
    $auth_user=\Auth::user()->id;
    return $this->model->where('type',2)
                       ->where('user_id',$auth_user)
                      ->get()->toArray();
 }

 public function getAllFamily()
 {
    $auth_user=\Auth::user()->id;
    return $this->model->where('type',3)
                       ->where('user_id',$auth_user)
                      ->get()->toArray();
 }

public function delete($id){

$this->model->destroy($id);

}

public function insertTarget($requestData){

$this->model->create($requestData);

}

public function editview($id){


 $dataById=$this->model->find($id)->toArray();

 return $dataById;

}

public function updateTarget($requestData,$id){

 $dataById=$this->model->find($id)->toArray();
 $TargetUpdate = $this->model->findOrFail($id);
 $TargetUpdate->update($requestData);
 

}

public function getcustome_target()
{
    $auth_user=\Auth::user()->id;
    return $this->model->with(['user'])
                       ->where('user_id','!=',$auth_user)
                      ->get()->toArray();

}

public function getAllstatus(){

	return $this->target_status_model->with('user')->get()->toArray();
}


public function getTargetStatusOfUser($user_id,$target_id,$status){

  return $this->target_status_model->where('user_id',$user_id)
                                   ->where('target_id',$target_id) 
                                   ->where('status',$status)
                                    ->get()->toArray();
} 



public function getTargetStatusOf_targetWise($target_id,$status){

  return $this->target_status_model->with('user')
                                   ->where('target_id',$target_id) 
                                   ->where('status',$status)
                                    ->get()->toArray();
} 



}//EOF

?>
