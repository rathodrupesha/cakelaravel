<?php
/**
 * Created by PhpStorm.
 * User: Rupesh
 * Date: 5/7/17
 * Time: 4:01 PM
 */

namespace App\Repositories\Admin;

use App\User;

/**
 * Class SettingsRepository
 * @package App\Repositories\Backend
 */
class UsersRepository
{
    /**
     * UsersRepository constructor.
     * @param \App\Models\Setting $setting
     */
    function __construct(User $user)
    {
        $this->model = $user;
    }

    /**
     * @return mixed
     */
    public function getAll()
    {
        return $this->model->with('role')->paginate(25);
    }

 

    public function update($request)
    {
        $userdata =$this->model->find($request['id']);
        // $this->model->update($request);
        $userdata->name=$request['name'];
        $userdata->email=$request['email'];
        $userdata->role_id=$request['role_id'];
        
        $userdata->save();
    }


    /**
     * @param $where
     * @return mixed
     */
    public function isExist($where)
    {
        return $this->model->where($where)->first();
    }

    /**
     * @param $data
     */
    public function store($data)
    {
        
     $this->model->create($data);

    }


    public function getrole()
    {
       return $Roledata=\App\Role::all()->toArray();

    }

     public function destroyById($id)  
    {

        $deletedata = $this->model->find($id);
        $deletedata->delete();
        
    }

    public function getUserById($id)  
    {
       
        $Userdata = $this->model->find($id)->toArray();
        return $Userdata;
        
    }

     public function checkemail_isExists($email,$id)
     {
       $emailRecord=$this->model->where('id', '!=', $id)
                   ->where('email', '=', $email)
                   ->get()->toArray();
        if(count($emailRecord)>0){

            $isPresent="yes";
        }else{
            $isPresent="no";

        }    
        return $isPresent; 

     }

     public function  getAllSalesPerson()
    {
        $Only_SalesPerson_Data=$this->model->where('role_id','=', 3)
                                  ->get()->toArray();
        return $Only_SalesPerson_Data;
    }
    
}
