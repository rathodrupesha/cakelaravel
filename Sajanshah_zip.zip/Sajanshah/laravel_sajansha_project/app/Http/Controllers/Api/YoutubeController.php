<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

/* json resposne*/
use Illuminate\Http\Response;

class YoutubeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    { 
        

        /* Get videos from channel by YouTube Data API */
    	$API_key    = config('constants.youtube.api_key');
    	$channelID  = config('constants.youtube.channel_id');
    	//$maxResults = 10;
     
        $videoList = json_decode(file_get_contents('https://www.googleapis.com/youtube/v3/search?order=date&part=snippet&maxResults=50&channelId='.$channelID.'&key='.$API_key.''));
      
       //echo "<pre>"; print_r($videoList); exit();
        $newArry=array();

        foreach ($videoList->items as $key => $value) {

      if(!empty($value->id->videoId))
      {
          /* Get video data like duraton from video id by YouTube Data API */
          $videodata = json_decode(file_get_contents('https://www.googleapis.com/youtube/v3/videos?id='.$value->id->videoId.'&part=contentDetails&key='.$API_key.''));
       
         $stamp = $videodata->items[0]->contentDetails->duration;
         $formated_stamp = str_replace(array("PT","H","M","S"), array("",":",":",""),$stamp);
         $videodata->items[0]->contentDetails->duration=$formated_stamp;
         
         /* Get video data like counters from video id by YouTube Data API */
          $counter = json_decode(file_get_contents('https://www.googleapis.com/youtube/v3/videos?id='.$value->id->videoId.'&part=statistics&key='.$API_key.''));

          

           $newArry[$key]['video_id']=$value->id->videoId; 
           $newArry[$key]['title']=$value->snippet->title; 
           $newArry[$key]['descriptions']=$value->snippet->description;
           $newArry[$key]['publishedAt']=$this->time_elapsed_string($value->snippet->publishedAt);//call fun
           $newArry[$key]['thumbnails']=$value->snippet->thumbnails->medium;
           $newArry[$key]['video_url']="https://www.youtube.com/watch?v=".$value->id->videoId;
           $newArry[$key]['video_data']=$videodata->items[0]->contentDetails;
           $newArry[$key]['counter']=$counter->items[0]->statistics;

        }
      }      
        return response()->json(['status' => Response::HTTP_OK,'message'=>'success','data' => $newArry]
                );
      
    }
/* function for convert date time to ago*/
public function time_elapsed_string($datetime, $full = false) {
    $now = new \DateTime;
    $ago = new \DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
