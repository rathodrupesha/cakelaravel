<?php

namespace App\Http\Controllers\Api;

use App\Http\Requests;
use App\Http\Controllers\Controller;

/* pushnotification library */
use App\Services\PushNotification;

/* model */
use App\User;
use App\Setting;

/* request*/
use Illuminate\Http\Request;
use App\Http\Requests\CmsRequest;

/* repositiry */
use App\Repositories\Api\LoginRepository;
use App\Repositories\Api\UserclaimRepository;
use App\Repositories\Api\QuoteRepository;

/* json resposne*/
use Illuminate\Http\Response;

class LoginController extends Controller
{
    protected $user_repo; 

    function __construct(LoginRepository $QuoteRepository,UserclaimRepository $UserclaimRepository, PushNotification $PushNotification,QuoteRepository $quote){

         //$this->middleware('auth');
         $this->user_repo=$QuoteRepository;
         $this->userclaim_repo=$UserclaimRepository;
         $this->pushNotification_lib=$PushNotification;
         $this->quote_repo=$quote;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */

   public function index(Request $request)
  {
      $email = $request->input('email'); 
      $device_id = $request->input('device_id');
       if(!isset($email) || empty($email) || !isset($device_id) || empty($device_id)){
         return response()->json(['status' =>400,'message'=>'All Fields are Required','data' =>'']
            );
        }else
        {
              $data=$this->user_repo->check_valid_email($email);
             
              if($data==false){
                    //email not found in db then add & success
                    $requestData = $request->all();
                    $data=$this->user_repo->createuser($requestData);

                   return response()->json(['status' =>Response::HTTP_OK,'message'=>'user create successfully','data' =>$data]);
              }else{
                  //alreadyexist
                //return response()->json(['status' =>400,'message'=>'Email Already Exists.','data' =>$data]);

                /* update device id */
                $updateDeviceId=$this->user_repo->update_device_id($email,$device_id);

                return response()->json(['status' =>Response::HTTP_OK,'message'=>'login successfully.','data' =>$data]);
              }

         }
       
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {   
        return view('admin.cms.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(CmsRequest $request)
    {  
        $requestData = $request->all();
        $cms=$this->cms_repo->insertcms($requestData);
  
        // Cm::create($requestData);
        flash('Cms created successfully.');
        return redirect('admin/cms');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $cm = Cm::findOrFail($id);

        return view('admin.cms.show', compact('cm'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $cm=$this->cms_repo->editview($id);
        return view('admin.cms.edit', compact('cm'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(CmsRequest $request, $id)
    {
        
        $requestData = $request->all();
       
        $cm=$this->cms_repo->updatecms($requestData,$id);
      
        flash('Cms Updated Successfully.');
        return redirect('admin/cms');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        $cms=$this->cms_repo->delete($id);
        flash('Deleted Successfully.');
        return redirect('admin/cms');
    }

 
     public function check_week_update_points()
    {
        $today = date("Y-m-d H:i:s");
        $data=$this->user_repo->get_Registration_Date();
        if($data==true){
           
             foreach ($data as $key => $value) {
           
                    if($value['new_created_at'] !='' && !empty($value['new_created_at'])){
                      
                        $datetime1 = new \DateTime($value['new_created_at']); //new created reg date
                    }else{
                        
                        $datetime1 = new \DateTime($value['created_at']); //original reg date
                    }
                   
                     
                     $datetime2 = new \DateTime($today);
                     $interval = $datetime1->diff($datetime2);
                     $days=$interval->format('%a'); 
                    
                     $oneweekdays=7;
                     $number=($days)/($oneweekdays); 
                     
                     if($number<12)
                     {
                         if (strpos($number,'.') !== false) {

                             //echo 'float';  if float value then week not complated
                           }else {
                           // echo 'integer'; if integer value then week  complated

                             $weekly_update_points=$number*100;

                             $this->user_repo->weekly_updatePoints_of_User($value['id'],$weekly_update_points); 
                             //flush claim of user of last week
                             $this->userclaim_repo->flush_claim_of_lastweek($value['id']);
                             
                          } 

                     }
                     else
                     {
                        // if 12 week complate then cycle start further 
                      $points=0;  
                      $this->user_repo->update_new_created_at_and_points($value['id'],$today,$points);
                       
                      //flush claim of user of last week or all claim bcoz cycle start further
                      $this->userclaim_repo->flush_claim_of_lastweek($value['id']);

                     }

             }

        }
    }

   

    public function open_target_of_week(Request $request)
    {

       

        $today = date("Y-m-d H:i:s");
        $user_id = $request->input('user_id');

               
        if(!isset($user_id) || empty($user_id))
        {

          return response()->json(['status' =>400,'message'=>'All fields are required.','data' =>array()]
            ); 

         }
        else
        {
             $data=$this->user_repo->getUserById($user_id);

            if($data!=false)
            {
               
               if($data[0]['new_created_at'] !='' || !empty($data[0]['new_created_at']))
               {
                
                 $datetime1 = new \DateTime($data[0]['new_created_at']); //new created reg date
               }else{
                
                 $datetime1 = new \DateTime($data[0]['created_at']); //original reg date
               }
                   
                     
               $datetime2 = new \DateTime($today);
               $interval = $datetime1->diff($datetime2);
               $days=$interval->format('%a'); 
               
               $oneweekdays=7;
               $number=($days)/($oneweekdays);
               //echo $number; exit();
               if($number>=0 && $number<=1){
                  $opentarget=1;
               }else if($number>1 && $number<=3){
                  $opentarget=2;
               }else if($number>3 && $number<=5){
                  $opentarget=3;
               }else if($number>5 && $number<=7){
                  $opentarget=4;
               }else if($number>7 && $number<=9){
                  $opentarget=5;
               }else if($number>9 && $number<=11){
                  $opentarget=6;
               }else if($number>11 && $number<=12){
                  $opentarget=7;
               }
               
               /* already claim gift_ids */
                 $AlreadyCalimed_array=array();
                  $claim_status_of_all_target=$this->userclaim_repo->get_Claimsdata_ByUserId($user_id);
                  foreach ($claim_status_of_all_target as $key => $value) {
                     $AlreadyCalimed_array[]=$value['gift_id'];
                  }
       
              /* end */



                return response()->json(['status' =>200,'message'=>'success','open_target' =>$opentarget,'claim_status'=>$AlreadyCalimed_array]
                );

            }
            else
            {

              return response()->json(['status' =>400,'message'=>'invalid user id so user not found.','open_target' =>0,'claim_status'=>array()]
                );
            }

        }

    }


  public function quoteNotification(Request $request)
  {

        $today=date('Y-m-d');
        $quote_data=$this->quote_repo->getAll();
                
        foreach ($quote_data as $key => $value) {

          $quote_Array[$key]=$value['quote']; 
          $autor_Array[$key]=$value['author']; 
        }
       
        $Userdata=$this->user_repo->get_Registration_Date();
       
        $fcm_response=array();
        foreach ($Userdata as $key => $value) {

            $reg_date=$value['created_at'];
            $devices=$value['device_id'];

            if(!empty($devices))
            {  
                $strToTime_reg_date = strtotime($reg_date);
                $strToTime_today = strtotime($today);

                $days_diffrence = ceil(abs($strToTime_today - $strToTime_reg_date) / 86400)-1;

                 $data=array();
                 if($days_diffrence<count($quote_Array))
                 {
                    $quote=$quote_Array[$days_diffrence];
                    $author=$autor_Array[$days_diffrence];

                 }else{
                    $ans=ceil(($days_diffrence)%(count($quote_Array)));
                    $quote=$quote_Array[$ans];
                    $author=$autor_Array[$ans];
                  
                 }

                $message=$quote." - ".$author;
                $token=[$devices]; 
                $fcm_response[$devices]=$this->pushNotification_lib->sendPushNotificationToFCMSever($token,$message,'123');
            }
        } 
          
          echo json_encode($fcm_response);
           // return response()->json([$fcm_response]
           //      );
  } 



  public function get_points_by_userid(Request $request){

    $user_id = $request->input('user_id');

               
    if(!isset($user_id) || empty($user_id))
    {

      return response()->json(['status' =>400,'message'=>'All fields are required.','points' =>-1]
        ); 

     }
    else
    {
       $isvalidUser=$this->user_repo->isvalidUser($user_id);
       if($isvalidUser!="unauthosired"){

        return response()->json(['status' =>200,'message'=>'success','points' =>$isvalidUser]); 

       }else{
        
        return response()->json(['status' =>400,'message'=>'Unauthorised user','points' =>-1]); 
 
       }


    }

  }//EOF


    public function app_update(Request $request){

      $phone_type = $request->input('phone_type');
      $version = $request->input('version');

               
    if(!isset($phone_type) || empty($phone_type) || !isset($version) || empty($version))
    {

      return response()->json(['status' =>400,'message'=>'All fields are required.','version' =>'','force_update' =>'']
        ); 

    }
    else
    {     
       $alredy_exist_version=Setting::where('phone_type',$phone_type)->first()->toArray();
      

       // if($alredy_exist_version['version']==$version){

       //   $force_update=0;
       //   $msg="App version is same.";

       // }else{

       //   $force_update=1; 
       //   $msg="App version is updated.";
       //   $update_version=Setting::where('phone_type',$phone_type)->update(['force_update' =>$force_update,'version'=>$version]);
         
       // }

       return response()->json(['status' =>200,'message'=>'get version','version' =>$alredy_exist_version['version'],'force_update' =>$alredy_exist_version['force_update']]
        ); 

    } 

  } 


}//EOC
