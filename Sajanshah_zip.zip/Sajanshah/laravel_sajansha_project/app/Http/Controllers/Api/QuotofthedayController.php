<?php

namespace App\Http\Controllers\Api;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Quotoftheday;

/* request*/
use Illuminate\Http\Request;
use App\Http\Requests\QuoteRequest;

/* repositiry */
use App\Repositories\Api\QuoteRepository;

/* json resposne*/
use Illuminate\Http\Response;

class QuotofthedayController extends Controller
{

    protected $quote_repo; 

    function __construct(QuoteRepository $QuoteRepository){

         //$this->middleware('auth');
         $this->quote_repo=$QuoteRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $data=$this->quote_repo->getAll();
         return response()->json(['status' => Response::HTTP_OK,'message'=>'success','data' => $data]
            );
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('admin.quotoftheday.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(QuoteRequest $request)
    {
        
        $requestData = $request->all();

        $quotoftheday=$this->quote_repo->insertquote($requestData);
  
        flash('Quote created successfully.');
        return redirect('admin/quotoftheday');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $quotoftheday = Quotoftheday::findOrFail($id);

        return view('admin.quotoftheday.show', compact('quotoftheday'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $quotoftheday=$this->quote_repo->editview($id);

        return view('admin.quotoftheday.edit', compact('quotoftheday'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(Request $request, $id)
    {
        $requestData = $request->all();
       
        $cm=$this->quote_repo->updatequote($requestData,$id);
      
        flash('Quote Updated Successfully.');
        return redirect('admin/quotoftheday');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        $cms=$this->quote_repo->delete($id);
        flash('Quote Deleted Successfully.');
        return redirect('admin/quotoftheday');
    }

    public function get_daily_quote(Request $request)
    {
        $email = $request->input('email');
        if(!isset($email) || empty($email))
        {
            return response()->json(['status' =>400,'message'=>'All fields are required','data' =>array()]
                );  
        }


       // $reg_date = $request->input('registration_date');
        // if(!isset($reg_date) || empty($reg_date))
        // {
        //     return response()->json(['status' =>400,'message'=>'All fields are required','data' =>array()]
        //         );  
        // }
        else
        {
             $email_check=$this->quote_repo->checkemail($email);
             //echo $email_check; exit();
             if($email_check=="noemail"){
                return response()->json(['status' =>400,'message'=>'invalid Email','data' =>array()]
                );

             }
             else
             {     
                 $reg_date=$email_check;
           
                 $quote_data=$this->quote_repo->getAll();
                
                  foreach ($quote_data as $key => $value) {

                    $quote_Array[$key]=$value['quote']; 
                    $autor_Array[$key]=$value['author']; 
                  }
                
                  
                  $today=date('Y-m-d');
                  $strToTime_reg_date = strtotime($reg_date);
                  $strToTime_today = strtotime($today);

                  $days_diffrence = ceil(abs($strToTime_today - $strToTime_reg_date) / 86400)-1;

                   $data=array();
                   if($days_diffrence<count($quote_Array))
                   {
                      $quote=$quote_Array[$days_diffrence];
                      $author=$autor_Array[$days_diffrence];

                   }else{
                      $ans=ceil(($days_diffrence)%(count($quote_Array)));
                      $quote=$quote_Array[$ans];
                      $author=$autor_Array[$ans];
                    
                   }

                 return response()->json(['status' => Response::HTTP_OK,'message'=>'success','quote' => $quote,'author'=>$author]
                        );
            }
        }

         
    }




}//EOF