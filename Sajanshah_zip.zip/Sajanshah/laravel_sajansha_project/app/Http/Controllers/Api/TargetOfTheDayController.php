<?php

namespace App\Http\Controllers\Api;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

/* repositiry */
use App\Repositories\Api\TargetOfTHeDayRepository;
use App\Repositories\Api\ChallengeOfTheDayRepository;
use App\Repositories\Api\QuoteRepository;

/* json resposne*/
use Illuminate\Http\Response;

class TargetOfTheDayController extends Controller
{
    protected $target; 

    function __construct(TargetOfTHeDayRepository $target,ChallengeOfTheDayRepository $ChallengeOfTheDayRepository,QuoteRepository $QuoteRepository){

         $this->target=$target;
         $this->challenge_repo=$ChallengeOfTheDayRepository;
         $this->quote_repo=$QuoteRepository;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $targets = $this->target->getAllTargets($request); 
        $data['success'] = 200;
        $data['targets'] = $targets;

        return $data;
    }

    public function store(Request $request)
    {
       /* Rashmi */
       $requestall = $request->all();
      
        $targets = $this->target->store_target($requestall); 
        $data['status'] = 200;
        $data['message'] = 'Target stored successfully';
        $data['data'] = $targets;

        return $data;
       
    }

    public function update(Request $request)
    {
         /* Rashmi */
        $targets = $this->target->update($request); 
        $data['success'] = 200;
        $data['message'] = 'Target status updated successfully';

        return $data;
    }

    public function update_custom_target(Request $request){

        $id = $request->input('id'); 
        $title = $request->input('title'); 
      if(!isset($id) || empty($id) || !isset($title) || empty($title) )
      {

        return response()->json(['status' =>400,'message'=>'All fields are required.','data' =>array()]
          ); 

       }
       else{
          $custom_targets = $this->target->update_custom_target($id,$title); 
           if(count($custom_targets)>0){
             return response()->json(['status' =>200,'message'=>'Updated Successfully.','data' =>$custom_targets]);
           }else{
             return response()->json(['status' =>400,'message'=>'Not Updated .','data' =>array()]);
           }  
       } 
      
      
    }

     public function save_target_status(Request $request){

        $user_id = $request->input('user_id');
        $target_id =$request->input('target_id');
        $status = $request->input('status');
     
        if(!isset($user_id) || empty($user_id) || !isset($target_id) || empty($target_id) || !isset($status) )
        {

          return response()->json(['status' =>400,'message'=>'All fields are required.','data' =>array()]
            ); 

         }
         else
         {
              $requestData = $request->all();
               
              $data=$this->target->store($requestData);
              if($status==1) {
                 $points=$this->challenge_repo->update_point_counter($user_id);

              }else{

                 $isvalidUser=$this->target->getPointsByUserId($user_id);
                 if($isvalidUser!="unauthosired"){

                  $points=$isvalidUser; 

                 }else{
                  
                  return response()->json(['status' =>400,'message'=>'Unauthorised user','points' =>-1]); 
           
                 }

              }
              return response()->json(['status' => Response::HTTP_OK,'message'=>'success','points' => $points]
            ); 
         }


     }
 
  //   public function checkTargetStatus(Request $request){
 
  //       $user_id = $request->input('user_id');
  //       $target_id = $request->input('target_id');
        
  //       if(!isset($user_id) || empty($user_id) || !isset($target_id) || empty($target_id) )
  //       {

  //         return response()->json(['status' =>400,'message'=>'All fields are required.','data' =>array()]
  //           ); 

  //        }
  //        else{

              
  //             $requestData = $request->all();  
  //             $data=$this->target->check_target_status($user_id,$target_id);
              
  //             if(count($data)>0) {
              
  //                $status_contain=$data[0]['status'];
  //                $data='disable';
  //                $status=200; //4

  //             }else{
  //               $data='enable';
  //               $status=200;  
  //               $status_contain=-1;
  //             }
  //             return response()->json(['status' => $status,'message'=>'success','data' => $data,'status_contain'=>$status_contain]); 

              
             
  //        }
         


  // }


   public function checkTargetStatus(Request $request){
 
        $user_id = $request->input('user_id');
       
        
        if(!isset($user_id) || empty($user_id) )
        {

          return response()->json(['status' =>400,'message'=>'All fields are required.','data' =>array()]
            ); 

         }
         else{

              $data=$this->target->checkAllTargetOfUser($user_id);
             
               return response()->json(['status' =>200,'message'=>'target status','data' =>$data]
            );
         }
         


  }



  public function my(Request $request)
  {
        $user_id = $request->input('user_id');
        $email = $request->input('email');
        if(!isset($email) || empty($email))
        {
            return response()->json(['status' =>400,'message'=>'All fields are required','data' =>array()]
                );  
        }
        else
        {
             $email_check=$this->quote_repo->checkemail($email);
             //echo $email_check; exit();
             if($email_check=="noemail"){
                return response()->json(['status' =>400,'message'=>'invalid Email','data' =>array()]
                );

             }
             else
             {     
                 $reg_date=$email_check;
                  
                 $personal_data=$this->target->getAllTargetsByType(1);
                 $professional_data=$this->target->getAllTargetsByType(2);
                 $family_data=$this->target->getAllTargetsByType(3);
                
                  foreach ($personal_data as $key => $value) {

                    $personal_id_Array[$key]=$value['id']; 
                    $personal_title_Array[$key]=$value['title']; 
                  }

                  foreach ($professional_data as $key => $value) {

                    $professional_id_Array[$key]=$value['id']; 
                    $professional_title_Array[$key]=$value['title']; 
                  }

                  foreach ($family_data as $key => $value) {

                    $family_id_Array[$key]=$value['id']; 
                    $family_title_Array[$key]=$value['title']; 
                  }
               
                  
                  $today=date('Y-m-d');
                  $strToTime_reg_date = strtotime($reg_date);
                  $strToTime_today = strtotime($today);

                  $days_diffrence = ceil(abs($strToTime_today - $strToTime_reg_date) / 86400)-1;
                
                   $data=array();
                   if($days_diffrence<count($personal_id_Array))
                   {
                    
                      $pid=$personal_id_Array[$days_diffrence];
                      $ptitle=$personal_title_Array[$days_diffrence];

                      $pfid=$professional_id_Array[$days_diffrence];
                      $pftitle=$professional_title_Array[$days_diffrence];

                      $fid=$family_id_Array[$days_diffrence];
                      $ftitle=$family_title_Array[$days_diffrence];

                   }else{

                      $ans=ceil(($days_diffrence)%(count($personal_id_Array)));
                      
                      $pid=$personal_id_Array[$ans];
                      $ptitle=$personal_title_Array[$ans];

                      $pfid=$professional_id_Array[$ans];
                      $pftitle=$professional_title_Array[$ans];

                      $fid=$family_id_Array[$ans];
                      $ftitle=$family_title_Array[$ans];
                    
                   }
               
                   $custom_target=$this->target->getAllCustomByUserId($user_id);
                    
                 return response()->json(['status' => Response::HTTP_OK,'message'=>'success','personal_id' => $pid,'personal_target'=>$ptitle,
                   'professional_id' => $pfid,'professional_target'=>$pftitle,
                   'family_id' => $fid,'family_target'=>$ftitle,'custom_target'=>$custom_target]
                        );
            }
        }
  }

}//EOF
