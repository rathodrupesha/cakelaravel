<?php

namespace App\Http\Controllers\Api;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Userclaim;
use Illuminate\Http\Request;

/* repositiry */
use App\Repositories\Api\UserclaimRepository;

/* json resposne*/
use Illuminate\Http\Response;

class UserclaimsController extends Controller
{

    protected $userclaim_repo; 

    function __construct(UserclaimRepository $UserclaimRepository){

         //$this->middleware('auth');
         $this->userclaim_repo=$UserclaimRepository;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {

        $keyword = $request->get('search');
        $perPage = 25;

        if (!empty($keyword)) {
            $userclaims = Userclaim::where('user_id', 'LIKE', "%$keyword%")
                ->orWhere('gift_id', 'LIKE', "%$keyword%")
                ->latest()->paginate($perPage);
        } else {
            $userclaims = Userclaim::latest()->paginate($perPage);
        }

        return view('admin.userclaims.index', compact('userclaims'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('admin.userclaims.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(Request $request)
    {
        $user_id = $request->input('user_id'); 
        $gift_id = $request->input('gift_id');
        $claim_points = $request->input('claim_points');
        $claim_status=$request->input('claim_status');

        if(!isset($user_id) || empty($user_id) || !isset($claim_points) || empty($claim_points) || !isset($gift_id) || empty($gift_id) || !isset($claim_status) )
        {

          return response()->json(['status' =>400,'message'=>'All fields are required.','data' =>array()]
            ); 

        }else{

           $requestData = $request->all();
           $addclaim=$this->userclaim_repo->insertclaim($requestData);
           return response()->json(['status' =>200,'message'=>'claim added successfully.','points' =>$addclaim]
            );
        }

       
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $userclaim = Userclaim::findOrFail($id);

        return view('admin.userclaims.show', compact('userclaim'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $userclaim = Userclaim::findOrFail($id);

        return view('admin.userclaims.edit', compact('userclaim'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(Request $request, $id)
    {
        
        $requestData = $request->all();
        
        $userclaim = Userclaim::findOrFail($id);
        $userclaim->update($requestData);

        return redirect('admin/userclaims')->with('flash_message', 'Userclaim updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        Userclaim::destroy($id);

        return redirect('admin/userclaims')->with('flash_message', 'Userclaim deleted!');
    }

 
   

   public function check_claim(Request $request)
    {
        $user_id = $request->input('user_id'); 
        $gift_id = $request->input('gift_id');
        $is_deleted = $request->input('is_deleted');
        $claim_status=$request->input('claim_status');

        if(!isset($user_id) || empty($user_id) || !isset($claim_status) || empty($claim_status) || !isset($gift_id) || empty($gift_id) || !isset($is_deleted) )
        {

          return response()->json(['status' =>400,'message'=>'All fields are required.','claim_status' =>0101]
            ); 

        }
        else
        {

           $is_claim=$this->userclaim_repo->checkclaim($user_id,$gift_id,$is_deleted,$claim_status);
           if($is_claim=="claimed"){

             return response()->json(['status' =>400,'message'=>'claim already exist.','claim_status' =>1]
            );

           }
           else
           {
             
             return response()->json(['status' =>200,'message'=>'claim not exist.','claim_status' =>0]
            );

           }
           
        }
    
    }



    public function get_all_gift(Request $request)
    {

    
       $gift_data=$this->userclaim_repo->getAllgift();
       return response()->json(['status' =>200,'message'=>'success.','data' =>$gift_data]);
    }



}
