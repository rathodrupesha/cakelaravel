<?php

namespace App\Http\Controllers\Api;

use App\Http\Requests;
use App\Http\Controllers\Controller;

/* model */
use App\Connectwithus;

/* request*/
use Illuminate\Http\Request;
use App\Http\Requests\ConnectusRequest;

/* repositiry */
use App\Repositories\Api\ConnectusRepository;

/* json resposne*/
use Illuminate\Http\Response;


class ConnectwithusController extends Controller
{

    protected $connectus_repo; 

    function __construct(ConnectusRepository $ConnectusRepository){

         //$this->middleware('auth');
         $this->connectus_repo=$ConnectusRepository;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $data=$this->connectus_repo->getAll();
        return response()->json(['status' => Response::HTTP_OK,'message'=>'Data Get successfully','data' => $data]
            );
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('admin.connectwithus.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(Request $request)
    {
        
        $requestData = $request->all();
        
        Connectwithus::create($requestData);

        return redirect('admin/connectwithus')->with('flash_message', 'Connectwithus added!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $connectwithus = Connectwithus::findOrFail($id);

        return view('admin.connectwithus.show', compact('connectwithus'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $connectwithus=$this->connectus_repo->editview($id);
        return view('admin.connectwithus.edit', compact('connectwithus'));
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(Request $request, $id)
    {
       
        $requestData = $request->all();
        $connectwithus=$this->connectus_repo->updateconnectus($requestData,$id);
        flash('Url Updated Successfully.');
        return redirect('admin/connectwithus/1/edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        Connectwithus::destroy($id);

        return redirect('admin/connectwithus')->with('flash_message', 'Connectwithus deleted!');
    }
}
