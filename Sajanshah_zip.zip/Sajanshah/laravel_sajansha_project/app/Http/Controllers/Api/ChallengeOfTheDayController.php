<?php

namespace App\Http\Controllers\Api;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\ChallengeOfTheDay;

/* request*/
use Illuminate\Http\Request;
use App\Http\Requests\ChallengeRequest;

/* repositiry */
use App\Repositories\Api\ChallengeOfTheDayRepository;
use App\Repositories\Api\TargetOfTHeDayRepository;


/* json resposne*/
use Illuminate\Http\Response;

//class ChallengeOfTheDayController extends Controller
class ChallengeofthedayController extends Controller
{
    protected $challenge_repo; 
    protected $target_repo;

    function __construct(ChallengeOfTheDayRepository $ChallengeOfTheDayRepository,TargetOfTHeDayRepository $TargetOfTHeDayRepository){

         // $this->middleware('auth');
         $this->challenge_repo=$ChallengeOfTheDayRepository;
         $this->target_repo=$TargetOfTHeDayRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
   
        $data=$this->challenge_repo->getAll(); 
        return response()->json(['status' => Response::HTTP_OK,'message'=>'success','data' => $data]
            );        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('admin.challenge-of-the-day.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(ChallengeRequest $request)
    {
        $requestData = $request->all();
        $challenge=$this->challenge_repo->insertchallenge($requestData);
        
        flash('Challenge created successfully.');
        return redirect('admin/challengeoftheday');
       
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $challengeoftheday = ChallengeOfTheDay::findOrFail($id);

        return view('admin.challenge-of-the-day.show', compact('challengeoftheday'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {

     $challengeoftheday=$this->challenge_repo->editview($id);

     return view('admin.challenge-of-the-day.edit', compact('challengeoftheday'));
         
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(ChallengeRequest $request, $id)
    {
        $requestData = $request->all();
       
        $chlng=$this->challenge_repo->updatechallenge($requestData,$id);
      
        flash('Challenge Updated Successfully.');
        return redirect('admin/challengeoftheday');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        $cms=$this->challenge_repo->delete($id);
        flash('Deleted Successfully.');
        return redirect('admin/challengeoftheday');
    }


   public function get_daily_challenge(Request $request)
    {
        $email = $request->input('email');
        if(!isset($email) || empty($email))
        {
            return response()->json(['status' =>400,'message'=>'All fields are required','data' =>array()]
                );  
        }


       // $reg_date = $request->input('registration_date');
        // if(!isset($reg_date) || empty($reg_date))
        // {
        //     return response()->json(['status' =>400,'message'=>'All fields are required','data' =>array()]
        //         );  
        // }
        else
        {
             $email_check=$this->challenge_repo->checkemail($email);
             //echo $email_check; exit();
             if($email_check=="noemail"){
                return response()->json(['status' =>400,'message'=>'invalid Email','data' =>array()]
                );

             }
             else
             {  
                 $reg_date=$email_check;
                 
                 $challenge_data=$this->challenge_repo->getAll();
              
                  foreach ($challenge_data as $key => $value) {

                    $challenge_Array[$key]=$value['title']; 
                     
                  }
                
                  
                  $today=date('Y-m-d');
                  $strToTime_reg_date = strtotime($reg_date);
                  $strToTime_today = strtotime($today);

                  $days_diffrence = ceil(abs($strToTime_today - $strToTime_reg_date) / 86400)-1;
                 
                   $data=array();
                   if($days_diffrence<count($challenge_Array))
                   {
                      $challenge=$challenge_Array[$days_diffrence];
                      $challenge_id=$days_diffrence+1;
                      

                   }else{
                      $ans=ceil(($days_diffrence)%(count($challenge_Array)));
                      $challenge=$challenge_Array[$ans];
                      $challenge_id=$ans+1;
                      
                   }

                 return response()->json(['status' => Response::HTTP_OK,'message'=>'success','challenge' => $challenge,'challene_id'=>$challenge_id]
                        );
            }
        }

         
    }

   public function savechallengestatus(Request $request)
   {
        $user_id = $request->input('user_id');
        $challenge_id = $request->input('challenge_id');
        $status = $request->input('status');

        if(!isset($user_id) || empty($user_id) || !isset($challenge_id) || empty($challenge_id) || !isset($status) )
        {

          return response()->json(['status' =>400,'message'=>'All fields are required.','data' =>array()]
            ); 

         }
         else{
              $requestData = $request->all();  
              $data=$this->challenge_repo->insert_challange_status($requestData);
              if($status==1) {
                 $points=$this->challenge_repo->update_point_counter($user_id);

              }else{

                 $isvalidUser=$this->target_repo->getPointsByUserId($user_id);
                 if($isvalidUser!="unauthosired"){

                  $points=$isvalidUser; 

                 }else{
                  
                  return response()->json(['status' =>400,'message'=>'Unauthorised user','points' =>-1]); 
           
                 }
                
              }
              return response()->json(['status' => Response::HTTP_OK,'message'=>'success','points' => $points]
            ); 
         }
    


  }

  public function checkchallengestatus(Request $request){
 
        $user_id = $request->input('user_id');
        $challenge_id = $request->input('challenge_id');
        
        if(!isset($user_id) || empty($user_id) || !isset($challenge_id) || empty($challenge_id) )
        {

          return response()->json(['status' =>400,'message'=>'All fields are required.','data' =>array()]
            ); 

         }
         else{
              $requestData = $request->all();  
              $data=$this->challenge_repo->check_challange_status($user_id,$challenge_id);
              
              if(count($data)>0) {
                 $status_contain=$data[0]['status']; 
                 $data='disable';
                 $status=200; //4
                
              }else{
                $data='enable';
                $status=200;
                $status_contain=-1;
              }
              return response()->json(['status' => $status,'message'=>'success','data' => $data,'status_contain'=>$status_contain]); 
         }
         


  }

}
