<?php

namespace App\Http\Controllers\Api;

use App\Http\Requests;
use App\Http\Controllers\Controller;

/* model */
use App\Cm;

/* request*/
use Illuminate\Http\Request;
use App\Http\Requests\CmsRequest;

/* repositiry */
use App\Repositories\Api\CmsRepository;

/* json resposne*/
use Illuminate\Http\Response;

class CmsController extends Controller
{
    protected $cms_repo; 

    function __construct(CmsRepository $CmsRepository){

         //$this->middleware('auth');
         $this->cms_repo=$CmsRepository;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */

    public function index(Request $request)
    { 
        $cms=$this->cms_repo->getAll(); 
        
        return response()->json(['status' => Response::HTTP_OK,'message'=>'success','title' => $cms[0]['title'],'content'=>$cms[0]['content']]
            );
      
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {   
        return view('admin.cms.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(CmsRequest $request)
    {  
        $requestData = $request->all();
        $cms=$this->cms_repo->insertcms($requestData);
  
        // Cm::create($requestData);
        flash('Cms created successfully.');
        return redirect('admin/cms');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $cm = Cm::findOrFail($id);

        return view('admin.cms.show', compact('cm'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $cm=$this->cms_repo->editview($id);
        return view('admin.cms.edit', compact('cm'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(CmsRequest $request, $id)
    {
        
        $requestData = $request->all();
       
        $cm=$this->cms_repo->updatecms($requestData,$id);
      
        flash('Cms Updated Successfully.');
        return redirect('admin/cms');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        $cms=$this->cms_repo->delete($id);
        flash('Deleted Successfully.');
        return redirect('admin/cms');
    }
}
