<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\ChallengeOfTheDay;

/* request*/
use Illuminate\Http\Request;
use App\Http\Requests\ChallengeRequest;

/* repositiry */
use App\Repositories\Admin\ChallengeOfTheDayRepository;

//class ChallengeOfTheDayController extends Controller
class ChallengeofthedayController extends Controller
{
    protected $challenge_repo; 

    function __construct(ChallengeOfTheDayRepository $ChallengeOfTheDayRepository){

         $this->middleware('auth');
         $this->challenge_repo=$ChallengeOfTheDayRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        
        $challengeoftheday=$this->challenge_repo->getAll(); 

        /*
        $keyword = $request->get('search');
        $perPage = 25;

        if (!empty($keyword)) {
            $challengeoftheday = ChallengeOfTheDay::where('title', 'LIKE', "%$keyword%")
                ->orWhere('content', 'LIKE', "%$keyword%")
                ->orWhere('category', 'LIKE', "%$keyword%")
                ->latest()->paginate($perPage);
        } else {
            $challengeoftheday = ChallengeOfTheDay::latest()->paginate($perPage);
        }
        */
        return view('admin.challenge-of-the-day.index', compact('challengeoftheday'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('admin.challenge-of-the-day.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(ChallengeRequest $request)
    {
        $requestData = $request->all();
        $challenge=$this->challenge_repo->insertchallenge($requestData);
        
        flash('Challenge created successfully.');
        return redirect('admin/challengeoftheday');
       
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $challengeoftheday = ChallengeOfTheDay::findOrFail($id);

        return view('admin.challenge-of-the-day.show', compact('challengeoftheday'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {

     $challengeoftheday=$this->challenge_repo->editview($id);

     return view('admin.challenge-of-the-day.edit', compact('challengeoftheday'));
         
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(ChallengeRequest $request, $id)
    {
        $requestData = $request->all();
       
        $chlng=$this->challenge_repo->updatechallenge($requestData,$id);
      
        flash('Challenge Updated Successfully.');
        return redirect('admin/challengeoftheday');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        $cms=$this->challenge_repo->delete($id);
        flash('Deleted Successfully.');
        return redirect('admin/challengeoftheday');
    }
}
