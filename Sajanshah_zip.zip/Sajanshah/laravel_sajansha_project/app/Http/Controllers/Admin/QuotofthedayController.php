<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Quotoftheday;

/* request*/
use Illuminate\Http\Request;
use App\Http\Requests\QuoteRequest;

/* repositiry */
use App\Repositories\Admin\QuoteRepository;

class QuotofthedayController extends Controller
{

    protected $quote_repo; 

    function __construct(QuoteRepository $QuoteRepository){

         $this->middleware('auth');
         $this->quote_repo=$QuoteRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $quotoftheday=$this->quote_repo->getAll();
        
        /*
        $keyword = $request->get('search');
        $perPage = 25;

        if (!empty($keyword)) {
            $quotoftheday = Quotoftheday::where('title', 'LIKE', "%$keyword%")
                ->orWhere('content', 'LIKE', "%$keyword%")
                ->orWhere('category', 'LIKE', "%$keyword%")
                ->latest()->paginate($perPage);
        } else {
            $quotoftheday = Quotoftheday::latest()->paginate($perPage);
        }
       */
        return view('admin.quotoftheday.index', compact('quotoftheday'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('admin.quotoftheday.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(QuoteRequest $request)
    {
        
        $requestData = $request->all();

        $quotoftheday=$this->quote_repo->insertquote($requestData);
  
        flash('Quote created successfully.');
        return redirect('admin/quotoftheday');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $quotoftheday = Quotoftheday::findOrFail($id);

        return view('admin.quotoftheday.show', compact('quotoftheday'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $quotoftheday=$this->quote_repo->editview($id);

        return view('admin.quotoftheday.edit', compact('quotoftheday'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(Request $request, $id)
    {
        $requestData = $request->all();
       
        $cm=$this->quote_repo->updatequote($requestData,$id);
      
        flash('Quote Updated Successfully.');
        return redirect('admin/quotoftheday');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        $cms=$this->quote_repo->delete($id);
        flash('Quote Deleted Successfully.');
        return redirect('admin/quotoftheday');
    }
}
