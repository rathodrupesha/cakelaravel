<?php
namespace App\Http\Controllers\Admin;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Userclaim;
use Illuminate\Http\Request;

/* repositiry */
use App\Repositories\Admin\UserclaimRepository;

class UserclaimsController extends Controller
{

    protected $userclaim_repo; 

    function __construct(UserclaimRepository $UserclaimRepository){
        
         //$this->middleware('auth');
         $this->userclaim_repo=$UserclaimRepository;
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        
      $claimHistory=$this->userclaim_repo->getAll();
      
      return view('admin.userclaims.index', compact('claimHistory'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('admin.userclaims.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(Request $request)
    {
        
        $requestData = $request->all();
        
        Userclaim::create($requestData);

        return redirect('admin/userclaims')->with('flash_message', 'Userclaim added!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $userclaim = Userclaim::findOrFail($id);

        return view('admin.userclaims.show', compact('userclaim'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $userclaim = Userclaim::findOrFail($id);

        return view('admin.userclaims.edit', compact('userclaim'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(Request $request, $id)
    {
        
        $requestData = $request->all();
        
        $userclaim = Userclaim::findOrFail($id);
        $userclaim->update($requestData);

        return redirect('admin/userclaims')->with('flash_message', 'Userclaim updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        Userclaim::destroy($id);

        return redirect('admin/userclaims')->with('flash_message', 'Userclaim deleted!');
    }
}