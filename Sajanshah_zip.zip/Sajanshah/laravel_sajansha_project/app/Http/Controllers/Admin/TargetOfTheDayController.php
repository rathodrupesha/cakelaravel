<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests;
use App\Http\Controllers\Controller;

/* model */
use App\TargetOfTheDay;
/* Request */
use Illuminate\Http\Request;
use App\Http\Requests\TargetRequest;

/* Repositiry */
use App\Repositories\Admin\TargetRepository;

class TargetOfTheDayController extends Controller
{
   var $TargetRepository;
    function __construct(TargetRepository $TargetRepository){
        $this->target_repo=$TargetRepository;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        //$target_pesonal=$this->target_repo->getAllPesrsonal(); 

        $targets=$this->target_repo->getAllPesrsonal();  //by rashmi
        // dd($targets);
        $target_professional=$this->target_repo->getAllProffesional(); 
        $target_family=$this->target_repo->getAllFamily();

        $target_custom=$this->target_repo->getcustome_target();

        $target_status=$this->target_repo->getAllstatus();
       
        return view('admin.target-of-the-day.index', compact('target_pesonal','target_professional','target_family','target_custom','target_status','targets'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('admin.target-of-the-day.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(TargetRequest $request)
    {
        $requestData = $request->all();
        $requestData['user_id']=\Auth::user()->id;
        $this->target_repo->insertTarget($requestData);
        flash("Target of the day created successfully. !"); 
        return redirect('admin/targetoftheday');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $targetoftheday = TargetOfTheDay::findOrFail($id);

        return view('admin.target-of-the-day.show', compact('targetoftheday'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $targetoftheday = $this->target_repo->editview($id);
        return view('admin.target-of-the-day.edit', compact('targetoftheday'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(Request $request, $id)
    {
        
        $requestData = $request->all();
        $this->target_repo->updateTarget($requestData,$id);
     
        flash("TargetOfTheDay Updated Successfully !");  
        return redirect('admin/targetoftheday');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
        $this->target_repo->delete($id);
        flash("TargetOfTheDay deleted Successfully !");  
        return redirect('admin/targetoftheday');
    }

    public function statusview($user_id,$target_id,$status){

          $statusview=$this->target_repo->getTargetStatusOfUser($user_id,$target_id,$status);
          return view('admin.target-of-the-day.statusview', compact('statusview'));
    }
   
    
    public function statusviewgeneral($target_id,$status){

          $statusviewgeneral=$this->target_repo->getTargetStatusOf_targetWise($target_id,$status);
          return view('admin.target-of-the-day.statusviewgeneral', compact('statusviewgeneral'));
    }


}
