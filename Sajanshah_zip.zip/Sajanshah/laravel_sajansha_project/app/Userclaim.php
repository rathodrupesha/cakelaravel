<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Userclaim extends Model
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'userclaims';

    /**
    * The database primary key value.
    *
    * @var string
    */
    protected $primaryKey = 'id';

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['user_id', 'gift_id','claim_status','claim_points'];


    public function user()
    {
        return $this->belongsTo(User::class,'user_id','id'); 
    }

    public function gift()
    {
        return $this->belongsTo(Gift::class,'gift_id','id'); 
    }
    
}
