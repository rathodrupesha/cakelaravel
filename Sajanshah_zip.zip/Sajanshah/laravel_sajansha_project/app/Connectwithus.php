<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Connectwithus extends Model
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'connectwithuses';

    /**
    * The database primary key value.
    *
    * @var string
    */
    protected $primaryKey = 'id';

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['facebook', 'instagrame', 'youtube','tweeter','whatsup','google_plus','snapchat','other'];

    
}
