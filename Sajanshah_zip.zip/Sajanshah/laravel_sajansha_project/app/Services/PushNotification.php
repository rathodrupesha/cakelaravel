<?php
namespace App\Services;
use App\User;
 

class PushNotification { 

    private static $API_SERVER_KEY = 'AAAAp_d4duA:APA91bFRYRHQ3kadp5HarwxR-SOAC0-ak0WoP1YcV_LmboXvIxvDgdlc8KveGNbukxJr5pammASfIaXrIfFqKzTrvLZMsWCXmhbQNGBXNlZCSMS0EWYlRUzdFftCgtWc5XBq_p2nZSf8';
    private static $is_background = "TRUE";

    public function __construct() {     
     
    }


    public function sendPushNotificationToFCMSever($token, $message, $notifyID) {
    	
        $path_to_firebase_cm = 'https://fcm.googleapis.com/fcm/send';
 
        $fields = array(
            'registration_ids' => $token,
            'priority' => 10,
            'notification' => array('title' => 'Quote of the day', 'body' =>  $message ,'sound'=>'Default','image'=>'Notification Image' ),
        );
        $headers = array(
            'Authorization:key=' . self::$API_SERVER_KEY,
            'Content-Type:application/json'
        );  
         
        // Open connection  
        $ch = curl_init(); 
        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $path_to_firebase_cm); 
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4 );
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        // Execute post   
        $result = curl_exec($ch); 
        // Close connection      
        curl_close($ch);
       
        return $result;
    }
 }
?>
