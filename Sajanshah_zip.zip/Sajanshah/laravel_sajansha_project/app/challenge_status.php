<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class challenge_status extends Model
{

   protected $table = 'challenge_status';

    protected $primaryKey = 'id';

    protected $fillable = [
        'user_id', 'challenge_id', 'status',
    ];

   

    public function user()
    {
        return $this->belongsTo(User::class,'user_id','id');
    }

    public function challengeoftheday()
    {
        return $this->belongsTo(ChallengeOfTheDay::class,'challenge_id','id');
    }



}
