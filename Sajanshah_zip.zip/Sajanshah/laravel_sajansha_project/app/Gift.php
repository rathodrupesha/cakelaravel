<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gift extends Model
{
    //

    // protected $fillable = [
    //     'name', 'email', 'password',
    // ];
    public function userclaim()
    {
        return $this->hasMany(Userclaim::class,'user_id','id');
    }
}
