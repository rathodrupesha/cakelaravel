<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

use App\Model\MasterGiftcard;
use App\Model\Sitesetting;
use App\Model\SiteUser;
use App\Model\MasterGiftcardReport;
use App\Model\Vendordetails;
use App\Model\Usersmodules;
use App\Model\Walletdetails;
use App\Model\Withdrawldetails;
use App\Model\Autopayment;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Traits\CommonTrait;

class PaypalCheckStatusFund extends Command
{
    use CommonTrait;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'paypal:fundstatus';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Paypal check status of pending & uncliamed records & update records in db for autopayment,walletdetails,siteuserbalance,withdrawaldetails';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function strright($str, $separator)
    {
        if (intval($separator)) {
            return substr($str, -$separator);
        } elseif ($separator === 0) {
            return $str;
        } else {
            $strpos = strpos($str, $separator);

            if ($strpos === false) {
                return $str;
            } else {
                return substr($str, -$strpos + 1);
            }
        }
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        \Log::info("PAYPAL => Paypal check status of pending & uncliamed records & update records in db for autopayment,walletdetails,siteuserbalance,withdrawaldetails");

        $dumpData=array(
                          'cron_name'=>'Paypal fund transfer for pending & unclaimed records',
                          'cron_desp'=>'PAYPAL => Paypal check status of pending & uncliamed records & update records in db for autopayment,walletdetails,siteuserbalance,withdrawaldetails',
                          'cron_command'=>'php artisan paypal:fundstatus',
                          'created_at'=>date('y-m-d H:i:s'),
                          'updated_at'=>date('y-m-d H:i:s')
                       );

        $this->cronRunInfoDumpInDb($dumpData);




        $isSandBoxOn=env('PAYPALFUNDTRSANSFER_SANDBOX');

        if ($isSandBoxOn=='on') {
            //sandbox
            $PAYPAL_CLIENT_ID=env('PAYPALFUNDTRSANSFER_CLIENT_ID_test');
            $PAYPAL_SECRATE_KEY=env('PAYPALFUNDTRSANSFER_SECRET_test');
            $baseUrl=env('PAYPALFUNDTRSANSFER_BASEURL_test');
        } else {
            //live
            $PAYPAL_CLIENT_ID=env('PAYPALFUNDTRSANSFER_CLIENT_ID_live');
            $PAYPAL_SECRATE_KEY=env('PAYPALFUNDTRSANSFER_SECRET_live');
            $baseUrl=env('PAYPALFUNDTRSANSFER_BASEURL_live');
        }

        $oAuthUrl=$baseUrl.'v1/oauth2/token';
        $paypalFundTransferUrl=$baseUrl.'v1/payments/payouts';
        $payoutStatusCheckUrl=$baseUrl.'v1/payments/payouts/';


        // Get access token from PayPal client Id and secrate key
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $oAuthUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "grant_type=client_credentials");
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_USERPWD, $PAYPAL_CLIENT_ID . ":" . $PAYPAL_SECRATE_KEY);

        $headers = array();
        $headers[] = "Accept: application/json";
        $headers[] = "Accept-Language: en_US";
        $headers[] = "Content-Type: application/x-www-form-urlencoded";
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $results = curl_exec($ch);
        $getresult = json_decode($results);

       //status 0 means pending or unclaimed
        $allData=Autopayment::where('status', 0)->where('withdrawoption', 1)->whereNotNull('paypal_api2')->get()->toArray();



        foreach ($allData as $key => $value) {
            $pData=Autopayment::where('id', $value['id'])->first();
            $userData=SiteUser::where('id', $value['siteusers_id'])->first();
            $amount=$pData->amount;
            $currency='USD'; //GBP
            $receiver=$userData->paypalid;

            //API 2
            $headers = array();
            $headers[] = "Content-Type: application/json";
            $headers[] = "Authorization: Bearer $getresult->access_token";
            $paypalapi2=$value['paypal_api2'];
            $cURLConnection = curl_init();
            curl_setopt($cURLConnection, CURLOPT_URL, $paypalapi2);
            curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($cURLConnection, CURLOPT_HTTPHEADER, $headers);
            $payoutStatus = curl_exec($cURLConnection);
            curl_close($cURLConnection);

            // echo "<pre>";
            // print_r(json_decode($payoutStatus, true));

            $finalResponse=json_decode($payoutStatus, true);

            if (isset($finalResponse['items'][0]['transaction_status']) && !empty($finalResponse['items'][0]['transaction_status']) && $finalResponse['items'][0]['transaction_status']=='SUCCESS') {

           //success

                $payout_item_id=$finalResponse['items'][0]['payout_item_id'];
                $payout_batch_id=$finalResponse['items'][0]['payout_batch_id'];
                $transaction_status=$finalResponse['items'][0]['transaction_status'];
                $transaction_id=$finalResponse['items'][0]['transaction_id'];
                $batch_status=$finalResponse['batch_header']['batch_status'];
                $sender_batch_id=$finalResponse['batch_header']['sender_batch_header']['sender_batch_id'];


                // status update in autopayment tbl

                $finalResponse=print_r($finalResponse, true);
                $paypalapi2=print_r($paypalapi2, true);

                Autopayment::where('id', $value['id'])->update(['status'=>1,'paypal_api_response2'=>$finalResponse,'updated_at'=>date('Y-m-d H:i:s'),'paypal_api2'=>$paypalapi2]);


                //status update in walletdetais tbl
                Walletdetails::where('id', $pData->walletdetails_id)->update(['walletstatus'=>1,'updated_at'=>date('Y-m-d H:i:s')]);



                Withdrawldetails::create([
                       'siteusers_id'=>$pData->siteusers_id,
                       'walletdetails_id'=>$pData->walletdetails_id,
                       'amount'=>$pData->amount,
                       'transactionid'=>$pData->transactionid,
                       'status'=>1, //1 for success, 4 for failed
                       'withdrawl_type'=>0,//manual amount
                       'created_at'=>date('Y-m-d H:i:s'),
                       'updated_at'=>date('Y-m-d H:i:s'),
                       'payoutbatchid'=>$payout_batch_id,
                       'batchstatus'=>$batch_status,
                       'senderbatchid'=>$sender_batch_id,
                       'withdrawoption'=>0,//manual paypal
                       'withdrawoption'=>0,
                       'currency'=>'$'
               ]);

                $tags['firstname']=$userData->firstname;
                $tags['lastname']=$userData->lastname;
                $tags['amount']=$amount;
                $template='paypaltopaypalfundtransfer';

                $this->sendEmailNotification($template, $toIds = [$pData->siteusers_id], $tags);

                echo "Paypalfund transfer.(id :".$value['id'].") is  success & updated successfully.</br>\r\n";
            } else {
                //failed or RETURNED
                if (
                    (isset($finalResponse['items'][0]['transaction_status']) && !empty($finalResponse['items'][0]['transaction_status']) && $finalResponse['items'][0]['transaction_status']=='FAILED')||(isset($finalResponse['items'][0]['transaction_status']) && !empty($finalResponse['items'][0]['transaction_status']) && $finalResponse['items'][0]['transaction_status']=='RETURNED')
                   ) {
                    $payout_item_id=$finalResponse['items'][0]['payout_item_id'];
                    $payout_batch_id=$finalResponse['items'][0]['payout_batch_id'];
                    $transaction_status=$finalResponse['items'][0]['transaction_status'];
                    $batch_status=$finalResponse['batch_header']['batch_status'];
                    $sender_batch_id=$finalResponse['batch_header']['sender_batch_header']['sender_batch_id'];


                    $finalResponse=print_r($finalResponse, true);
                    $paypalapi2=print_r($paypalapi2, true);

                    Autopayment::where('id', $value['id'])->update(['status'=>4,'paypal_api_response2'=>$finalResponse,'updated_at'=>date('Y-m-d H:i:s'),'paypal_api2'=>$paypalapi2]);


                    $col_name="wallettotalamount";
                    $updateCol=$col_name.'+'.$amount;
                    SiteUser::where('id', $pData->siteusers_id)->update([$col_name=> \DB::raw($updateCol)]);

                    //status update in walletdetais tbl
                    Walletdetails::where('id', $pData->walletdetails_id)->update(['walletstatus'=>2,'updated_at'=>date('Y-m-d H:i:s')]);

                    Withdrawldetails::create([
                       'siteusers_id'=>$pData->siteusers_id,
                       'walletdetails_id'=>$pData->walletdetails_id,
                       'amount'=>$pData->amount,
                       'transactionid'=>$pData->transactionid,
                       'status'=>4, //1 for success, 4 for failed
                       'withdrawl_type'=>0,//manual amount
                       'created_at'=>date('Y-m-d H:i:s'),
                       'updated_at'=>date('Y-m-d H:i:s'),
                       'payoutbatchid'=>$payout_batch_id,
                       'batchstatus'=>'FAILED',
                       'senderbatchid'=>$sender_batch_id,
                       'withdrawoption'=>0,//manual paypal
                       'withdrawoption'=>0,
                       'currency'=>'$'
               ]);

                    $tags['firstname']=$userData->firstname;
                    $tags['lastname']=$userData->lastname;
                    $tags['amount']=$amount;
                    $template='failedpaypaltopaypalfundtransfer';

                    $this->sendEmailNotification($template, $toIds = [$pData->siteusers_id], $tags);

                    echo "Paypalfund transfer.(id :".$value['id'].") is  failed & updated successfully.</br>\r\n";
                }
            }
        }//foreach main
    }//handel
}//class
