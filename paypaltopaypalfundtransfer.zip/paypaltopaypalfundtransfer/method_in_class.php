<?php


public function adminToUserPaypalFundTransfer(Request $request)
    {
        $requestData = $request->all();

        $autoPaymentId=$requestData['id'];

        $pData=Autopayment::where('id', $autoPaymentId)->first();

        $userData=SiteUser::where('id', $pData->siteusers_id)->first();

        $isSandBoxOn=env('PAYPALFUNDTRSANSFER_SANDBOX');

        if ($isSandBoxOn=='on') {
            //sandbox
            $PAYPAL_CLIENT_ID=env('PAYPALFUNDTRSANSFER_CLIENT_ID_test');
            $PAYPAL_SECRATE_KEY=env('PAYPALFUNDTRSANSFER_SECRET_test');
            $baseUrl=env('PAYPALFUNDTRSANSFER_BASEURL_test');
        } else {
            //live
            $PAYPAL_CLIENT_ID=env('PAYPALFUNDTRSANSFER_CLIENT_ID_live');
            $PAYPAL_SECRATE_KEY=env('PAYPALFUNDTRSANSFER_SECRET_live');
            $baseUrl=env('PAYPALFUNDTRSANSFER_BASEURL_live');
        }

        $oAuthUrl=$baseUrl.'v1/oauth2/token';
        $paypalFundTransferUrl=$baseUrl.'v1/payments/payouts';
        $payoutStatusCheckUrl=$baseUrl.'v1/payments/payouts/';

        $amount=$pData->amount;
        $currency='USD'; //GBP
        $receiver=$userData->paypalid;



        // Get access token from PayPal client Id and secrate key
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $oAuthUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "grant_type=client_credentials");
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_USERPWD, $PAYPAL_CLIENT_ID . ":" . $PAYPAL_SECRATE_KEY);

        $headers = array();
        $headers[] = "Accept: application/json";
        $headers[] = "Accept-Language: en_US";
        $headers[] = "Content-Type: application/x-www-form-urlencoded";
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $results = curl_exec($ch);
        $getresult = json_decode($results);
        //echo "<pre>";print_r($getresult->access_token);exit;

        // PayPal Payout API for Send Payment from PayPal to PayPal account
        curl_setopt($ch, CURLOPT_URL, $paypalFundTransferUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        $array = array('sender_batch_header' => array(
                    "sender_batch_id" => time(),
                    "email_subject" => "You have a payout!",
                    "email_message" => "You have received a payout."
                ),
                'items' => array(array(
                        "recipient_type" => "EMAIL",
                        "amount" => array(
                            "value" => $amount,
                            "currency" => $currency
                        ),
                        "note" => "Thanks for the payout!",
                        "sender_item_id" => time(),
                        "receiver" =>$receiver
                    ))
            );
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($array));
        curl_setopt($ch, CURLOPT_POST, 1);

        $headers = array();
        $headers[] = "Content-Type: application/json";
        $headers[] = "Authorization: Bearer $getresult->access_token";
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $payoutResult = curl_exec($ch);
        //print_r($result);
        $getPayoutResult = json_decode($payoutResult);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close($ch);
        // echo "<pre>";
        // print_r($getPayoutResult);
        // echo "<pre>";print_r($getPayoutResult->batch_header->payout_batch_id);exit;

        sleep(10);

        //API 2
        $paypalapi2=$payoutStatusCheckUrl.$getPayoutResult->batch_header->payout_batch_id;
        $cURLConnection = curl_init();
        curl_setopt($cURLConnection, CURLOPT_URL, $paypalapi2);
        curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($cURLConnection, CURLOPT_HTTPHEADER, $headers);
        $payoutStatus = curl_exec($cURLConnection);
        curl_close($cURLConnection);

        // echo "<pre>";
        // print_r(json_decode($payoutStatus, true));

        $finalResponse=json_decode($payoutStatus, true);

        if (isset($finalResponse['items'][0]['transaction_status']) && !empty($finalResponse['items'][0]['transaction_status']) && $finalResponse['items'][0]['transaction_status']=='SUCCESS') {

           //success

            $payout_item_id=$finalResponse['items'][0]['payout_item_id'];
            $payout_batch_id=$finalResponse['items'][0]['payout_batch_id'];
            $transaction_status=$finalResponse['items'][0]['transaction_status'];
            $transaction_id=$finalResponse['items'][0]['transaction_id'];
            $batch_status=$finalResponse['batch_header']['batch_status'];
            $sender_batch_id=$finalResponse['batch_header']['sender_batch_header']['sender_batch_id'];


            // status update in autopayment tbl
            $getPayoutResult=print_r($getPayoutResult, true);
            $finalResponse=print_r($finalResponse, true);
            $paypalapi2=print_r($paypalapi2, true);

            Autopayment::where('id', $autoPaymentId)->update(['status'=>1,'paypal_api_response1'=>$getPayoutResult,'paypal_api_response2'=>$finalResponse,'updated_at'=>date('Y-m-d H:i:s'),'paypal_api2'=>$paypalapi2]);


            //status update in walletdetais tbl
            Walletdetails::where('id', $pData->walletdetails_id)->update(['walletstatus'=>1,'updated_at'=>date('Y-m-d H:i:s')]);



            Withdrawldetails::create([
                       'siteusers_id'=>$pData->siteusers_id,
                       'walletdetails_id'=>$pData->walletdetails_id,
                       'amount'=>$pData->amount,
                       'transactionid'=>$pData->transactionid,
                       'status'=>1, //1 for success, 4 for failed
                       'withdrawl_type'=>0,//manual amount
                       'created_at'=>date('Y-m-d H:i:s'),
                       'updated_at'=>date('Y-m-d H:i:s'),
                       'payoutbatchid'=>$payout_batch_id,
                       'batchstatus'=>$batch_status,
                       'senderbatchid'=>$sender_batch_id,
                       'withdrawoption'=>0,//manual paypal
                       'withdrawoption'=>0,
                       'currency'=>'$'
          ]);

            $tags['firstname']=$userData->firstname;
            $tags['lastname']=$userData->lastname;
            $tags['amount']=$amount;
            $template='paypaltopaypalfundtransfer';

            $this->sendEmailNotification($template, $toIds = [$pData->siteusers_id], $tags);

            return 'SUCCESS';
        } else {

           //faile, pending,unclaimed

            if (isset($finalResponse['items'][0]['transaction_status']) && !empty($finalResponse['items'][0]['transaction_status']) && $finalResponse['items'][0]['transaction_status']=='FAILED') {
                $payout_item_id=$finalResponse['items'][0]['payout_item_id'];
                $payout_batch_id=$finalResponse['items'][0]['payout_batch_id'];
                $transaction_status=$finalResponse['items'][0]['transaction_status'];
                $batch_status=$finalResponse['batch_header']['batch_status'];
                $sender_batch_id=$finalResponse['batch_header']['sender_batch_header']['sender_batch_id'];


                $getPayoutResult=print_r($getPayoutResult, true);
                $finalResponse=print_r($finalResponse, true);
                $paypalapi2=print_r($paypalapi2, true);

                Autopayment::where('id', $autoPaymentId)->update(['status'=>4,'paypal_api_response1'=>$getPayoutResult,'paypal_api_response2'=>$finalResponse,'updated_at'=>date('Y-m-d H:i:s'),'paypal_api2'=>$paypalapi2]);


                $col_name="wallettotalamount";
                $updateCol=$col_name.'+'.$amount;
                SiteUser::where('id', $pData->siteusers_id)->update([$col_name=> \DB::raw($updateCol)]);

                //status update in walletdetais tbl
                Walletdetails::where('id', $pData->walletdetails_id)->update(['walletstatus'=>2,'updated_at'=>date('Y-m-d H:i:s')]);

                Withdrawldetails::create([
                       'siteusers_id'=>$pData->siteusers_id,
                       'walletdetails_id'=>$pData->walletdetails_id,
                       'amount'=>$pData->amount,
                       'transactionid'=>$pData->transactionid,
                       'status'=>4, //1 for success, 4 for failed
                       'withdrawl_type'=>0,//manual amount
                       'created_at'=>date('Y-m-d H:i:s'),
                       'updated_at'=>date('Y-m-d H:i:s'),
                       'payoutbatchid'=>$payout_batch_id,
                       'batchstatus'=>'FAILED',
                       'senderbatchid'=>$sender_batch_id,
                       'withdrawoption'=>0,//manual paypal
                       'withdrawoption'=>0,
                       'currency'=>'$'
               ]);

                $tags['firstname']=$userData->firstname;
                $tags['lastname']=$userData->lastname;
                $tags['amount']=$amount;
                $template='failedpaypaltopaypalfundtransfer';

                $this->sendEmailNotification($template, $toIds = [$pData->siteusers_id], $tags);

                return 'FAILED';
            }//Failed
            else {
                //PENDING


                if (isset($finalResponse['items'][0]['transaction_status']) && !empty($finalResponse['items'][0]['transaction_status']) && $finalResponse['items'][0]['transaction_status']=='PENDING') {
                    $getPayoutResult=print_r($getPayoutResult, true);
                    $finalResponse=print_r($finalResponse, true);
                    $paypalapi2=print_r($paypalapi2, true);

                    Autopayment::where('id', $autoPaymentId)->update(['status'=>0,'paypal_api_response1'=>$getPayoutResult,'paypal_api_response2'=>$finalResponse,'updated_at'=>date('Y-m-d H:i:s'),'paypal_api2'=>$paypalapi2]);
                    return 'PENDING';
                }

                //or UNCLAIMED
                if (isset($finalResponse['items'][0]['transaction_status']) && !empty($finalResponse['items'][0]['transaction_status']) && $finalResponse['items'][0]['transaction_status']=='UNCLAIMED') {
                    $getPayoutResult=print_r($getPayoutResult, true);
                    $finalResponse=print_r($finalResponse, true);
                    $paypalapi2=print_r($paypalapi2, true);

                    Autopayment::where('id', $autoPaymentId)->update(['status'=>0,'paypal_api_response1'=>$getPayoutResult,'paypal_api_response2'=>$finalResponse,'updated_at'=>date('Y-m-d H:i:s'),'paypal_api2'=>$paypalapi2]);
                    return 'UNCLAIMED';
                }
            }
        }
    }



    public function adminToUserPaypalFundTransferCanceled(Request $request)
    {
        $requestData = $request->all();

        $autoPaymentId=$requestData['id'];

        $pData=Autopayment::where('id', $autoPaymentId)->first();

        $userData=SiteUser::where('id', $pData->siteusers_id)->first();

        //3=rejected
        Autopayment::where('id', $autoPaymentId)->update(['status'=>3,'updated_at'=>date('Y-m-d H:i:s')]);


        $col_name="wallettotalamount";
        $updateCol=$col_name.'+'.$pData->amount;
        SiteUser::where('id', $pData->siteusers_id)->update([$col_name=> \DB::raw($updateCol)]);

        //status update in walletdetais tbl
        Walletdetails::where('id', $pData->walletdetails_id)->update(['walletstatus'=>2,'updated_at'=>date('Y-m-d H:i:s')]);

        $tags['firstname']=$userData->firstname;
        $tags['lastname']=$userData->lastname;
        $tags['amount']=$pData->amount;
        $template='cancelledpaypaltopaypalfundtransfer';

        $this->sendEmailNotification($template, $toIds = [$pData->siteusers_id], $tags);

        return 'CANCELLED';
    }