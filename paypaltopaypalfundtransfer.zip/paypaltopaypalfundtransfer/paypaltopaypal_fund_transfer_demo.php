<?php
//dev account url:https://developer.paypal.com/
//Account:rupesh.rathod@brainvire.com / Brain@2019
//AIM: Amount/Fund transfer from One paypal Account to Another paypal account by email
//Ref souce : http://significanttechno.com/paypal-transfer-payment-to-paypal-account-using-php
//Official : https://developer.paypal.com/docs/api/payments.payouts-batch/v1/
//Login with paypal : http://significanttechno.com/login-with-paypal-using-php

$PAYPAL_CLIENT_ID='AUM95ZWeeqtq6DeI_9DYLvafBsA3MreCEYMGXsbVVl_lLarlaVw8Ja8h86fOZkBX6793uTg847yQOM69';
$PAYPAL_SECRATE_KEY='ELDDUlFqqAhZsZRrDvGC_NWKrrbzWhhDwwqhff6w7AgcSzavHCjG8CJwrabuk3OZU9IzP7g4K1yxjU5p';


$baseUrl='https://api.sandbox.paypal.com/';
$oAuthUrl=$baseUrl.'v1/oauth2/token';
$paypalFundTransferUrl=$baseUrl.'v1/payments/payouts';
$payoutStatusCheckUrl=$baseUrl.'v1/payments/payouts/';

$amount='10';
$currency='USD'; //GBP
$receiver='sb-mkckf1482368@personal.example.com';



 // Get access token from PayPal client Id and secrate key
            $ch = curl_init();

            curl_setopt($ch, CURLOPT_URL, $oAuthUrl);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, "grant_type=client_credentials");
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_USERPWD, $PAYPAL_CLIENT_ID . ":" . $PAYPAL_SECRATE_KEY);

            $headers = array();
            $headers[] = "Accept: application/json";
            $headers[] = "Accept-Language: en_US";
            $headers[] = "Content-Type: application/x-www-form-urlencoded";
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            $results = curl_exec($ch);
            $getresult = json_decode($results);
            // echo "<pre>";print_r($getresult->access_token);exit;

            // PayPal Payout API for Send Payment from PayPal to PayPal account
            curl_setopt($ch, CURLOPT_URL, $paypalFundTransferUrl);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

            $array = array('sender_batch_header' => array(
                    "sender_batch_id" => time(),
                    "email_subject" => "You have a payout!",
                    "email_message" => "You have received a payout."
                ),
                'items' => array(array(
                        "recipient_type" => "EMAIL",
                        "amount" => array(
                            "value" => $amount,
                            "currency" => $currency
                        ),
                        "note" => "Thanks for the payout!",
                        "sender_item_id" => time(),
                        "receiver" =>$receiver
                    ))
            );
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($array));
            curl_setopt($ch, CURLOPT_POST, 1);

            $headers = array();
            $headers[] = "Content-Type: application/json";
            $headers[] = "Authorization: Bearer $getresult->access_token";
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            $payoutResult = curl_exec($ch);
            //print_r($result);
            $getPayoutResult = json_decode($payoutResult);
            if (curl_errno($ch)) {
                echo 'Error:' . curl_error($ch);
            }
            curl_close($ch);
            echo "<pre>";print_r($getPayoutResult);

            // echo "<pre>";print_r($getPayoutResult->batch_header->payout_batch_id);exit;


           sleep(10);
           //API 2
           $cURLConnection = curl_init();
           curl_setopt($cURLConnection, CURLOPT_URL, $payoutStatusCheckUrl.$getPayoutResult->batch_header->payout_batch_id);
           curl_setopt($cURLConnection, CURLOPT_RETURNTRANSFER, true);
           curl_setopt($cURLConnection, CURLOPT_HTTPHEADER, $headers);
           $payoutStatus = curl_exec($cURLConnection);
           curl_close($cURLConnection);

          echo "<pre>";print_r(json_decode($payoutStatus,true));

          $finalResponse=json_decode($payoutStatus,true);

        // echo "<pre>AAA";print_r($finalResponse['items']);exit;

        echo $payout_item_id=$finalResponse['items'][0]['payout_item_id']; echo "<br>";
        echo $payout_batch_id=$finalResponse['items'][0]['payout_batch_id'];echo "<br>";
        echo $transaction_status=$finalResponse['items'][0]['transaction_status'];echo "<br>";

        echo $transaction_id=$finalResponse['items'][0]['transaction_id'];
        // $activity_id=$payoutStatus->items[0]->activity_id;
