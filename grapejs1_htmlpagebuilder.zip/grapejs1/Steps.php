
Demo Project setup Guidline
==========================
Note: Here I have given zip file for demo.
      Unzip & put in htdocs
      Run below command in cli
       -npm i
       -npm i grapesjs ckeditor --no-save




For Custom download & custom plugin/functionality
===============

step -1
==========

You can download GrapesJS from one of these sources

CDNs
unpkg
https://unpkg.com/grapesjs
https://unpkg.com/grapesjs/dist/css/grapes.min.css
cdnjs
https://cdnjs.cloudflare.com/ajax/libs/grapesjs/0.12.17/grapes.min.js
https://cdnjs.cloudflare.com/ajax/libs/grapesjs/0.12.17/css/grapes.min.css
npm
npm i grapesjs
git
git clone https://github.com/artf/grapesjs.git


step-2
=====
Import the library

If use CDN or take clone then no need to do this step

Before you start using GrapesJS, you'll have to import it. Let's import the latest version

<link rel="stylesheet" href="//unpkg.com/grapesjs/dist/css/grapes.min.css">
<script src="//unpkg.com/grapesjs"></script>
<!--
If you need plugins, put them below the main grapesjs script
<script src="/path/to/some/plugin.min.js"></script>
-->
or if you're in a Node environment

import 'grapesjs/dist/css/grapes.min.css';
import grapesjs from 'grapesjs';
// If you need plugins, put them below the main grapesjs script
// import 'grapesjs-some-plugin';

step-3
=====

Open in browser

Step-4
=======
make initialise object for editor
var editor = grapesjs.init({});

Step-5
=======
If you need custom then only add
5.1) Add block manager
     -Write HTML as per your requirement & do drag & drop the block where you have require in cms template
5.2) Add style manager
    -You can add a different section of style & uses build props for CSS tags
5.3) Add AssetManager
    -It is used for upload image & set image in the cms page. You need to add an asset manager array in grapjs object.
5.4) Trait manager
     -Some are built-in trait-like text, number, checkbox, color, button
     -Create custom trait
5.5) Storage Manager
     -For Saving of modified/changed template
     -Store template on remote server
5.6) Plugin
     -Create new plugin for js functionality
     -Boilerplate
     -Popular plugins
     A)Git URL:https://github.com/artf/grapesjs-preset-webpage
      1)Take git clone
      2)open in browser














