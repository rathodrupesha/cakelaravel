<?php

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "grapesjs";


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


if($_GET['type']=='store'){

 $data=json_decode(file_get_contents('php://input'),1);

 // $jsonData=json_encode($data);
 // $storeData=stripslashes($jsonData);
 // echo $jsonData;exit;
   $id=$data['id'];
   $cms_page_name=$data['cms_page_name'];
   $html=json_encode($data['gjs-html']);
   $component=json_encode($data['gjs-components']);
   $assets=json_encode($data['gjs-assets']);
   $css=json_encode($data['gjs-css']);
   $styles=json_encode($data['gjs-styles']);


   $sql = "SELECT cms_page_name FROM cms_pages where cms_page_name='".$cms_page_name."'";
   $result = $conn->query($sql);

	if ($result->num_rows > 0) {
	 //Update
		 // $sql = "UPDATE cms_pages SET html='".$html."',component='".$component."',assets='".$assets."',css='".$css."',styles='".$styles."' WHERE cms_page_name='".$cms_page_name."'";

		 $sql = "UPDATE cms_pages SET html=$html,component=$component,assets=$assets,css=$css,styles=$styles  WHERE cms_page_name='".$cms_page_name."'";


			if ($conn->query($sql) === TRUE) {
			  echo "Record updated successfully";
			} else {
			  echo "Error updating record: " . $conn->error;
			}
	}else{
	//Insert
		$sql = "INSERT INTO cms_pages (cms_page_name,html,component,assets,css,styles)
	VALUES ('$cms_page_name',$html,$component,$assets,$css,$styles)";

	    if ($conn->query($sql) === TRUE) {
		  echo "New record created successfully"; exit;
		} else {
		  echo "Error: " . $sql . "<br>" . $conn->error; exit;
		}

	}

	$conn->close();


}else{

		$sql = "SELECT cms_page_content,html,component,assets,css,styles FROM cms_pages where cms_page_name='test2'";
		$result = $conn->query($sql);
		$conn->close();
		if ($result->num_rows > 0) {
		  // output data of each row
		  while($row = $result->fetch_assoc()) {

		    $c=array(

		       'gjs-html'=>$row['html'],
		       'gjs-components'=>$row['component'],
		       'gjs-assets'=>$row['assets'],
		       'gjs-css'=>$row['css'],
		       'gjs-styles'=>$row['styles']
		   );

		  	header('Content-Type: application/json');
		    echo json_encode($c); exit;
		  }
		} else {
		  echo "0 results";
		}
}

